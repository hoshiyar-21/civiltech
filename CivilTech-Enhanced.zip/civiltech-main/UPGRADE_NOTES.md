# CivilTech Upgrade Notes

This upgrade preserves the existing React/TypeScript + Express application and improves reliability without changing its product direction.

## Improvements included

1. **Persistent application records:** the server now loads and saves projects, tasks, materials, purchases, consumption, labour, equipment, safety checks/incidents, documents and site photos to `data/civiltech-db.json`. Writes use a temporary file followed by rename to reduce the chance of a partially-written database file.
2. **Honest AI fallback behaviour:** site progress fallback no longer claims that a site image was inspected or that physical checks passed. It labels the result as a preliminary checklist and retains the user-reported percentage.
3. **No fabricated compliance claims:** document-summary fallback no longer says a document complies with standards when no document content was actually reviewed.
4. **No fabricated citations:** the frontend no longer invents IS-code citations when the model response did not return citations.
5. **Project metadata and environment template:** package metadata and `.env.example` have been cleaned up.

## Run locally

Requirements: Node.js compatible with the Vite version in `package.json` (Node 20.19+ or 22.12+ recommended).

```bash
npm install
cp .env.example .env
# Optionally add GEMINI_API_KEY to .env
npm run dev
```

Open `http://localhost:3000`. The Express server starts Vite in middleware mode for development.

## Build and checks

```bash
npm run build
npm run check
```

The check script runs TypeScript checking. Resolve any diagnostics reported by your local dependency/toolchain versions before submission.

## Data storage notes

The JSON store is intended for a local student/demo deployment and single-process use. It is not a substitute for PostgreSQL or a transactional multi-user database in production. Back up `data/civiltech-db.json` before moving or resetting the project. Seed data is used on first run; after the first successful write, application state is saved in the JSON file.

## Important limitations to disclose

- AI features require a valid Gemini API key for live model responses.
- Site progress analysis in the current application uses user-provided progress and text; it is not a genuine computer-vision inspection.
- The JSON persistence layer is not designed for concurrent multi-instance production deployment.
- This is a student project, not certified engineering software. All structural, safety and code-compliance decisions require review by qualified professionals against current approved documents and standards.

## Recommended next upgrades

- Migrate JSON persistence to SQLite/PostgreSQL with schema migrations.
- Add authentication and server-side role authorization.
- Add automated API tests and frontend component tests.
- Implement real file uploads with validation, storage limits and access controls.
- Verify every engineering calculator against documented formulas and independent test cases.
- Add audit logs for material stock changes and safety incident updates.
