import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import {
  INITIAL_PROJECTS,
  INITIAL_TASKS,
  INITIAL_MATERIALS,
  INITIAL_PURCHASES,
  INITIAL_CONSUMPTION,
  INITIAL_LABOUR,
  INITIAL_EQUIPMENT,
  INITIAL_SAFETY_CHECKS,
  INITIAL_SAFETY_INCIDENTS,
  INITIAL_DOCUMENTS,
  INITIAL_SITE_PHOTOS,
} from './src/data/seedData.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '20mb' }));

// In-Memory Database State for Full-Stack CRUD
let projects = [...INITIAL_PROJECTS];
let tasks = [...INITIAL_TASKS];
let materials = [...INITIAL_MATERIALS];
let purchases = [...INITIAL_PURCHASES];
let consumption = [...INITIAL_CONSUMPTION];
let labourRecords = [...INITIAL_LABOUR];
let equipment = [...INITIAL_EQUIPMENT];
let safetyChecks = [...INITIAL_SAFETY_CHECKS];
let safetyIncidents = [...INITIAL_SAFETY_INCIDENTS];
let documents = [...INITIAL_DOCUMENTS];
let sitePhotos = [...INITIAL_SITE_PHOTOS];

// Lightweight durable JSON persistence. The original project kept all records
// in process memory, so changes were lost whenever the server restarted.
const dataDirectory = path.join(__dirname, 'data');
const databaseFile = path.join(dataDirectory, 'civiltech-db.json');
const persistentState = {
  projects, tasks, materials, purchases, consumption, labourRecords,
  equipment, safetyChecks, safetyIncidents, documents, sitePhotos,
};

function loadPersistentState() {
  try {
    if (!fs.existsSync(databaseFile)) return;
    const saved = JSON.parse(fs.readFileSync(databaseFile, 'utf8'));
    if (!saved || typeof saved !== 'object') return;
    projects = Array.isArray(saved.projects) ? saved.projects : projects;
    tasks = Array.isArray(saved.tasks) ? saved.tasks : tasks;
    materials = Array.isArray(saved.materials) ? saved.materials : materials;
    purchases = Array.isArray(saved.purchases) ? saved.purchases : purchases;
    consumption = Array.isArray(saved.consumption) ? saved.consumption : consumption;
    labourRecords = Array.isArray(saved.labourRecords) ? saved.labourRecords : labourRecords;
    equipment = Array.isArray(saved.equipment) ? saved.equipment : equipment;
    safetyChecks = Array.isArray(saved.safetyChecks) ? saved.safetyChecks : safetyChecks;
    safetyIncidents = Array.isArray(saved.safetyIncidents) ? saved.safetyIncidents : safetyIncidents;
    documents = Array.isArray(saved.documents) ? saved.documents : documents;
    sitePhotos = Array.isArray(saved.sitePhotos) ? saved.sitePhotos : sitePhotos;
    console.log('[CIVILTECH] Persistent data loaded.');
  } catch (error) {
    console.error('[CIVILTECH] Could not read database file; starting with seed data.', error);
  }
}

function savePersistentState() {
  try {
    fs.mkdirSync(dataDirectory, { recursive: true });
    const snapshot = {
      projects, tasks, materials, purchases, consumption, labourRecords,
      equipment, safetyChecks, safetyIncidents, documents, sitePhotos,
    };
    const temporaryFile = `${databaseFile}.tmp`;
    fs.writeFileSync(temporaryFile, JSON.stringify(snapshot, null, 2), 'utf8');
    fs.renameSync(temporaryFile, databaseFile);
  } catch (error) {
    console.error('[CIVILTECH] Failed to persist application data:', error);
  }
}

loadPersistentState();

// Persist successful write requests before returning the API response.
app.use((req: Request, res: Response, next) => {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) return next();
  const originalJson = res.json.bind(res);
  res.json = ((body: any) => {
    if (res.statusCode < 400 && !req.path.startsWith('/api/ai/')) savePersistentState();
    return originalJson(body);
  }) as typeof res.json;
  next();
});

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// REST API Endpoints

// 1. Projects
app.get('/api/projects', (req: Request, res: Response) => {
  res.json({ success: true, data: projects });
});

app.post('/api/projects', (req: Request, res: Response) => {
  const newProject = {
    ...req.body,
    id: `proj-${Date.now()}`,
    code: req.body.code || `CIV-2026-${Math.floor(100 + Math.random() * 900)}`,
    spentBudget: Number(req.body.spentBudget) || 0,
    completionPercentage: Number(req.body.completionPercentage) || 0,
    risksIdentified: Number(req.body.risksIdentified) || 0,
  };
  projects.unshift(newProject);
  res.status(201).json({ success: true, data: newProject });
});

app.put('/api/projects/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const index = projects.findIndex((p) => p.id === id);
  if (index !== -1) {
    projects[index] = { ...projects[index], ...req.body };
    res.json({ success: true, data: projects[index] });
  } else {
    res.status(404).json({ success: false, error: 'Project not found' });
  }
});

// 2. Tasks
app.get('/api/tasks', (req: Request, res: Response) => {
  const { projectId } = req.query;
  const filtered = projectId ? tasks.filter((t) => t.projectId === projectId) : tasks;
  res.json({ success: true, data: filtered });
});

app.post('/api/tasks', (req: Request, res: Response) => {
  const newTask = {
    ...req.body,
    id: `task-${Date.now()}`,
  };
  tasks.unshift(newTask);
  res.status(201).json({ success: true, data: newTask });
});

app.put('/api/tasks/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const index = tasks.findIndex((t) => t.id === id);
  if (index !== -1) {
    tasks[index] = { ...tasks[index], ...req.body };
    res.json({ success: true, data: tasks[index] });
  } else {
    res.status(404).json({ success: false, error: 'Task not found' });
  }
});

// 3. Materials & Inventory
app.get('/api/materials', (req: Request, res: Response) => {
  res.json({
    success: true,
    data: {
      materials,
      purchases,
      consumption,
    },
  });
});

app.post('/api/materials', (req: Request, res: Response) => {
  const newItem = {
    ...req.body,
    id: `mat-${Date.now()}`,
    currentStock: Number(req.body.currentStock) || 0,
    minThreshold: Number(req.body.minThreshold) || 10,
    unitCost: Number(req.body.unitCost) || 0,
  };
  materials.push(newItem);
  res.status(201).json({ success: true, data: newItem });
});

app.post('/api/materials/purchase', (req: Request, res: Response) => {
  const purchase = {
    ...req.body,
    id: `pur-${Date.now()}`,
    totalAmount: Number(req.body.quantity) * Number(req.body.unitPrice),
    purchaseDate: req.body.purchaseDate || new Date().toISOString().split('T')[0],
  };
  purchases.unshift(purchase);

  // Update stock level
  const mat = materials.find((m) => m.id === purchase.materialId || m.name === purchase.materialName);
  if (mat) {
    mat.currentStock += Number(purchase.quantity);
    mat.lastRestocked = purchase.purchaseDate;
  }

  res.status(201).json({ success: true, data: purchase, updatedStock: mat?.currentStock });
});

app.post('/api/materials/consume', (req: Request, res: Response) => {
  const log = {
    ...req.body,
    id: `con-${Date.now()}`,
    date: req.body.date || new Date().toISOString().split('T')[0],
  };
  consumption.unshift(log);

  // Deduct from stock
  const mat = materials.find((m) => m.name.toLowerCase() === log.materialName.toLowerCase());
  if (mat) {
    mat.currentStock = Math.max(0, mat.currentStock - Number(log.quantity));
  }

  res.status(201).json({ success: true, data: log, remainingStock: mat?.currentStock });
});

// 4. Labour & Equipment
app.get('/api/labour', (req: Request, res: Response) => {
  res.json({ success: true, data: labourRecords });
});

app.post('/api/labour', (req: Request, res: Response) => {
  const newRecord = {
    ...req.body,
    id: `lab-${Date.now()}`,
    date: req.body.date || new Date().toISOString().split('T')[0],
  };
  labourRecords.unshift(newRecord);
  res.status(201).json({ success: true, data: newRecord });
});

app.get('/api/equipment', (req: Request, res: Response) => {
  res.json({ success: true, data: equipment });
});

app.post('/api/equipment', (req: Request, res: Response) => {
  const item = {
    ...req.body,
    id: `eq-${Date.now()}`,
    hourMeter: Number(req.body.hourMeter) || 0,
  };
  equipment.unshift(item);
  res.status(201).json({ success: true, data: item });
});

// 5. Safety Management
app.get('/api/safety', (req: Request, res: Response) => {
  res.json({
    success: true,
    data: {
      checklist: safetyChecks,
      incidents: safetyIncidents,
    },
  });
});

app.post('/api/safety/check', (req: Request, res: Response) => {
  const { id, status, notes } = req.body;
  const item = safetyChecks.find((c) => c.id === id);
  if (item) {
    item.status = status;
    if (notes) item.notes = notes;
    res.json({ success: true, data: item });
  } else {
    res.status(404).json({ success: false, error: 'Check item not found' });
  }
});

app.post('/api/safety/incident', (req: Request, res: Response) => {
  const incident = {
    ...req.body,
    id: `inc-${Date.now()}`,
    date: req.body.date || new Date().toISOString().split('T')[0],
    status: req.body.status || 'Reported',
  };
  safetyIncidents.unshift(incident);
  res.status(201).json({ success: true, data: incident });
});

// 6. Documents
app.get('/api/documents', (req: Request, res: Response) => {
  res.json({ success: true, data: documents });
});

app.post('/api/documents', (req: Request, res: Response) => {
  const doc = {
    ...req.body,
    id: `doc-${Date.now()}`,
    uploadedAt: new Date().toISOString().split('T')[0],
    fileSize: req.body.fileSize || '3.2 MB',
  };
  documents.unshift(doc);
  res.status(201).json({ success: true, data: doc });
});

// 7. Site Photos & Progress Comparison
app.get('/api/site-photos', (req: Request, res: Response) => {
  res.json({ success: true, data: sitePhotos });
});

app.post('/api/site-photos', (req: Request, res: Response) => {
  const photo = {
    ...req.body,
    id: `sp-${Date.now()}`,
    dateCaptured: req.body.dateCaptured || new Date().toISOString().split('T')[0],
  };
  sitePhotos.unshift(photo);
  res.status(201).json({ success: true, data: photo });
});

// 8. AI Civil Engineering Assistant & Chat
app.post('/api/ai/chat', async (req: Request, res: Response) => {
  try {
    const { message, history } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const systemInstruction = `You are CIVILTECH AI, an authoritative Senior Civil & Structural Engineer, Construction Manager, and Indian Standards (IS Code) & International Building Code (IBC) specialist.
You assist civil engineers, site managers, quantity surveyors, and students.
Knowledge domains:
1. Indian Standards: IS 456:2000 (Plain and Reinforced Concrete), IS 800:2007 (Steel), IS 1893:2016 (Earthquake Resistant Design), IS 875 Parts 1-5 (Design Loads), IS 1200 (Measurement of Building Works), IS 383 (Aggregates), IS 10262 (Concrete Mix Proportioning), IS 1786 (High strength deformed steel bars), IS 3786 (Industrial safety).
2. Construction Tech: RMC mix design, slump test tolerances, water-cement ratios, formwork stripping intervals, curing techniques, deep foundations, pre-stressed concrete, post-tensioned slabs.
3. Quantity Surveying: Detailed BOQ calculations, Center Line vs Long Wall-Short Wall methods, dry volume factors (1.54 for concrete, 1.33 for plaster), steel bar bending schedules ($D^2/162$).
4. Structural Safety & Ethics: NEVER invent IS code clauses. If an engineering query requires formal structural detailing, provide the preliminary calculations, state formulas clearly, and explicitly state that all structural members must be checked against bending moment, shear force, deflection, and crack width limits by a licensed structural engineer before construction.

Format responses with clean Markdown, clear step-by-step formulas, equations, and exact clause citations where appropriate.`;

    let assistantReply = '';
    let citations: string[] = [];

    if (process.env.GEMINI_API_KEY) {
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: message,
          config: {
            systemInstruction,
          },
        });
        assistantReply = response.text || '';
      } catch (geminiError: any) {
        console.error('Gemini API Error:', geminiError?.message || geminiError);
        assistantReply = getFallbackCivilAnswer(message);
      }
    } else {
      assistantReply = getFallbackCivilAnswer(message);
    }

    // Extract probable citations from text
    const matches = assistantReply.match(/IS\s*\d+(:?\d{4})?/gi) || [];
    citations = Array.from(new Set(matches)).slice(0, 4);

    return res.json({
      success: true,
      reply: assistantReply,
      citations: citations.length ? citations : ['IS 456:2000', 'IS 10262:2019', 'CPWD DSR Specs'],
    });
  } catch (err: any) {
    console.error('Error in /api/ai/chat:', err);
    res.status(500).json({ error: 'Failed to process AI chat request' });
  }
});

// 9. AI Site Progress Vision Analysis
app.post('/api/ai/analyze-site', async (req: Request, res: Response) => {
  try {
    const { phase, stage, reportedPercent, notes } = req.body;

    const prompt = `Analyze this construction site progress data:
Phase: ${phase || 'Superstructure'}
Stage: ${stage || 'Slab Casting'}
Reported Work Completion: ${reportedPercent || 65}%
Site Notes: ${notes || 'Rebar placement and shuttering underway'}

Provide an objective civil engineering evaluation:
1. Realistic estimated range of completion based on structural staging.
2. Critical Quality & Safety check points (e.g. cover blocks, lapping zones, prop spacing, formwork levelling).
3. Potential delay risks and mitigation measures.
4. Formal disclaimer that computer vision & AI analysis provides preliminary verification and requires physical sign-off by the Resident Site Engineer.`;

    let analysis = '';
    if (process.env.GEMINI_API_KEY) {
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            systemInstruction: 'You are a Senior Construction Quality Assurance Auditor and Computer Vision Site Inspector.',
          },
        });
        analysis = response.text || '';
      } catch (e) {
        analysis = getFallbackSiteAnalysis(phase, stage, reportedPercent);
      }
    } else {
      analysis = getFallbackSiteAnalysis(phase, stage, reportedPercent);
    }

    res.json({
      success: true,
      analysis,
      calculatedVisionMatch: Math.max(0, Math.min(100, Number(reportedPercent) || 0)),
      inspectionStatus: 'Preliminary review only - no image-based verification performed',
    });
  } catch (e: any) {
    res.status(500).json({ error: 'Failed to analyze site progress' });
  }
});

// 10. AI Document Summarizer
app.post('/api/ai/summarize-doc', async (req: Request, res: Response) => {
  try {
    const { title, category, content } = req.body;
    const prompt = `Summarize this civil engineering document:
Title: ${title}
Category: ${category}
Document Overview: ${content || 'Structural design calculation sheet and soil test report for G+18 high rise.'}

Provide:
1. Executive Summary (2-3 sentences)
2. Key Design Parameters / Values Identified
3. Critical Compliance Standards & Clauses (IS / ASTM / Eurocode)
4. Recommended Actions for Site Engineer`;

    let summary = '';
    if (process.env.GEMINI_API_KEY) {
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
        });
        summary = response.text || '';
      } catch (e) {
        summary = `Document Analysis for "${title}":\n\n- Category provided: ${category || 'Not specified'}.\n- No document text was supplied for substantive review.\n- Compliance, design values and safe bearing capacity have NOT been verified.\n- Action: Upload or provide the document text for a meaningful summary, then have technical conclusions checked by a qualified engineer.`;
      }
    } else {
      summary = `Document Analysis for "${title}":\n\n- Category provided: ${category || 'Not specified'}.\n- No document text was supplied for substantive review.\n- Compliance, design values and safe bearing capacity have NOT been verified.\n- Action: Upload or provide the document text for a meaningful summary, then have technical conclusions checked by a qualified engineer.`;
    }

    res.json({ success: true, summary });
  } catch (e: any) {
    res.status(500).json({ error: 'Failed to summarize document' });
  }
});

// Fallback response generators for civil engineering expertise
function getFallbackCivilAnswer(query: string): string {
  const q = query.toLowerCase();
  if (q.includes('slump') || q.includes('workability')) {
    return `### Concrete Slump Test & Workability (IS 456:2000 Clause 7.1 & IS 1199)

The slump test measures the consistency and workability of fresh concrete.

| Placement Condition | Degree of Workability | Slump Value (mm) |
|---|---|---|
| Shallow sections, pavements using pavers | Very Low | 0 - 25 (Vee-Bee 10-20s) |
| Mass concrete, lightly reinforced sections in slabs, beams, walls | Low | 25 - 75 |
| Heavily reinforced sections in slabs, beams, columns | Medium | 50 - 100 |
| Pumped concrete, slipform work | High | 75 - 150 |
| Trench fill, in-situ piling, Tremie concrete | Very High | 150 - 200 (Flow table test) |

**Key Site Precautions:**
- Slump cone dimensions: Bottom dia 200mm, Top dia 100mm, Height 300mm.
- Filled in 4 equal layers; each tamped 25 times with standard 16mm bullet-nosed tamping rod.
- Measure vertical difference between cone height and highest point of slumped specimen immediately within 2.5 minutes of sampling.`;
  }

  if (q.includes('cover') || q.includes('nominal cover')) {
    return `### Nominal Concrete Cover Requirements (IS 456:2000 Clause 26.4)

Nominal cover is the design depth of concrete cover to all steel reinforcements (including links/stirrups).

| Structural Element | Minimum Nominal Cover (mm) | Conditions / Notes |
|---|---|---|
| **Footing / Raft Foundation** | **50 mm** | Protects against subsoil moisture & chemical attack |
| **Columns** | **40 mm** | 25 mm if column dimension $\\le 200\\text{ mm}$ and rebar $\\le 12\\text{ mm}$ |
| **Beams** | **25 mm** | For longitudinal main bars |
| **Slabs** | **20 mm** | Can be reduced to 15 mm for mild exposure with $\\le 12\\text{ mm}$ bars |
| **Staircase Waist Slab** | **15 - 20 mm** | Depending on exposure condition |
| **Shear Walls** | **25 mm** | Minimum cover for external faces |

*Note: For severe or very severe marine exposures (Clause 26.4.2), add 15mm to 20mm extra cover.*`;
  }

  if (q.includes('mix') || q.includes('m20') || q.includes('m25') || q.includes('ratio')) {
    return `### Standard Nominal & Design Concrete Mixes (IS 456:2000 & IS 10262:2019)

**Nominal Mix Proportions (By Volume - for small/preliminary works):**
- **M10 (1:3:6):** 1 Part Cement : 3 Parts Sand : 6 Parts Aggregate (PCC Foundation)
- **M15 (1:2:4):** 1 Part Cement : 2 Parts Sand : 4 Parts Aggregate (General Mass Concrete)
- **M20 (1:1.5:3):** 1 Part Cement : 1.5 Parts Sand : 3 Parts Aggregate (Minimum for RCC works)
- **M25 (1:1:2):** 1 Part Cement : 1 Part Sand : 2 Parts Aggregate (Heavily loaded beams/slabs)

**Dry Volume Calculation Multiplier:**
Fresh wet concrete shrinks when water fills the voids between sand and aggregate. Therefore, **Dry Volume = Wet Volume $\\times 1.54$** (a 54% allowance for shrinkage and void filling).

**Target Mean Strength ($f'_{ck}$):**
$$f'_{ck} = f_{ck} + 1.65 \\times s$$
Where $f_{ck}$ is characteristic compressive strength at 28 days and $s$ is standard deviation (e.g., $4.0\\text{ N/mm}^2$ for M20-M25, $5.0\\text{ N/mm}^2$ for M30-M50).`;
  }

  return `### Civil Engineering Technical Response

Regarding your query: "${query}"

**1. Applicable Indian Standards & Codes:**
- **IS 456:2000:** Code of Practice for Plain and Reinforced Concrete.
- **IS 800:2007:** General Construction in Steel - Code of Practice.
- **IS 1893 (Part 1): 2016:** Criteria for Earthquake Resistant Design of Structures.
- **IS 875 (Parts 1-5):** Code of Practice for Design Loads (Dead, Imposed, Wind, Snow, Special).
- **SP 16:** Design Aids for Reinforced Concrete to IS 456:2000.

**2. Key Design & Construction Principles:**
- All structural members must satisfy both **Limit State of Collapse** (Flexure, Compression, Shear, Torsion) and **Limit State of Serviceability** (Deflection, Cracking, Durability).
- Standard dry volume multiplier for concrete: **1.54**.
- Standard dry volume multiplier for mortar/plaster: **1.33**.
- Standard rebar unit weight: $\\text{Weight (kg/m)} = \\frac{D^2}{162}$, where $D$ is rebar diameter in mm.

*Disclaimer: This response is for educational and preliminary engineering guidance. Certified structural designs require verification by a registered Structural Engineer.*`;
}

function getFallbackSiteAnalysis(phase?: string, stage?: string, reportedPercent?: number): string {
  const percentage = Math.max(0, Math.min(100, Number(reportedPercent) || 0));
  return `### Preliminary Site Progress Review\n\n**Phase:** ${phase || 'Not specified'}  \n**Stage:** ${stage || 'Not specified'}  \n**Progress reported by user:** ${percentage}%\n\nNo site photograph or inspection evidence was analyzed by this fallback. The percentage above is the user-reported value, not an AI-measured result.\n\n**Suggested checks for the site engineer:**\n- Compare completed work against the approved drawings and current work programme.\n- Check reinforcement size, spacing, laps, anchorage and concrete cover against approved documents.\n- Verify formwork stability, line, level and propping before concrete placement.\n- Record inspection evidence and test results before approving the next activity.\n\n**Status:** Preliminary checklist only. This response does not certify quality, structural safety or code compliance. A qualified site/structural engineer must inspect and approve the work.`;
}

// Development and Production Static Serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[CIVILTECH AI] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
