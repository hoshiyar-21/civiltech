export type UserRole =
  | 'Administrator'
  | 'Civil Engineer'
  | 'Project Manager'
  | 'Contractor'
  | 'Site Supervisor'
  | 'Client';

export interface Project {
  id: string;
  name: string;
  code: string;
  type: 'Residential' | 'Commercial' | 'Infrastructure' | 'Industrial';
  location: string;
  coordinates: { lat: number; lng: number };
  clientName: string;
  projectManager: string;
  contractor: string;
  startDate: string;
  targetCompletionDate: string;
  estimatedBudget: number; // in currency units (e.g. ₹ or $)
  spentBudget: number;
  completionPercentage: number;
  status: 'Planning' | 'Active' | 'On Hold' | 'Under Review' | 'Completed';
  currentPhase: string;
  floors: number;
  totalBuiltupAreaSqFt: number;
  description: string;
  risksIdentified: number;
}

export interface ProjectTask {
  id: string;
  projectId: string;
  taskName: string;
  phase: 'Substructure' | 'Superstructure' | 'MEP' | 'Finishes' | 'Handover';
  startDate: string;
  endDate: string;
  progress: number;
  assignedContractor: string;
  status: 'Not Started' | 'In Progress' | 'Completed' | 'Delayed';
  budget: number;
  spent: number;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
}

export interface MaterialItem {
  id: string;
  name: string;
  category: 'Cement' | 'Steel' | 'Aggregates' | 'Bricks' | 'Finishes' | 'Chemicals';
  unit: string;
  currentStock: number;
  minThreshold: number;
  unitCost: number;
  supplier: string;
  lastRestocked: string;
  specification: string;
}

export interface MaterialPurchase {
  id: string;
  materialId: string;
  materialName: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  totalAmount: number;
  supplier: string;
  invoiceNo: string;
  purchaseDate: string;
  receivedBy: string;
}

export interface MaterialConsumption {
  id: string;
  projectId: string;
  materialName: string;
  quantity: number;
  unit: string;
  usedFor: string;
  date: string;
  loggedBy: string;
}

export interface LabourRecord {
  id: string;
  date: string;
  projectId: string;
  trade: 'Mason' | 'Bar Bender' | 'Carpenter' | 'Electrician' | 'Plumber' | 'Unskilled Helper';
  count: number;
  dailyWage: number;
  shiftHours: number;
  supervisor: string;
  remarks: string;
}

export interface EquipmentItem {
  id: string;
  name: string;
  equipmentType: 'Tower Crane' | 'Concrete Pump' | 'Excavator JCB' | 'Transit Mixer' | 'Plate Compactor' | 'Total Station';
  model: string;
  status: 'Operational' | 'In Use' | 'Under Maintenance' | 'Idle';
  assignedProject: string;
  dailyRentalCost: number;
  operatorName: string;
  nextServiceDate: string;
  hourMeter: number;
}

export interface SafetyCheckItem {
  id: string;
  category: 'Scaffolding' | 'Electrical' | 'Excavation' | 'PPE' | 'Fall Protection' | 'Housekeeping';
  item: string;
  status: 'Compliant' | 'Non-Compliant' | 'Not Applicable';
  notes: string;
}

export interface SafetyIncident {
  id: string;
  date: string;
  projectId: string;
  severity: 'Near Miss' | 'Minor' | 'Moderate' | 'Severe';
  type: string;
  location: string;
  description: string;
  correctiveAction: string;
  status: 'Reported' | 'Investigating' | 'Resolved';
  reportedBy: string;
}

export interface BOQItem {
  itemNo: string;
  category: string;
  description: string;
  quantity: number;
  unit: string;
  rate: number;
  amount: number;
  isCodeReference?: string;
}

export interface CostEstimateInput {
  plotLength: number;
  plotWidth: number;
  floors: number;
  buildingType: 'Residential Villa' | 'Apartment Complex' | 'Commercial Office' | 'Industrial Shed';
  quality: 'Economy / Basic' | 'Standard / Executive' | 'Luxury / High-End';
  basementIncluded: boolean;
  seismicZone: 'Zone II' | 'Zone III' | 'Zone IV' | 'Zone V';
  soilCondition: 'Hard Rock / Dense' | 'Medium / Sand' | 'Soft Clay / Loose';
  concreteGrade: 'M20' | 'M25' | 'M30';
  steelGrade: 'Fe415' | 'Fe500D' | 'Fe550';
}

export interface DocumentRecord {
  id: string;
  title: string;
  category: 'Structural Drawings' | 'Architectural' | 'BOQ & Contracts' | 'Site Inspection' | 'Cube Test Lab Reports';
  uploadedAt: string;
  fileSize: string;
  fileType: 'pdf' | 'dwg' | 'xlsx' | 'img';
  tags: string[];
  summary?: string;
}

export interface SitePhotoRecord {
  id: string;
  projectId: string;
  title: string;
  phase: string;
  dateCaptured: string;
  stage: 'Excavation' | 'Foundation' | 'Plinth Level' | 'Slab Casting' | 'Brickwork' | 'Finishing';
  imageUrlBefore: string;
  imageUrlAfter: string;
  progressReportedPercent: number;
  aiDetectedPercent: number;
  notes: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  timestamp: string;
  content: string;
  citations?: string[];
  suggestedFollowups?: string[];
}
