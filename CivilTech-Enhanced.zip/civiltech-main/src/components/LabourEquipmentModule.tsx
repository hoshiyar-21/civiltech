import React, { useState } from 'react';
import {
  Users2,
  HardHat,
  Truck,
  Plus,
  Clock,
  DollarSign,
  Calendar,
  Wrench,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { LabourRecord, EquipmentItem } from '../types/civil';
import { civilApi } from '../services/api';

interface LabourEquipmentProps {
  labour: LabourRecord[];
  equipment: EquipmentItem[];
  onDataUpdated: () => void;
}

export const LabourEquipmentModule: React.FC<LabourEquipmentProps> = ({
  labour,
  equipment,
  onDataUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'labour' | 'equipment'>('labour');
  const [showAddLabourModal, setShowAddLabourModal] = useState(false);

  // Form State
  const [trade, setTrade] = useState<'Mason' | 'Bar Bender' | 'Carpenter' | 'Electrician' | 'Plumber' | 'Unskilled Helper'>('Mason');
  const [count, setCount] = useState<number>(10);
  const [dailyWage, setDailyWage] = useState<number>(950);
  const [supervisor, setSupervisor] = useState<string>('Foreman Santosh');
  const [remarks, setRemarks] = useState<string>('10th floor slab formwork');

  const totalWorkers = labour.reduce((acc, l) => acc + l.count, 0);
  const totalDailyWageBill = labour.reduce((acc, l) => acc + l.count * l.dailyWage, 0);
  const operationalEquipment = equipment.filter((e) => e.status === 'Operational' || e.status === 'In Use').length;

  const handleAddLabour = async (e: React.FormEvent) => {
    e.preventDefault();
    await civilApi.addLabourRecord({
      date: new Date().toISOString().split('T')[0],
      projectId: 'proj-1',
      trade,
      count: Number(count),
      dailyWage: Number(dailyWage),
      shiftHours: 8,
      supervisor,
      remarks,
    });
    setShowAddLabourModal(false);
    onDataUpdated();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white">
              Labour Workforce &amp; Equipment Fleet
            </h1>
            <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-xs font-bold text-orange-700 dark:text-orange-400">
              Daily Muster Roll
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage daily worker allocation across trades, wage expenditures, heavy machinery availability, and service logs.
          </p>
        </div>

        <button
          onClick={() => setShowAddLabourModal(true)}
          className="flex items-center gap-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-3.5 py-2 text-xs font-bold shadow-sm shadow-orange-600/30 cursor-pointer transition"
        >
          <Plus className="h-4 w-4" />
          <span>Record Daily Labour</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Site Workforce Today</div>
          <div className="text-3xl font-black text-slate-900 dark:text-white mt-1">{totalWorkers} Workers</div>
          <div className="text-xs text-slate-500 mt-1">Across 6 construction trades</div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Daily Labour Wage Bill</div>
          <div className="text-3xl font-black text-orange-600 dark:text-orange-400 mt-1">
            ₹{totalDailyWageBill.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-500 mt-1">Based on 8-hour shift schedule</div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Equipment Fleet Health</div>
          <div className="text-3xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
            {operationalEquipment} / {equipment.length} Active
          </div>
          <div className="text-xs text-slate-500 mt-1">Tower cranes, batching pumps, JCBs</div>
        </div>
      </div>

      {/* Tab Switcher */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-4 text-xs font-bold">
        <button
          onClick={() => setActiveTab('labour')}
          className={`pb-2 transition cursor-pointer ${
            activeTab === 'labour'
              ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          Daily Labour Muster Roll ({labour.length} Entries)
        </button>
        <button
          onClick={() => setActiveTab('equipment')}
          className={`pb-2 transition cursor-pointer ${
            activeTab === 'equipment'
              ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          Machinery &amp; Heavy Equipment Fleet ({equipment.length})
        </button>
      </div>

      {/* Tab 1: Labour Table */}
      {activeTab === 'labour' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Trade Category</th>
                  <th className="py-3 px-4">Head Count</th>
                  <th className="py-3 px-4">Daily Wage Rate</th>
                  <th className="py-3 px-4">Total Daily Wage</th>
                  <th className="py-3 px-4">Shift Hours</th>
                  <th className="py-3 px-4">Supervisor / Jamadar</th>
                  <th className="py-3 px-4">Assigned Work / Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {labour.map((l) => (
                  <tr key={l.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <HardHat className="h-4 w-4 text-orange-500" />
                      <span>{l.trade}</span>
                    </td>
                    <td className="py-3 px-4 font-black text-slate-900 dark:text-white">{l.count} Nos</td>
                    <td className="py-3 px-4">₹{l.dailyWage} / day</td>
                    <td className="py-3 px-4 font-black text-orange-600 dark:text-orange-400">
                      ₹{(l.count * l.dailyWage).toLocaleString('en-IN')}
                    </td>
                    <td className="py-3 px-4 text-slate-500">{l.shiftHours} hrs</td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{l.supervisor}</td>
                    <td className="py-3 px-4 text-slate-500 max-w-xs">{l.remarks}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Equipment Grid */}
      {activeTab === 'equipment' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {equipment.map((eq) => (
            <div
              key={eq.id}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">{eq.name}</h3>
                  <div className="text-[11px] text-slate-400">{eq.model}</div>
                </div>
                <span
                  className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${
                    eq.status === 'In Use'
                      ? 'bg-orange-100 dark:bg-orange-950/60 text-orange-700 dark:text-orange-400'
                      : eq.status === 'Operational'
                      ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400'
                      : 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400'
                  }`}
                >
                  {eq.status}
                </span>
              </div>

              <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 p-3 text-xs space-y-1.5 border border-slate-100 dark:border-slate-800">
                <div className="flex justify-between text-slate-500">
                  <span>Operator:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">{eq.operatorName}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Daily Rate:</span>
                  <span className="font-bold text-slate-900 dark:text-white">₹{eq.dailyRentalCost.toLocaleString()}/day</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Hour Meter:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">{eq.hourMeter} Hours</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Next Service:</span>
                  <span className="font-semibold text-orange-600 dark:text-orange-400">{eq.nextServiceDate}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Labour Modal */}
      {showAddLabourModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-4">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Record Daily Labour Attendance</h2>
            <form onSubmit={handleAddLabour} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-500">Trade Category</label>
                <select
                  value={trade}
                  onChange={(e) => {
                    setTrade(e.target.value as any);
                    if (e.target.value === 'Unskilled Helper') setDailyWage(650);
                    else setDailyWage(950);
                  }}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                >
                  <option value="Mason">Mason</option>
                  <option value="Bar Bender">Bar Bender</option>
                  <option value="Carpenter">Carpenter</option>
                  <option value="Electrician">Electrician</option>
                  <option value="Plumber">Plumber</option>
                  <option value="Unskilled Helper">Unskilled Helper</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-500">Head Count</label>
                  <input
                    type="number"
                    value={count}
                    onChange={(e) => setCount(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-500">Daily Wage (₹)</label>
                  <input
                    type="number"
                    value={dailyWage}
                    onChange={(e) => setDailyWage(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-500">Supervisor / Lead</label>
                <input
                  type="text"
                  value={supervisor}
                  onChange={(e) => setSupervisor(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-slate-500">Work Area / Remarks</label>
                <input
                  type="text"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddLabourModal(false)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-2 font-bold text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 font-bold shadow-md shadow-orange-600/30"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
