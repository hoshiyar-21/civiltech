import React, { useState } from 'react';
import {
  Boxes,
  Plus,
  AlertTriangle,
  CheckCircle2,
  TrendingDown,
  ShoppingBag,
  FileText,
  DollarSign,
  Filter,
  Truck,
} from 'lucide-react';
import { MaterialItem, MaterialPurchase, MaterialConsumption } from '../types/civil';
import { civilApi } from '../services/api';

interface MaterialProps {
  materials: MaterialItem[];
  purchases: MaterialPurchase[];
  consumption: MaterialConsumption[];
  onMaterialUpdated: () => void;
}

export const MaterialModule: React.FC<MaterialProps> = ({
  materials,
  purchases,
  consumption,
  onMaterialUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'inventory' | 'purchases' | 'consumption'>('inventory');
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);
  const [showConsumeModal, setShowConsumeModal] = useState(false);

  // Purchase Form
  const [purchaseMatId, setPurchaseMatId] = useState(materials[0]?.id || '');
  const [purchaseQty, setPurchaseQty] = useState(100);
  const [purchasePrice, setPurchasePrice] = useState(385);
  const [purchaseSupplier, setPurchaseSupplier] = useState('UltraTech Cement Ltd');
  const [purchaseInvoice, setPurchaseInvoice] = useState('INV-2026-904');

  // Consumption Form
  const [consumeMatName, setConsumeMatName] = useState(materials[0]?.name || '');
  const [consumeQty, setConsumeQty] = useState(50);
  const [consumeTask, setConsumeTask] = useState('10th Floor Slab Concreting');
  const [consumeLoggedBy, setConsumeLoggedBy] = useState('Site Eng. Ankit Verma');

  const totalValuation = materials.reduce((acc, m) => acc + m.currentStock * m.unitCost, 0);
  const lowStockCount = materials.filter((m) => m.currentStock <= m.minThreshold).length;

  const formatINR = (val: number) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(2)} L`;
    return `₹${val.toLocaleString('en-IN')}`;
  };

  const handleCreatePurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    const mat = materials.find((m) => m.id === purchaseMatId) || materials[0];
    await civilApi.purchaseMaterial({
      materialId: mat.id,
      materialName: mat.name,
      quantity: Number(purchaseQty),
      unit: mat.unit,
      unitPrice: Number(purchasePrice),
      supplier: purchaseSupplier,
      invoiceNo: purchaseInvoice,
      receivedBy: 'Storekeeper Vinod Sharma',
    });
    setShowPurchaseModal(false);
    onMaterialUpdated();
  };

  const handleLogConsumption = async (e: React.FormEvent) => {
    e.preventDefault();
    const mat = materials.find((m) => m.name === consumeMatName) || materials[0];
    await civilApi.logMaterialConsumption({
      projectId: 'proj-1',
      materialName: mat.name,
      quantity: Number(consumeQty),
      unit: mat.unit,
      usedFor: consumeTask,
      loggedBy: consumeLoggedBy,
    });
    setShowConsumeModal(false);
    onMaterialUpdated();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white">
              Construction Material &amp; Inventory Management
            </h1>
            <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-xs font-bold text-orange-700 dark:text-orange-400">
              Live Stock Ledger
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Real-time site material inventory, minimum threshold alerts, purchase records, and consumption audits.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowConsumeModal(true)}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 shadow-sm cursor-pointer transition"
          >
            <TrendingDown className="h-4 w-4 text-orange-600" />
            <span>Log Consumption</span>
          </button>
          <button
            onClick={() => setShowPurchaseModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-3.5 py-2 text-xs font-bold shadow-sm shadow-orange-600/30 cursor-pointer transition"
          >
            <Plus className="h-4 w-4" />
            <span>Purchase Order (PO)</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Stock Value</div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">{formatINR(totalValuation)}</div>
          <div className="text-xs text-slate-500 mt-1">{materials.length} categories on site</div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Threshold Alerts</div>
          <div className="text-2xl font-black text-rose-600 dark:text-rose-400 mt-1 flex items-center gap-2">
            {lowStockCount > 0 ? (
              <>
                <AlertTriangle className="h-6 w-6" />
                <span>{lowStockCount} Low Stock Item</span>
              </>
            ) : (
              <span className="text-emerald-500">All Levels Safe</span>
            )}
          </div>
          <div className="text-xs text-slate-500 mt-1">Automatic restock notification</div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Recent PO Invoices</div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">{purchases.length} Orders</div>
          <div className="text-xs text-slate-500 mt-1">Direct supplier billing</div>
        </div>
      </div>

      {/* Tab Selectors */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-4 text-xs font-bold">
        <button
          onClick={() => setActiveTab('inventory')}
          className={`pb-2 transition cursor-pointer ${
            activeTab === 'inventory'
              ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          Material Stock Ledger ({materials.length})
        </button>
        <button
          onClick={() => setActiveTab('purchases')}
          className={`pb-2 transition cursor-pointer ${
            activeTab === 'purchases'
              ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          Material Purchases &amp; POs ({purchases.length})
        </button>
        <button
          onClick={() => setActiveTab('consumption')}
          className={`pb-2 transition cursor-pointer ${
            activeTab === 'consumption'
              ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          Site Consumption Log ({consumption.length})
        </button>
      </div>

      {/* Tab 1: Current Inventory Table */}
      {activeTab === 'inventory' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Material Name</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Current Stock</th>
                  <th className="py-3 px-4">Min. Threshold</th>
                  <th className="py-3 px-4">Unit Rate (₹)</th>
                  <th className="py-3 px-4">Total Value</th>
                  <th className="py-3 px-4">Approved Supplier</th>
                  <th className="py-3 px-4">Stock Health</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {materials.map((m) => {
                  const isLow = m.currentStock <= m.minThreshold;
                  return (
                    <tr key={m.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900 dark:text-white">{m.name}</div>
                        <div className="text-[10px] text-slate-400">{m.specification}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2 py-0.5 text-[10px] font-bold text-slate-700 dark:text-slate-300">
                          {m.category}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-black text-slate-900 dark:text-white">
                        {m.currentStock} {m.unit}
                      </td>
                      <td className="py-3 px-4 text-slate-500 font-semibold">
                        {m.minThreshold} {m.unit}
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-700 dark:text-slate-300">
                        ₹{m.unitCost.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 font-black text-slate-900 dark:text-white">
                        {formatINR(m.currentStock * m.unitCost)}
                      </td>
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-400">{m.supplier}</td>
                      <td className="py-3 px-4">
                        {isLow ? (
                          <span className="rounded-md bg-rose-100 dark:bg-rose-950/60 px-2 py-0.5 text-[10px] font-bold text-rose-700 dark:text-rose-400 flex items-center gap-1 w-fit">
                            <AlertTriangle className="h-3 w-3" /> Reorder Now
                          </span>
                        ) : (
                          <span className="rounded-md bg-emerald-100 dark:bg-emerald-950/60 px-2 py-0.5 text-[10px] font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1 w-fit">
                            <CheckCircle2 className="h-3 w-3" /> Adequate
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Purchases */}
      {activeTab === 'purchases' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Invoice No</th>
                  <th className="py-3 px-4">Material</th>
                  <th className="py-3 px-4">Qty</th>
                  <th className="py-3 px-4">Unit Price</th>
                  <th className="py-3 px-4">Total Amount</th>
                  <th className="py-3 px-4">Supplier</th>
                  <th className="py-3 px-4">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {purchases.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-bold text-orange-600 dark:text-orange-400">{p.invoiceNo}</td>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{p.materialName}</td>
                    <td className="py-3 px-4">{p.quantity} {p.unit}</td>
                    <td className="py-3 px-4">₹{p.unitPrice}</td>
                    <td className="py-3 px-4 font-black text-slate-900 dark:text-white">{formatINR(p.totalAmount)}</td>
                    <td className="py-3 px-4 text-slate-500">{p.supplier}</td>
                    <td className="py-3 px-4 text-slate-400">{p.purchaseDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Consumption */}
      {activeTab === 'consumption' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Material</th>
                  <th className="py-3 px-4">Quantity Used</th>
                  <th className="py-3 px-4">Construction Activity / Purpose</th>
                  <th className="py-3 px-4">Logged By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {consumption.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 text-slate-500 font-semibold">{c.date}</td>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{c.materialName}</td>
                    <td className="py-3 px-4 font-black text-orange-600 dark:text-orange-400">{c.quantity} {c.unit}</td>
                    <td className="py-3 px-4 text-slate-700 dark:text-slate-300">{c.usedFor}</td>
                    <td className="py-3 px-4 text-slate-500">{c.loggedBy}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Purchase Modal */}
      {showPurchaseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-4">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">New Material Purchase Order</h2>
            <form onSubmit={handleCreatePurchase} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-500">Select Material</label>
                <select
                  value={purchaseMatId}
                  onChange={(e) => {
                    setPurchaseMatId(e.target.value);
                    const mat = materials.find((m) => m.id === e.target.value);
                    if (mat) setPurchasePrice(mat.unitCost);
                  }}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                >
                  {materials.map((m) => (
                    <option key={m.id} value={m.id}>{m.name} ({m.unit})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-500">Quantity</label>
                  <input
                    type="number"
                    value={purchaseQty}
                    onChange={(e) => setPurchaseQty(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-500">Unit Price (₹)</label>
                  <input
                    type="number"
                    value={purchasePrice}
                    onChange={(e) => setPurchasePrice(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-500">Supplier</label>
                  <input
                    type="text"
                    value={purchaseSupplier}
                    onChange={(e) => setPurchaseSupplier(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-500">Invoice No</label>
                  <input
                    type="text"
                    value={purchaseInvoice}
                    onChange={(e) => setPurchaseInvoice(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowPurchaseModal(false)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-2 font-bold text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 font-bold shadow-md shadow-orange-600/30"
                >
                  Submit Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Consumption Modal */}
      {showConsumeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-4">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Log Material Consumption</h2>
            <form onSubmit={handleLogConsumption} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-500">Material</label>
                <select
                  value={consumeMatName}
                  onChange={(e) => setConsumeMatName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                >
                  {materials.map((m) => (
                    <option key={m.id} value={m.name}>{m.name} (Available: {m.currentStock} {m.unit})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-500">Quantity Consumed</label>
                <input
                  type="number"
                  value={consumeQty}
                  onChange={(e) => setConsumeQty(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-slate-500">Work Activity / Purpose</label>
                <input
                  type="text"
                  value={consumeTask}
                  onChange={(e) => setConsumeTask(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowConsumeModal(false)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-2 font-bold text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 font-bold shadow-md shadow-orange-600/30"
                >
                  Deduct &amp; Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
