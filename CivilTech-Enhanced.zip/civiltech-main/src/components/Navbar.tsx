import React from 'react';
import {
  Building2,
  HardHat,
  ShieldCheck,
  Search,
  Bell,
  Sun,
  Moon,
  ChevronDown,
  Sparkles,
  Layers,
} from 'lucide-react';
import { UserRole, Project } from '../types/civil';

interface NavbarProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  projects: Project[];
  selectedProjectId: string;
  onSelectProject: (id: string) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenQuickEstimate?: () => void;
}

const ROLES: UserRole[] = [
  'Administrator',
  'Civil Engineer',
  'Project Manager',
  'Contractor',
  'Site Supervisor',
  'Client',
];

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  onRoleChange,
  projects,
  selectedProjectId,
  onSelectProject,
  darkMode,
  onToggleDarkMode,
  onOpenQuickEstimate,
}) => {
  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 px-4 backdrop-blur-md transition-colors">
      {/* Brand & Tagline */}
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-md shadow-orange-500/20">
          <Building2 className="h-6 w-6" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-extrabold tracking-tight text-lg text-slate-900 dark:text-white">
              CIVILTECH <span className="text-orange-600 dark:text-orange-500">AI</span>
            </span>
            <span className="hidden sm:inline-flex rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-[11px] font-semibold text-orange-700 dark:text-orange-400 border border-orange-200 dark:border-orange-800/50">
              IS &amp; IBC Standards
            </span>
          </div>
          <p className="hidden md:block text-[11px] font-medium text-slate-500 dark:text-slate-400 leading-none">
            Building Smarter, Planning Better, Constructing Safer
          </p>
        </div>
      </div>

      {/* Middle: Active Project Selector */}
      <div className="hidden lg:flex items-center gap-2 bg-slate-100 dark:bg-slate-800/70 px-3 py-1.5 rounded-lg border border-slate-200/80 dark:border-slate-700/60">
        <Layers className="h-4 w-4 text-orange-500" />
        <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Active Site:</span>
        <select
          value={selectedProjectId}
          onChange={(e) => onSelectProject(e.target.value)}
          className="bg-transparent text-xs font-bold text-slate-800 dark:text-slate-100 outline-none cursor-pointer pr-2 max-w-[220px] truncate"
        >
          {projects.map((proj) => (
            <option key={proj.id} value={proj.id} className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200">
              {proj.name} ({proj.code})
            </option>
          ))}
        </select>
      </div>

      {/* Right: Actions, Role Selector & Theme */}
      <div className="flex items-center gap-2 sm:gap-3">
        {onOpenQuickEstimate && (
          <button
            onClick={onOpenQuickEstimate}
            className="hidden sm:flex items-center gap-1.5 rounded-lg bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white px-3 py-1.5 text-xs font-bold shadow-sm shadow-orange-600/30 transition-all cursor-pointer"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>AI Estimator</span>
          </button>
        )}

        {/* Role Switcher */}
        <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700">
          <HardHat className="h-4 w-4 text-amber-500" />
          <div className="text-left">
            <div className="text-[10px] text-slate-400 uppercase font-semibold leading-none">Role</div>
            <select
              value={currentRole}
              onChange={(e) => onRoleChange(e.target.value as UserRole)}
              className="bg-transparent text-xs font-bold text-slate-800 dark:text-slate-200 outline-none cursor-pointer"
            >
              {ROLES.map((role) => (
                <option key={role} value={role} className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200">
                  {role}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Safety Badge */}
        <div className="hidden xl:flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/50 px-2.5 py-1 rounded-lg">
          <ShieldCheck className="h-4 w-4" />
          <span>EHS Compliant</span>
        </div>

        {/* Dark Mode Toggle */}
        <button
          onClick={onToggleDarkMode}
          title="Toggle Light/Dark Theme"
          className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
        >
          {darkMode ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4 text-slate-600" />}
        </button>
      </div>
    </header>
  );
};
