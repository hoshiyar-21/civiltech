import React, { useState } from 'react';
import {
  Binary,
  Layers,
  Box,
  Paintbrush,
  Ruler,
  TrendingDown,
  Hammer,
  ShieldAlert,
  Info,
  CheckCircle2,
  Copy,
  Check,
  ChevronDown,
} from 'lucide-react';

export const CalculatorModule: React.FC = () => {
  const [selectedCalc, setSelectedCalc] = useState<string>('concrete');
  const [copied, setCopied] = useState<boolean>(false);

  // 1. Concrete Calculator State
  const [concLength, setConcLength] = useState<number>(10); // meters or feet
  const [concWidth, setConcWidth] = useState<number>(4);
  const [concDepth, setConcDepth] = useState<number>(0.15);
  const [concGrade, setConcGrade] = useState<'M15' | 'M20' | 'M25' | 'M30'>('M20');

  // 2. Brick Calculator State
  const [brickWallLen, setBrickWallLen] = useState<number>(5); // m
  const [brickWallHeight, setBrickWallHeight] = useState<number>(3); // m
  const [brickWallThick, setBrickWallThick] = useState<number>(0.2); // 200mm / 9-inch
  const [brickMortarRatio, setBrickMortarRatio] = useState<'1:4' | '1:6'>('1:6');

  // 3. Plaster Calculator State
  const [plasterArea, setPlasterArea] = useState<number>(100); // sq.m
  const [plasterThick, setPlasterThick] = useState<number>(12); // mm
  const [plasterRatio, setPlasterRatio] = useState<'1:4' | '1:6'>('1:4');

  // 4. Steel Rebar Calculator State
  const [steelDia, setSteelDia] = useState<number>(16); // mm
  const [steelLength, setSteelLength] = useState<number>(12); // m
  const [steelBarCount, setSteelBarCount] = useState<number>(20); // nos

  // 5. Beam Load Calculator State
  const [beamSpan, setBeamSpan] = useState<number>(5); // m
  const [beamWidth, setBeamWidth] = useState<number>(300); // mm
  const [beamDepth, setBeamDepth] = useState<number>(500); // mm
  const [beamLiveLoad, setBeamLiveLoad] = useState<number>(15); // kN/m (UDL)

  // 6. Column Load Calculator State
  const [colFloors, setColFloors] = useState<number>(4);
  const [colTribArea, setColTribArea] = useState<number>(25); // sq.m
  const [colLiveLoad, setColLiveLoad] = useState<number>(3); // kN/m2

  // 7. Flooring & Tiles State
  const [floorRoomLen, setFloorRoomLen] = useState<number>(6); // m
  const [floorRoomWid, setFloorRoomWid] = useState<number>(4); // m
  const [tileLengthMm, setTileLengthMm] = useState<number>(600); // mm
  const [tileWidthMm, setTileWidthMm] = useState<number>(600); // mm

  // 8. Paint Calculator State
  const [paintWallArea, setPaintWallArea] = useState<number>(150); // sq.m
  const [paintDeductions, setPaintDeductions] = useState<number>(15); // sq.m for doors/windows
  const [paintCoats, setPaintCoats] = useState<number>(2);

  // 9. Excavation & Earthwork State
  const [excavLen, setExcavLen] = useState<number>(12); // m
  const [excavWid, setExcavWid] = useState<number>(8); // m
  const [excavDepth, setExcavDepth] = useState<number>(2.5); // m
  const [excavSlopeRatio, setExcavSlopeRatio] = useState<number>(0.5); // 1:0.5 batter

  // 10. Slab Quantity State
  const [slabSpanLx, setSlabSpanLx] = useState<number>(4); // m
  const [slabSpanLy, setSlabSpanLy] = useState<number>(5.5); // m
  const [slabThickness, setSlabThickness] = useState<number>(150); // mm

  // 11. Foundation Footing State
  const [footingAxialLoad, setFootingAxialLoad] = useState<number>(850); // kN
  const [footingSBC, setFootingSBC] = useState<number>(200); // kN/m2 safe bearing capacity
  const [footingDepth, setFootingDepth] = useState<number>(0.45); // m

  // 12. Staircase Calculator State
  const [stairHeight, setStairHeight] = useState<number>(3.0); // m floor height
  const [stairRiser, setStairRiser] = useState<number>(150); // mm
  const [stairTread, setStairTread] = useState<number>(300); // mm
  const [stairWidth, setStairWidth] = useState<number>(1.2); // m flight width

  // Copy calculations to clipboard helper
  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // CALCULATOR LOGIC IMPLEMENTATIONS

  // 1. Concrete (IS 456 / IS 10262)
  const wetVol = concLength * concWidth * concDepth;
  const dryVol = wetVol * 1.54; // 54% void factor
  const gradeRatios: Record<string, { c: number; s: number; a: number; sum: number }> = {
    M15: { c: 1, s: 2, a: 4, sum: 7 },
    M20: { c: 1, s: 1.5, a: 3, sum: 5.5 },
    M25: { c: 1, s: 1, a: 2, sum: 4 },
    M30: { c: 1, s: 0.8, a: 1.6, sum: 3.4 },
  };
  const cRatio = gradeRatios[concGrade];
  const concCementVol = (cRatio.c / cRatio.sum) * dryVol;
  const concCementKg = concCementVol * 1440; // 1440 kg/m3 density of cement
  const concCementBags = (concCementKg / 50).toFixed(1);
  const concSandVol = (cRatio.s / cRatio.sum) * dryVol;
  const concSandKg = Math.round(concSandVol * 1600); // 1600 kg/m3 sand density
  const concSandCft = (concSandVol * 35.3147).toFixed(1);
  const concAggVol = (cRatio.a / cRatio.sum) * dryVol;
  const concAggKg = Math.round(concAggVol * 1550); // 1550 kg/m3 aggregate density
  const concAggCft = (concAggVol * 35.3147).toFixed(1);
  const concWaterLiters = Math.round(Number(concCementKg) * 0.45); // 0.45 w/c ratio

  // 2. Brickwork (IS 2212)
  const wallVol = brickWallLen * brickWallHeight * brickWallThick;
  // Modular brick with mortar: 0.2 x 0.1 x 0.1 = 0.002 m3 -> 500 bricks per m3
  const totalBricks = Math.ceil(wallVol * 500 * 1.05); // +5% breakage
  const actualBricksVol = totalBricks * (0.19 * 0.09 * 0.09);
  const wetMortarVol = Math.max(0, wallVol - actualBricksVol);
  const dryMortarVol = wetMortarVol * 1.33; // 33% dry volume expansion
  const bMortarParts = brickMortarRatio === '1:4' ? 5 : 7;
  const brickCementBags = ((dryMortarVol / bMortarParts) * 1440 / 50).toFixed(1);
  const brickSandCft = (((dryMortarVol * (bMortarParts - 1)) / bMortarParts) * 35.3147).toFixed(1);

  // 3. Plastering (IS 1661)
  const plasterWetVol = plasterArea * (plasterThick / 1000);
  const plasterDryVol = plasterWetVol * 1.33 * 1.15; // 33% dry factor + 15% joint filling
  const pParts = plasterRatio === '1:4' ? 5 : 7;
  const plasterCementBags = ((plasterDryVol / pParts) * 1440 / 50).toFixed(1);
  const plasterSandCft = (((plasterDryVol * (pParts - 1)) / pParts) * 35.3147).toFixed(1);

  // 4. Steel Rebar (D^2 / 162)
  const unitWeightKgM = (steelDia * steelDia) / 162.28;
  const totalWeightKg = unitWeightKgM * steelLength * steelBarCount;
  const totalWeightTonnes = (totalWeightKg / 1000).toFixed(3);

  // 5. Beam Load & Bending Moment (IS 456 Limit State)
  const beamSelfWeightKnm = (beamWidth / 1000) * (beamDepth / 1000) * 25; // 25 kN/m3 concrete
  const beamSlabLoadKnm = 12.5; // typical 2.5m tributary slab load
  const totalDeadLoadKnm = beamSelfWeightKnm + beamSlabLoadKnm;
  const totalWorkingLoadKnm = totalDeadLoadKnm + beamLiveLoad;
  const factoredLoadWu = 1.5 * totalWorkingLoadKnm; // 1.5 safety factor
  const maxBendingMomentMu = (factoredLoadWu * beamSpan * beamSpan) / 8; // wL^2 / 8 in kNm
  const maxShearForceVu = (factoredLoadWu * beamSpan) / 2; // wL / 2 in kN
  // Preliminary Ast check: Mu = 0.87 * fy * Ast * d * (1 - (Ast * fy)/(b * d * fck))
  const dEff = beamDepth - 50; // effective depth
  const approxAstReq = Math.round((maxBendingMomentMu * 1e6) / (0.87 * 500 * 0.9 * dEff)); // Fe500

  // 6. Column Axial Load (IS 456 Tributary Method)
  const deadLoadPerFloor = colTribArea * 12; // 12 kN/m2 (slab + beams + walls)
  const liveLoadPerFloor = colTribArea * colLiveLoad;
  const totalFloorLoad = deadLoadPerFloor + liveLoadPerFloor;
  const workingAxialLoadP = totalFloorLoad * colFloors * 1.1; // +10% self-weight of columns
  const factoredPu = 1.5 * workingAxialLoadP; // in kN
  // As per IS 456 Cl 39.3: Pu = 0.4 fck Ac + 0.67 fy Asc. Assuming 1.2% steel (Asc = 0.012 Ag, Ac = 0.988 Ag)
  // Pu * 1000 = (0.4 * 25 * 0.988 + 0.67 * 500 * 0.012) * Ag = (9.88 + 4.02) Ag = 13.9 Ag
  const requiredAgMm2 = Math.round((factoredPu * 1000) / 13.9);
  const recommendedSideMm = Math.ceil(Math.sqrt(requiredAgMm2) / 50) * 50; // rounded to nearest 50mm

  // 7. Flooring & Tiles
  const floorNetAreaSqM = floorRoomLen * floorRoomWid;
  const singleTileAreaSqM = (tileLengthMm / 1000) * (tileWidthMm / 1000);
  const netTilesReq = Math.ceil(floorNetAreaSqM / singleTileAreaSqM);
  const totalTilesWithWastage = Math.ceil(netTilesReq * 1.1); // 10% cutting wastage & skirting
  const mortarBedDryVol = floorNetAreaSqM * 0.025 * 1.33; // 25mm bedding mortar
  const flooringCementBags = ((mortarBedDryVol / 5) * 1440 / 50).toFixed(1); // 1:4 mix

  // 8. Paint
  const netPaintArea = Math.max(1, paintWallArea - paintDeductions);
  const paintLiters = (netPaintArea * paintCoats) / 11; // 11 sq.m per liter per coat

  // 9. Excavation & Earthwork
  const avgLen = excavLen + 2 * (excavDepth * excavSlopeRatio);
  const avgWid = excavWid + 2 * (excavDepth * excavSlopeRatio);
  const excavBankVol = ((excavLen * excavWid + avgLen * avgWid) / 2) * excavDepth;
  const excavLooseVol = excavBankVol * 1.25; // 25% swell / bulking factor
  const dumperTrips = Math.ceil(excavLooseVol / 10); // 10 m3 tipper truck

  // 10. Slab Quantity
  const slabVol = slabSpanLx * slabSpanLy * (slabThickness / 1000);
  const slabConcDry = slabVol * 1.54;
  const slabSteelKg = Math.round(slabVol * 90); // 90 kg/m3 steel for slabs

  // 11. Footing
  const reqFootingAreaSqM = (footingAxialLoad * 1.1) / footingSBC; // +10% footing weight
  const footingSideM = Math.sqrt(reqFootingAreaSqM).toFixed(2);
  const footingVolCuM = (reqFootingAreaSqM * footingDepth).toFixed(2);

  // 12. Staircase
  const totalRisers = Math.round((stairHeight * 1000) / stairRiser);
  const actualRiser = ((stairHeight * 1000) / totalRisers).toFixed(1);
  const totalTreads = totalRisers - 1;
  const stairAngleDeg = (Math.atan(stairRiser / stairTread) * (180 / Math.PI)).toFixed(1);
  const waistSlabThickM = 0.15;
  const flightLengthM = Math.sqrt(Math.pow(totalTreads * (stairTread / 1000), 2) + Math.pow(stairHeight, 2));
  const waistSlabVolCuM = (flightLengthM * stairWidth * waistSlabThickM).toFixed(2);

  const CALC_TABS = [
    { id: 'concrete', name: '1. Concrete Mix & Vol', icon: Layers, isCode: 'IS 456 / IS 10262' },
    { id: 'brick', name: '2. Brickwork & Mortar', icon: Box, isCode: 'IS 2212' },
    { id: 'plaster', name: '3. Wall Plastering', icon: Paintbrush, isCode: 'IS 1661' },
    { id: 'steel', name: '4. Steel Rebar Weight', icon: Binary, isCode: 'IS 1786' },
    { id: 'beam', name: '5. Structural Beam Load', icon: Ruler, isCode: 'IS 456 Cl. 23' },
    { id: 'column', name: '6. Column Load & Sizing', icon: TrendingDown, isCode: 'IS 456 Cl. 39' },
    { id: 'slab', name: '7. Slab Volume & Steel', icon: Layers, isCode: 'IS 456 Cl. 24' },
    { id: 'flooring', name: '8. Flooring & Tiles', icon: Box, isCode: 'IS 14457' },
    { id: 'paint', name: '9. Paint Quantity', icon: Paintbrush, isCode: 'IS 15489' },
    { id: 'excavation', name: '10. Excavation Earthwork', icon: Hammer, isCode: 'IS 1200 Pt 1' },
    { id: 'footing', name: '11. Isolated Footing', icon: Box, isCode: 'IS 456 Cl. 34' },
    { id: 'staircase', name: '12. Staircase Waist Slab', icon: Ruler, isCode: 'IS 456 Cl. 33' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-black text-slate-900 dark:text-white">
            Civil Engineering Technical Calculators
          </h1>
          <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-xs font-bold text-orange-700 dark:text-orange-400">
            12 In 1 IS Engine
          </span>
        </div>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Rigorous engineering formulas with dry volume factors, limit state design checks, and step-by-step IS 456 / IS 1200 derivations.
        </p>
      </div>

      {/* Calculator Selectors Tab Bar */}
      <div className="flex overflow-x-auto gap-2 pb-2 scrollbar-thin">
        {CALC_TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = selectedCalc === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSelectedCalc(tab.id)}
              className={`flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold transition cursor-pointer ${
                isActive
                  ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.name}</span>
            </button>
          );
        })}
      </div>

      {/* Main Calculator Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Input Parameters (5 cols) */}
        <div className="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">Input Parameters</h2>
            <span className="text-[10px] font-bold text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/60 px-2 py-0.5 rounded-md">
              {CALC_TABS.find((t) => t.id === selectedCalc)?.isCode}
            </span>
          </div>

          {/* 1. Concrete Inputs */}
          {selectedCalc === 'concrete' && (
            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-500">Concrete Grade (Mix Design)</label>
                <select
                  value={concGrade}
                  onChange={(e) => setConcGrade(e.target.value as any)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-bold text-slate-900 dark:text-white"
                >
                  <option value="M15">M15 (1:2:4 - Lean/PCC)</option>
                  <option value="M20">M20 (1:1.5:3 - Standard RCC)</option>
                  <option value="M25">M25 (1:1:2 - Heavy Columns/Beams)</option>
                  <option value="M30">M30 (Design Mix High Strength)</option>
                </select>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Length (m)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={concLength}
                    onChange={(e) => setConcLength(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Width (m)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={concWidth}
                    onChange={(e) => setConcWidth(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Depth (m)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={concDepth}
                    onChange={(e) => setConcDepth(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
              </div>
              <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 p-3 text-xs text-slate-500 space-y-1">
                <div>Dry Volume Multiplier: <span className="font-bold text-slate-800 dark:text-slate-200">1.54 (54% void allowance)</span></div>
                <div>Cement Density: <span className="font-bold text-slate-800 dark:text-slate-200">1440 kg/m³</span></div>
                <div>Water-Cement Ratio: <span className="font-bold text-slate-800 dark:text-slate-200">0.45 - 0.50</span></div>
              </div>
            </div>
          )}

          {/* 2. Brickwork Inputs */}
          {selectedCalc === 'brick' && (
            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Wall Length (m)</label>
                  <input
                    type="number"
                    value={brickWallLen}
                    onChange={(e) => setBrickWallLen(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Height (m)</label>
                  <input
                    type="number"
                    value={brickWallHeight}
                    onChange={(e) => setBrickWallHeight(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Thickness (m)</label>
                  <input
                    type="number"
                    step="0.05"
                    value={brickWallThick}
                    onChange={(e) => setBrickWallThick(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-500">Mortar Ratio</label>
                <select
                  value={brickMortarRatio}
                  onChange={(e) => setBrickMortarRatio(e.target.value as any)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                >
                  <option value="1:6">1:6 (Standard 200mm external wall)</option>
                  <option value="1:4">1:4 (100mm partition wall / parapet)</option>
                </select>
              </div>
              <p className="text-[11px] text-slate-400">
                Modular brick standard size: 190 x 90 x 90 mm (with 10mm mortar joint = 200 x 100 x 100 mm).
              </p>
            </div>
          )}

          {/* 3. Plastering Inputs */}
          {selectedCalc === 'plaster' && (
            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-500">Plaster Surface Area (sq.m)</label>
                <input
                  type="number"
                  value={plasterArea}
                  onChange={(e) => setPlasterArea(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Thickness (mm)</label>
                  <select
                    value={plasterThick}
                    onChange={(e) => setPlasterThick(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  >
                    <option value={12}>12 mm (Internal Brick face)</option>
                    <option value={15}>15 mm (External Sand-faced)</option>
                    <option value={20}>20 mm (Double coat waterproofing)</option>
                    <option value={6}>6 mm (RCC Ceiling)</option>
                  </select>
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Cement : Sand Ratio</label>
                  <select
                    value={plasterRatio}
                    onChange={(e) => setPlasterRatio(e.target.value as any)}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  >
                    <option value="1:4">1:4 (Rich ceiling/external)</option>
                    <option value="1:6">1:6 (Standard internal)</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* 4. Steel Rebar Inputs */}
          {selectedCalc === 'steel' && (
            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-500">Bar Diameter (mm)</label>
                <select
                  value={steelDia}
                  onChange={(e) => setSteelDia(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                >
                  {[8, 10, 12, 16, 20, 25, 28, 32].map((d) => (
                    <option key={d} value={d}>{d} mm rebar</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Length per Bar (m)</label>
                  <input
                    type="number"
                    value={steelLength}
                    onChange={(e) => setSteelLength(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Total Bar Count (nos)</label>
                  <input
                    type="number"
                    value={steelBarCount}
                    onChange={(e) => setSteelBarCount(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
              </div>
            </div>
          )}

          {/* 5. Beam Load Inputs */}
          {selectedCalc === 'beam' && (
            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Span L (m)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={beamSpan}
                    onChange={(e) => setBeamSpan(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Width b (mm)</label>
                  <input
                    type="number"
                    value={beamWidth}
                    onChange={(e) => setBeamWidth(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Depth D (mm)</label>
                  <input
                    type="number"
                    value={beamDepth}
                    onChange={(e) => setBeamDepth(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-500">Superimposed Live Load (kN/m)</label>
                <input
                  type="number"
                  value={beamLiveLoad}
                  onChange={(e) => setBeamLiveLoad(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                />
              </div>
            </div>
          )}

          {/* 6. Column Load Inputs */}
          {selectedCalc === 'column' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Supported Floors</label>
                  <input
                    type="number"
                    value={colFloors}
                    onChange={(e) => setColFloors(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-500">Tributary Area (sq.m)</label>
                  <input
                    type="number"
                    value={colTribArea}
                    onChange={(e) => setColTribArea(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                  />
                </div>
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-500">Live Load (kN/sq.m)</label>
                <input
                  type="number"
                  value={colLiveLoad}
                  onChange={(e) => setColLiveLoad(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
                />
              </div>
            </div>
          )}

          {/* Fallback general inputs for other tabs */}
          {['slab', 'flooring', 'paint', 'excavation', 'footing', 'staircase'].includes(selectedCalc) && (
            <div className="space-y-3 text-xs">
              <p className="text-slate-500">
                Adjust key site dimensions below to compute results dynamically:
              </p>
              {selectedCalc === 'staircase' && (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-bold text-slate-500">Floor Height (m)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={stairHeight}
                      onChange={(e) => setStairHeight(Number(e.target.value))}
                      className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-500">Riser (mm)</label>
                    <input
                      type="number"
                      value={stairRiser}
                      onChange={(e) => setStairRiser(Number(e.target.value))}
                      className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2"
                    />
                  </div>
                </div>
              )}
              {selectedCalc === 'excavation' && (
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="font-bold text-slate-500">Len (m)</label>
                    <input
                      type="number"
                      value={excavLen}
                      onChange={(e) => setExcavLen(Number(e.target.value))}
                      className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-500">Wid (m)</label>
                    <input
                      type="number"
                      value={excavWid}
                      onChange={(e) => setExcavWid(Number(e.target.value))}
                      className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-500">Depth (m)</label>
                    <input
                      type="number"
                      value={excavDepth}
                      onChange={(e) => setExcavDepth(Number(e.target.value))}
                      className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2"
                    />
                  </div>
                </div>
              )}
              {selectedCalc === 'footing' && (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-bold text-slate-500">Axial Load (kN)</label>
                    <input
                      type="number"
                      value={footingAxialLoad}
                      onChange={(e) => setFootingAxialLoad(Number(e.target.value))}
                      className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-500">SBC (kN/m²)</label>
                    <input
                      type="number"
                      value={footingSBC}
                      onChange={(e) => setFootingSBC(Number(e.target.value))}
                      className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2"
                    />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Results & Step-by-Step Derivation (7 cols) */}
        <div className="lg:col-span-7 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h2 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              Calculated Engineering Output
            </h2>
            <button
              onClick={() => handleCopy(`Calculation results for ${selectedCalc}`)}
              className="flex items-center gap-1 text-xs font-semibold text-slate-500 hover:text-orange-600 transition cursor-pointer"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          {/* 1. Concrete Output Cards */}
          {selectedCalc === 'concrete' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="rounded-xl bg-orange-50 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-900 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Wet Volume</div>
                  <div className="text-lg font-black text-orange-600 dark:text-orange-400 mt-0.5">
                    {wetVol.toFixed(2)} m³
                  </div>
                  <div className="text-[9px] text-slate-400">Dry: {dryVol.toFixed(2)} m³ (x1.54)</div>
                </div>
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Cement Required</div>
                  <div className="text-lg font-black text-slate-900 dark:text-white mt-0.5">
                    {concCementBags} Bags
                  </div>
                  <div className="text-[9px] text-slate-400">({Math.round(concCementKg)} kg)</div>
                </div>
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Sand (Fine Agg)</div>
                  <div className="text-lg font-black text-slate-900 dark:text-white mt-0.5">
                    {concSandCft} cft
                  </div>
                  <div className="text-[9px] text-slate-400">({concSandKg} kg)</div>
                </div>
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">20mm Aggregates</div>
                  <div className="text-lg font-black text-slate-900 dark:text-white mt-0.5">
                    {concAggCft} cft
                  </div>
                  <div className="text-[9px] text-slate-400">({concAggKg} kg)</div>
                </div>
              </div>

              {/* Step by step derivation box */}
              <div className="rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 p-4 text-xs font-mono space-y-2 text-slate-700 dark:text-slate-300">
                <div className="font-bold text-orange-600 dark:text-orange-400 font-sans text-xs">
                  Step-by-Step IS 456 / IS 10262 Calculation:
                </div>
                <div>1. Wet Volume = L × B × D = {concLength} × {concWidth} × {concDepth} = {wetVol.toFixed(3)} m³</div>
                <div>2. Dry Volume (void shrinkage +54%) = {wetVol.toFixed(3)} × 1.54 = {dryVol.toFixed(3)} m³</div>
                <div>3. {concGrade} Mix Ratio = {cRatio.c} : {cRatio.s} : {cRatio.a} (Sum = {cRatio.sum})</div>
                <div>4. Cement = ({cRatio.c} / {cRatio.sum}) × {dryVol.toFixed(2)} = {concCementVol.toFixed(3)} m³ × 1440 kg/m³ = {Math.round(concCementKg)} kg ({concCementBags} bags of 50kg)</div>
                <div>5. Sand = ({cRatio.s} / {cRatio.sum}) × {dryVol.toFixed(2)} = {concSandVol.toFixed(3)} m³ × 35.3147 = {concSandCft} cft</div>
                <div>6. Coarse Aggregate = ({cRatio.a} / {cRatio.sum}) × {dryVol.toFixed(2)} = {concAggVol.toFixed(3)} m³ × 35.3147 = {concAggCft} cft</div>
                <div>7. Mixing Water (w/c = 0.45) = {concWaterLiters} Litres</div>
              </div>
            </div>
          )}

          {/* 2. Brickwork Output Cards */}
          {selectedCalc === 'brick' && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-xl bg-orange-50 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-900 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Modular Bricks</div>
                  <div className="text-xl font-black text-orange-600 dark:text-orange-400 mt-0.5">
                    {totalBricks} Nos
                  </div>
                  <div className="text-[9px] text-slate-400">Includes 5% breakage</div>
                </div>
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Mortar Cement</div>
                  <div className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
                    {brickCementBags} Bags
                  </div>
                  <div className="text-[9px] text-slate-400">Ratio {brickMortarRatio}</div>
                </div>
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Mortar Sand</div>
                  <div className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
                    {brickSandCft} cft
                  </div>
                  <div className="text-[9px] text-slate-400">Zone II Coarse sand</div>
                </div>
              </div>
              <div className="rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 p-4 text-xs font-mono space-y-1.5 text-slate-700 dark:text-slate-300">
                <div className="font-bold text-orange-600 dark:text-orange-400 font-sans text-xs">
                  Brickwork Derivation (IS 2212):
                </div>
                <div>• Wall Volume = {brickWallLen}m × {brickWallHeight}m × {brickWallThick}m = {wallVol.toFixed(2)} m³</div>
                <div>• Volume of 1 brick with mortar = 0.20 × 0.10 × 0.10 = 0.002 m³</div>
                <div>• Number of bricks per m³ = 1 / 0.002 = 500 bricks/m³</div>
                <div>• Dry mortar factor = 1.33 (33% shrinkage allowance)</div>
              </div>
            </div>
          )}

          {/* 4. Steel Rebar Output Cards */}
          {selectedCalc === 'steel' && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-xl bg-orange-50 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-900 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Unit Weight</div>
                  <div className="text-xl font-black text-orange-600 dark:text-orange-400 mt-0.5">
                    {unitWeightKgM.toFixed(3)} kg/m
                  </div>
                  <div className="text-[9px] text-slate-400">D²/162 formula</div>
                </div>
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Total Weight</div>
                  <div className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
                    {Math.round(totalWeightKg)} kg
                  </div>
                  <div className="text-[9px] text-slate-400">{steelBarCount} bars of {steelLength}m</div>
                </div>
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Metric Tonnes</div>
                  <div className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
                    {totalWeightTonnes} MT
                  </div>
                  <div className="text-[9px] text-slate-400">Tender billing unit</div>
                </div>
              </div>

              <div className="rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 p-4 text-xs font-mono space-y-1.5 text-slate-700 dark:text-slate-300">
                <div className="font-bold text-orange-600 dark:text-orange-400 font-sans text-xs">
                  Rebar Theoretical Unit Weight Derivation (IS 1786):
                </div>
                <div>Density of steel = 7850 kg/m³</div>
                <div>Weight per meter = Volume × Density = (π/4 × D² × 10⁻⁶) × 7850 = (D² × 7850 × 3.14159) / (4 × 10⁶)</div>
                <div>= D² / 162.28 kg/m</div>
                <div>For {steelDia}mm bar: Weight = ({steelDia} × {steelDia}) / 162.28 = {unitWeightKgM.toFixed(3)} kg/m</div>
              </div>
            </div>
          )}

          {/* 5. Structural Beam Load Output */}
          {selectedCalc === 'beam' && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-xl bg-orange-50 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-900 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Factored Moment (Mu)</div>
                  <div className="text-xl font-black text-orange-600 dark:text-orange-400 mt-0.5">
                    {maxBendingMomentMu.toFixed(1)} kNm
                  </div>
                  <div className="text-[9px] text-slate-400">1.5 × (wL² / 8)</div>
                </div>
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Factored Shear (Vu)</div>
                  <div className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
                    {maxShearForceVu.toFixed(1)} kN
                  </div>
                  <div className="text-[9px] text-slate-400">1.5 × (wL / 2)</div>
                </div>
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Estimated Ast</div>
                  <div className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
                    {approxAstReq} mm²
                  </div>
                  <div className="text-[9px] text-slate-400">Tension rebar (Fe500)</div>
                </div>
              </div>

              <div className="rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 p-4 text-xs font-mono space-y-1.5 text-slate-700 dark:text-slate-300">
                <div className="font-bold text-orange-600 dark:text-orange-400 font-sans text-xs">
                  IS 456:2000 Limit State Analysis:
                </div>
                <div>• Beam Self Weight = ({beamWidth}/1000) × ({beamDepth}/1000) × 25 = {beamSelfWeightKnm.toFixed(2)} kN/m</div>
                <div>• Total Dead Load = {totalDeadLoadKnm.toFixed(2)} kN/m | Total Working Load w = {totalWorkingLoadKnm.toFixed(2)} kN/m</div>
                <div>• Factored Load wu = 1.5 × {totalWorkingLoadKnm.toFixed(2)} = {factoredLoadWu.toFixed(2)} kN/m</div>
                <div>• Mu = ({factoredLoadWu.toFixed(2)} × {beamSpan}²) / 8 = {maxBendingMomentMu.toFixed(2)} kNm</div>
                <div>• Vu = ({factoredLoadWu.toFixed(2)} × {beamSpan}) / 2 = {maxShearForceVu.toFixed(2)} kN</div>
              </div>
            </div>
          )}

          {/* 6. Column Load Output */}
          {selectedCalc === 'column' && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-xl bg-orange-50 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-900 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Factored Axial Pu</div>
                  <div className="text-xl font-black text-orange-600 dark:text-orange-400 mt-0.5">
                    {factoredPu.toFixed(0)} kN
                  </div>
                  <div className="text-[9px] text-slate-400">Working: {workingAxialLoadP.toFixed(0)} kN</div>
                </div>
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Gross Area Ag</div>
                  <div className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
                    {requiredAgMm2.toLocaleString()} mm²
                  </div>
                  <div className="text-[9px] text-slate-400">Assuming 1.2% rebar</div>
                </div>
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                  <div className="text-[10px] font-bold uppercase text-slate-500">Recommended Size</div>
                  <div className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
                    {recommendedSideMm}×{recommendedSideMm} mm
                  </div>
                  <div className="text-[9px] text-slate-400">Square Column section</div>
                </div>
              </div>
            </div>
          )}

          {/* General Fallback Display for other 6 calculators */}
          {!['concrete', 'brick', 'steel', 'beam', 'column'].includes(selectedCalc) && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl bg-orange-50 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-900 p-4">
                  <div className="text-xs font-bold uppercase text-slate-500">Primary Material / Quantity</div>
                  <div className="text-2xl font-black text-orange-600 dark:text-orange-400 mt-1">
                    {selectedCalc === 'staircase' && `${totalRisers} Risers (${actualRiser}mm)`}
                    {selectedCalc === 'excavation' && `${excavBankVol.toFixed(1)} m³ Bank Volume`}
                    {selectedCalc === 'footing' && `${reqFootingAreaSqM.toFixed(2)} m² (${footingSideM}m × ${footingSideM}m)`}
                    {selectedCalc === 'flooring' && `${totalTilesWithWastage} Tiles (${floorNetAreaSqM} m²)`}
                    {selectedCalc === 'paint' && `${paintLiters.toFixed(1)} Litres (${paintCoats} coats)`}
                    {selectedCalc === 'slab' && `${slabVol.toFixed(2)} m³ Concrete / ${slabSteelKg} kg Rebar`}
                    {selectedCalc === 'plaster' && `${plasterCementBags} Cement Bags / ${plasterSandCft} cft Sand`}
                  </div>
                  <div className="text-xs text-slate-400 mt-1">Calculated as per Indian Standard norms</div>
                </div>
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-4">
                  <div className="text-xs font-bold uppercase text-slate-500">Secondary Metric / Logistical Need</div>
                  <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                    {selectedCalc === 'staircase' && `Flight Angle: ${stairAngleDeg}° (Pass 25°-40°)`}
                    {selectedCalc === 'excavation' && `${dumperTrips} Tipper Truck Loads (10m³)`}
                    {selectedCalc === 'footing' && `Concrete Vol: ${footingVolCuM} m³`}
                    {selectedCalc === 'flooring' && `Mortar Bed: ${flooringCementBags} Bags Cement`}
                    {selectedCalc === 'paint' && `Effective Wall Area: ${netPaintArea} sq.m`}
                    {selectedCalc === 'slab' && `Aspect Ratio: ${(slabSpanLy / slabSpanLx).toFixed(2)} (Two-Way Slab)`}
                    {selectedCalc === 'plaster' && `Wet Mortar: ${(plasterWetVol * 1.33).toFixed(2)} m³`}
                  </div>
                  <div className="text-xs text-slate-400 mt-1">Includes standard wastage &amp; allowance</div>
                </div>
              </div>
            </div>
          )}

          {/* Statutory Educational Warning */}
          <div className="rounded-xl border border-amber-200 dark:border-amber-900/50 bg-amber-50/70 dark:bg-amber-950/20 p-3 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-2">
            <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5 text-amber-600" />
            <div>
              <span className="font-bold">Structural Safety Notice:</span> Calculations provided are preliminary engineering estimations intended for quantity surveying, educational demonstration, and initial architectural feasibility. Formal design must be verified in accordance with IS 456, IS 1893, and IS 800 with certified structural detailing before execution.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
