import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Plus,
  CheckCircle2,
  XCircle,
  HelpCircle,
  HardHat,
  Eye,
  FileCheck,
} from 'lucide-react';
import { SafetyCheckItem, SafetyIncident } from '../types/civil';
import { civilApi } from '../services/api';

interface SafetyProps {
  checklist: SafetyCheckItem[];
  incidents: SafetyIncident[];
  onCheckUpdated: () => void;
  onIncidentReported: () => void;
}

export const SafetyModule: React.FC<SafetyProps> = ({
  checklist,
  incidents,
  onCheckUpdated,
  onIncidentReported,
}) => {
  const [showIncidentModal, setShowIncidentModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'checklist' | 'incidents'>('checklist');

  // Form State
  const [incSeverity, setIncSeverity] = useState<'Near Miss' | 'Minor' | 'Moderate' | 'Severe'>('Near Miss');
  const [incType, setIncType] = useState('Working at Height');
  const [incLocation, setIncLocation] = useState('10th Floor Edge');
  const [incDesc, setIncDesc] = useState('');
  const [incAction, setIncAction] = useState('');

  const compliantCount = checklist.filter((c) => c.status === 'Compliant').length;
  const nonCompliantCount = checklist.filter((c) => c.status === 'Non-Compliant').length;
  const complianceScore = Math.round((compliantCount / (checklist.length || 1)) * 100);

  const handleToggleCheck = async (id: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'Compliant' ? 'Non-Compliant' : 'Compliant';
    await civilApi.updateSafetyCheck(id, nextStatus);
    onCheckUpdated();
  };

  const handleReportIncident = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!incDesc.trim()) return;

    await civilApi.reportSafetyIncident({
      projectId: 'proj-1',
      date: new Date().toISOString().split('T')[0],
      severity: incSeverity,
      type: incType,
      location: incLocation,
      description: incDesc,
      correctiveAction: incAction || 'Immediate safety toolbox briefing conducted.',
      status: 'Reported',
      reportedBy: 'Safety Officer Kuldeep Malik',
    });

    setShowIncidentModal(false);
    setIncDesc('');
    setIncAction('');
    onIncidentReported();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white">
              Environment, Health &amp; Site Safety (EHS)
            </h1>
            <span className="rounded-md bg-emerald-100 dark:bg-emerald-950/60 px-2 py-0.5 text-xs font-bold text-emerald-700 dark:text-emerald-400">
              IS 3786 / OSHA 1926
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Enforce mandatory 100% PPE adherence, daily scaffolding inspections, electrical trip tests, and incident corrective actions (CAR).
          </p>
        </div>

        <button
          onClick={() => setShowIncidentModal(true)}
          className="flex items-center gap-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white px-3.5 py-2 text-xs font-bold shadow-sm shadow-rose-600/30 cursor-pointer transition"
        >
          <AlertTriangle className="h-4 w-4" />
          <span>Report Safety Hazard</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Daily EHS Audit Score</div>
          <div className="text-3xl font-black text-emerald-600 dark:text-emerald-400 mt-1 flex items-baseline gap-2">
            <span>{complianceScore}%</span>
            <span className="text-xs font-semibold text-slate-500">
              ({compliantCount}/{checklist.length} Compliant)
            </span>
          </div>
          <div className="mt-2 w-full h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${complianceScore}%` }} />
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Lost Time Injury (LTI) Free</div>
          <div className="text-3xl font-black text-slate-900 dark:text-white mt-1">184 Safe Days</div>
          <div className="text-xs text-emerald-600 font-semibold mt-1">Target: 365 Days Milestone</div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Incident Counter</div>
          <div className="text-3xl font-black text-orange-600 dark:text-orange-400 mt-1">
            {incidents.length} Reported
          </div>
          <div className="text-xs text-slate-500 mt-1">All investigated with corrective action</div>
        </div>
      </div>

      {/* Tab Switcher */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-4 text-xs font-bold">
        <button
          onClick={() => setActiveTab('checklist')}
          className={`pb-2 transition cursor-pointer ${
            activeTab === 'checklist'
              ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          Daily Safety Inspection Protocol ({checklist.length})
        </button>
        <button
          onClick={() => setActiveTab('incidents')}
          className={`pb-2 transition cursor-pointer ${
            activeTab === 'incidents'
              ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          Safety Incidents &amp; Near-Miss Register ({incidents.length})
        </button>
      </div>

      {/* Tab 1: Checklist */}
      {activeTab === 'checklist' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {checklist.map((item) => {
              const isCompliant = item.status === 'Compliant';
              return (
                <div
                  key={item.id}
                  className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2 py-0.5 text-[10px] font-bold text-slate-700 dark:text-slate-300">
                        {item.category}
                      </span>
                      <span className="text-xs font-bold text-slate-900 dark:text-white">{item.item}</span>
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">{item.notes}</div>
                  </div>

                  <button
                    onClick={() => handleToggleCheck(item.id, item.status)}
                    className={`shrink-0 flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold transition cursor-pointer ${
                      isCompliant
                        ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800'
                        : 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-400 border border-rose-300 dark:border-rose-800'
                    }`}
                  >
                    {isCompliant ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                    <span>{item.status} (Click to toggle)</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Incidents */}
      {activeTab === 'incidents' && (
        <div className="space-y-3">
          {incidents.map((inc) => (
            <div
              key={inc.id}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span
                    className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase ${
                      inc.severity === 'Near Miss'
                        ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400'
                        : 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-400'
                    }`}
                  >
                    {inc.severity}
                  </span>
                  <span className="text-xs font-bold text-slate-900 dark:text-white">{inc.type}</span>
                </div>
                <span className="text-xs text-slate-400">{inc.date}</span>
              </div>

              <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Location: <span className="font-bold text-slate-900 dark:text-white">{inc.location}</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">{inc.description}</p>

              <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 p-3 text-xs border border-slate-100 dark:border-slate-800">
                <span className="font-bold text-slate-900 dark:text-white">Corrective Action Taken (CAR): </span>
                <span className="text-slate-600 dark:text-slate-300">{inc.correctiveAction}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Incident Modal */}
      {showIncidentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-4">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Log Site Safety Hazard or Near-Miss</h2>
            <form onSubmit={handleReportIncident} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-500">Severity</label>
                  <select
                    value={incSeverity}
                    onChange={(e) => setIncSeverity(e.target.value as any)}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  >
                    <option value="Near Miss">Near Miss</option>
                    <option value="Minor">Minor Injury</option>
                    <option value="Moderate">Moderate / First Aid</option>
                    <option value="Severe">Severe / LTI</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-500">Hazard Type</label>
                  <input
                    type="text"
                    value={incType}
                    onChange={(e) => setIncType(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-500">Exact Site Grid / Location</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Tower 2 8th Floor Balcony Edge"
                  value={incLocation}
                  onChange={(e) => setIncLocation(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-slate-500">Incident Description</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Describe what occurred, potential risks, workers involved..."
                  value={incDesc}
                  onChange={(e) => setIncDesc(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-slate-500">Corrective Action Taken</label>
                <input
                  type="text"
                  placeholder="Immediate barricade, harness re-anchoring..."
                  value={incAction}
                  onChange={(e) => setIncAction(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowIncidentModal(false)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-2 font-bold text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-rose-600 hover:bg-rose-700 text-white px-4 py-2 font-bold shadow-md shadow-rose-600/30"
                >
                  Submit Report
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
