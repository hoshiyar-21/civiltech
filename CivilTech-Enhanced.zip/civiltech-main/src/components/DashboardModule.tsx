import React from 'react';
import {
  TrendingUp,
  AlertTriangle,
  Building,
  CheckCircle2,
  Clock,
  DollarSign,
  Boxes,
  Users,
  HardHat,
  ShieldCheck,
  ChevronRight,
  Sparkles,
  ArrowUpRight,
  Activity,
  Layers,
} from 'lucide-react';
import { Project, ProjectTask, MaterialItem, LabourRecord } from '../types/civil';
import { NavModule } from './Sidebar';

interface DashboardProps {
  projects: Project[];
  tasks: ProjectTask[];
  materials: MaterialItem[];
  labour: LabourRecord[];
  selectedProjectId: string;
  onNavigate: (module: NavModule) => void;
}

export const DashboardModule: React.FC<DashboardProps> = ({
  projects,
  tasks,
  materials,
  labour,
  selectedProjectId,
  onNavigate,
}) => {
  const activeProject = projects.find((p) => p.id === selectedProjectId) || projects[0];

  // Global KPIs
  const totalProjects = projects.length;
  const activeProjects = projects.filter((p) => p.status === 'Active').length;
  const completedProjects = projects.filter((p) => p.status === 'Completed' || p.status === 'Under Review').length;

  const totalBudget = projects.reduce((acc, p) => acc + p.estimatedBudget, 0);
  const totalSpent = projects.reduce((acc, p) => acc + p.spentBudget, 0);
  const budgetUtilization = Math.round((totalSpent / (totalBudget || 1)) * 100);

  const lowStockMaterials = materials.filter((m) => m.currentStock <= m.minThreshold);
  const totalLabourToday = labour.reduce((acc, l) => acc + l.count, 0);

  // Currency Formatter
  const formatINR = (val: number) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(2)} Lakh`;
    return `₹${val.toLocaleString('en-IN')}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Active Project Status */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-navy-900 p-6 text-white shadow-xl border border-slate-800">
        <div className="absolute -right-10 -bottom-10 opacity-10 pointer-events-none">
          <Building className="h-64 w-64 text-orange-500" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="rounded-full bg-orange-500/20 px-2.5 py-0.5 text-xs font-bold text-orange-400 border border-orange-500/30">
                Active Site: {activeProject?.code}
              </span>
              <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-xs font-bold text-emerald-400 border border-emerald-500/30">
                Phase: {activeProject?.currentPhase}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">{activeProject?.name}</h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-300 max-w-2xl">{activeProject?.description}</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onNavigate('estimator')}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 px-4 py-2.5 text-xs font-bold text-white shadow-lg shadow-orange-600/30 hover:brightness-110 active:scale-95 transition cursor-pointer"
            >
              <Sparkles className="h-4 w-4" />
              <span>AI Cost Estimation</span>
            </button>
            <button
              onClick={() => onNavigate('bim_3d')}
              className="flex items-center gap-2 rounded-xl bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700 px-4 py-2.5 text-xs font-bold text-white transition cursor-pointer"
            >
              <Layers className="h-4 w-4 text-orange-400" />
              <span>Inspect 3D BIM</span>
            </button>
          </div>
        </div>

        {/* Mini progress bar inside banner */}
        <div className="mt-6 pt-4 border-t border-slate-700/60 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-3">
            <span className="text-slate-400">Target Completion:</span>
            <span className="font-semibold text-white">{activeProject?.targetCompletionDate}</span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">Total Built-up:</span>
            <span className="font-semibold text-white">{activeProject?.totalBuiltupAreaSqFt?.toLocaleString()} sq.ft</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-slate-400">Cumulative Progress:</span>
            <span className="font-bold text-orange-400 text-sm">{activeProject?.completionPercentage}%</span>
            <div className="w-32 h-2.5 rounded-full bg-slate-700 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-orange-500 to-amber-400 rounded-full transition-all duration-500"
                style={{ width: `${activeProject?.completionPercentage}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Projects Status */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm hover:shadow-md transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Portfolio Projects
            </span>
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
              <Building className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{totalProjects}</span>
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
              {activeProjects} Active
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
            <span>Completed: {completedProjects}</span>
            <button
              onClick={() => onNavigate('projects')}
              className="font-semibold text-orange-600 dark:text-orange-400 hover:underline flex items-center gap-0.5 cursor-pointer"
            >
              Details <ChevronRight className="h-3 w-3" />
            </button>
          </div>
        </div>

        {/* Card 2: Financial Utilization */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm hover:shadow-md transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Budget Utilization
            </span>
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
              <DollarSign className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{budgetUtilization}%</span>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              {formatINR(totalSpent)} spent
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
            <span>Total: {formatINR(totalBudget)}</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Under Budget</span>
          </div>
        </div>

        {/* Card 3: Material Stock & Critical Alert */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm hover:shadow-md transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Material Inventory
            </span>
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
              <Boxes className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{materials.length}</span>
            <span className="text-xs font-semibold text-slate-500">Tracked Items</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-slate-100 dark:border-slate-800">
            {lowStockMaterials.length > 0 ? (
              <span className="text-rose-600 dark:text-rose-400 font-bold flex items-center gap-1">
                <AlertTriangle className="h-3.5 w-3.5" /> {lowStockMaterials.length} Low Stock Alert
              </span>
            ) : (
              <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle2 className="h-3.5 w-3.5" /> Stock Healthy
              </span>
            )}
            <button
              onClick={() => onNavigate('materials')}
              className="font-semibold text-orange-600 dark:text-orange-400 hover:underline flex items-center gap-0.5 cursor-pointer"
            >
              Order <ChevronRight className="h-3 w-3" />
            </button>
          </div>
        </div>

        {/* Card 4: Daily Labour Force */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm hover:shadow-md transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Site Workforce Today
            </span>
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-orange-50 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400">
              <HardHat className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{totalLabourToday}</span>
            <span className="text-xs font-semibold text-slate-500">Workers Deployed</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
            <span>5 Skilled Trades</span>
            <button
              onClick={() => onNavigate('labour')}
              className="font-semibold text-orange-600 dark:text-orange-400 hover:underline flex items-center gap-0.5 cursor-pointer"
            >
              Muster Roll <ChevronRight className="h-3 w-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Middle Row: S-Curve Progress Chart & Live Site Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* S-Curve Chart (2 cols) */}
        <div className="lg:col-span-2 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-orange-600" />
                Construction Progress S-Curve (Earned Value &amp; Schedule)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Baseline Planned Schedule vs Actual Physical Completion %
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs font-semibold">
              <div className="flex items-center gap-1.5">
                <div className="h-2.5 w-2.5 rounded-full bg-slate-400" />
                <span className="text-slate-600 dark:text-slate-300">Planned Baseline</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="h-2.5 w-2.5 rounded-full bg-orange-600" />
                <span className="text-orange-600 dark:text-orange-400">Actual Earned</span>
              </div>
            </div>
          </div>

          {/* SVG S-Curve Graph */}
          <div className="relative h-64 w-full pt-4">
            <svg viewBox="0 0 600 200" className="w-full h-full overflow-visible">
              {/* Grid Lines */}
              <line x1="50" y1="20" x2="570" y2="20" stroke="currentColor" className="text-slate-200 dark:text-slate-800" strokeDasharray="3 3" />
              <line x1="50" y1="65" x2="570" y2="65" stroke="currentColor" className="text-slate-200 dark:text-slate-800" strokeDasharray="3 3" />
              <line x1="50" y1="110" x2="570" y2="110" stroke="currentColor" className="text-slate-200 dark:text-slate-800" strokeDasharray="3 3" />
              <line x1="50" y1="155" x2="570" y2="155" stroke="currentColor" className="text-slate-200 dark:text-slate-800" strokeDasharray="3 3" />

              {/* Y Axis Labels */}
              <text x="35" y="24" className="text-[10px] fill-slate-400" textAnchor="end">100%</text>
              <text x="35" y="69" className="text-[10px] fill-slate-400" textAnchor="end">75%</text>
              <text x="35" y="114" className="text-[10px] fill-slate-400" textAnchor="end">50%</text>
              <text x="35" y="159" className="text-[10px] fill-slate-400" textAnchor="end">25%</text>

              {/* Planned S-Curve (Smooth sigmoidal path) */}
              <path
                d="M 50 180 C 180 180, 240 120, 310 90 C 380 60, 480 30, 570 20"
                fill="none"
                stroke="#94a3b8"
                strokeWidth="2.5"
                strokeDasharray="4 4"
              />

              {/* Actual Completed Curve (up to current month: x=340, y=99) */}
              <path
                d="M 50 180 C 180 180, 230 125, 310 99"
                fill="none"
                stroke="#ea580c"
                strokeWidth="3.5"
              />

              {/* Current Date Dot */}
              <circle cx="310" cy="99" r="6" fill="#ea580c" className="animate-pulse" />
              <circle cx="310" cy="99" r="10" fill="#ea580c" opacity="0.25" />

              {/* Current Marker Text */}
              <rect x="250" y="60" width="120" height="28" rx="6" fill="#0f172a" />
              <text x="310" y="78" textAnchor="middle" className="text-[11px] font-bold fill-white">
                Oct: 45.0% Actual
              </text>

              {/* X Axis Months */}
              <text x="50" y="195" className="text-[10px] fill-slate-400" textAnchor="middle">Q1 '25</text>
              <text x="180" y="195" className="text-[10px] fill-slate-400" textAnchor="middle">Q3 '25</text>
              <text x="310" y="195" className="text-[10px] fill-orange-500 font-bold" textAnchor="middle">Current</text>
              <text x="440" y="195" className="text-[10px] fill-slate-400" textAnchor="middle">Q2 '26</text>
              <text x="570" y="195" className="text-[10px] fill-slate-400" textAnchor="middle">Completion</text>
            </svg>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-3 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-800 dark:text-slate-200">SPI (Schedule Performance Index):</span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400">0.97 (On Schedule)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-800 dark:text-slate-200">CPI (Cost Performance Index):</span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400">1.04 (Favorable)</span>
            </div>
          </div>
        </div>

        {/* Live Site Tasks & Deadlines (1 col) */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Clock className="h-5 w-5 text-orange-600" />
                Critical Path Tasks
              </h2>
              <span className="text-xs font-semibold text-slate-400">{tasks.length} Active</span>
            </div>

            <div className="space-y-3">
              {tasks.slice(0, 4).map((task) => (
                <div
                  key={task.id}
                  className="rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 p-3 hover:border-orange-500/40 transition"
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200 leading-snug">
                      {task.taskName}
                    </span>
                    <span
                      className={`shrink-0 rounded-md px-1.5 py-0.5 text-[10px] font-bold ${
                        task.status === 'Completed'
                          ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400'
                          : task.status === 'In Progress'
                          ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400'
                          : 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-400'
                      }`}
                    >
                      {task.status}
                    </span>
                  </div>

                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                    <span>Due: {task.endDate}</span>
                    <span className="font-bold text-slate-700 dark:text-slate-300">{task.progress}%</span>
                  </div>

                  <div className="mt-1 w-full h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                    <div
                      className="h-full bg-orange-600 rounded-full"
                      style={{ width: `${task.progress}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => onNavigate('projects')}
            className="mt-4 w-full rounded-xl border border-slate-200 dark:border-slate-700 py-2.5 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center gap-1.5 cursor-pointer transition"
          >
            <span>Open Full WBS Schedule</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Quick Launchpad to Core Engineering Modules */}
      <div>
        <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
          Engineering Tool Launchpad
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { title: 'Concrete Mix & Vol', icon: Layers, mod: 'calculators' as NavModule, desc: 'M20 / M25 design' },
            { title: 'Steel Rebar Calc', icon: Activity, mod: 'calculators' as NavModule, desc: 'D²/162 weight' },
            { title: 'IS Code AI Chat', icon: Sparkles, mod: 'ai_assistant' as NavModule, desc: 'IS 456 & 1893' },
            { title: 'Site Photo CV', icon: CheckCircle2, mod: 'progress' as NavModule, desc: 'Edge & rebar verify' },
            { title: 'Plot & Setback', icon: Building, mod: 'land_plot' as NavModule, desc: 'FAR & coverage' },
            { title: 'BOQ & Reports', icon: TrendingUp, mod: 'reports' as NavModule, desc: 'PDF / Excel export' },
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <button
                key={idx}
                onClick={() => onNavigate(item.mod)}
                className="group flex flex-col items-start p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-orange-500/50 hover:shadow-md transition text-left cursor-pointer"
              >
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-orange-50 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 group-hover:scale-110 transition-transform mb-2">
                  <Icon className="h-4 w-4" />
                </div>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-100">{item.title}</span>
                <span className="text-[10px] text-slate-400 mt-0.5">{item.desc}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
