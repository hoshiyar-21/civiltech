import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  Box,
  Layers,
  RotateCcw,
  Eye,
  Info,
  Sliders,
  CheckCircle,
  ShieldCheck,
  Maximize2,
  Compass,
  Sparkles,
} from 'lucide-react';

interface StructuralElement {
  id: string;
  name: string;
  category: 'Column' | 'Beam' | 'Floor Slab' | 'Footing' | 'Rebar Cage';
  level: string;
  dimensions: string;
  concreteGrade: string;
  rebarDetail: string;
  loadCapacity: string;
  castDate: string;
  status: 'Inspected & Passed' | 'Cured (28-day)' | 'Formwork In Place';
}

const SAMPLE_ELEMENTS: StructuralElement[] = [
  {
    id: 'elem-c1',
    name: 'Corner Column C-01 (Grid A1)',
    category: 'Column',
    level: 'Ground to Level 1',
    dimensions: '450 × 450 mm',
    concreteGrade: 'M35 High Strength',
    rebarDetail: '8 Nos 20mm Fe500D + 8mm links @ 125mm c/c',
    loadCapacity: '2,650 kN Factored Axial',
    castDate: '2026-08-14',
    status: 'Cured (28-day)',
  },
  {
    id: 'elem-b1',
    name: 'Primary Perimeter Beam B-12',
    category: 'Beam',
    level: 'Level 1 Framing',
    dimensions: '300 × 550 mm',
    concreteGrade: 'M30 Grade',
    rebarDetail: 'Top 3-T20, Bottom 4-T20 + 2-legged 8mm shear stirrups',
    loadCapacity: '185 kNm Moment Capacity',
    castDate: '2026-08-20',
    status: 'Cured (28-day)',
  },
  {
    id: 'elem-s1',
    name: 'Two-Way Suspended Slab S-04',
    category: 'Floor Slab',
    level: 'Level 1 Slab',
    dimensions: '5.2m × 4.8m × 150mm',
    concreteGrade: 'M25 Grade',
    rebarDetail: '10mm TMT @ 150mm c/c both ways + top chair bars',
    loadCapacity: '5.0 kN/m² Live Load Rating',
    castDate: '2026-08-21',
    status: 'Cured (28-day)',
  },
  {
    id: 'elem-f1',
    name: 'Isolated Stepped Footing F-02',
    category: 'Footing',
    level: 'Foundation Substructure',
    dimensions: '2.4m × 2.4m × 0.6m Depth',
    concreteGrade: 'M30 Concrete (IS 456)',
    rebarDetail: '12mm mesh @ 120mm c/c with 50mm nominal cover',
    loadCapacity: 'Safe Bearing Pressure: 285 kN/m²',
    castDate: '2026-06-10',
    status: 'Inspected & Passed',
  },
];

export const BimViewerModule: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [selectedElement, setSelectedElement] = useState<StructuralElement>(SAMPLE_ELEMENTS[0]);
  const [activeFloor, setActiveFloor] = useState<string>('all');
  const [renderMode, setRenderMode] = useState<'solid' | 'xray' | 'rebar' | 'wireframe'>('solid');
  const [autoRotate, setAutoRotate] = useState<boolean>(true);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Dimensions
    const width = container.clientWidth;
    const height = container.clientHeight || 450;

    // Three.js Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a); // dark slate/navy

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(18, 14, 22);
    camera.lookAt(0, 4, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(30, 30, 0xea580c, 0x334155);
    gridHelper.position.y = -0.01;
    scene.add(gridHelper);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffedd5, 1.2);
    dirLight.position.set(15, 25, 15);
    dirLight.castShadow = true;
    scene.add(dirLight);

    const fillLight = new THREE.DirectionalLight(0x93c5fd, 0.6);
    fillLight.position.set(-15, 10, -15);
    scene.add(fillLight);

    // Building Group
    const buildingGroup = new THREE.Group();
    scene.add(buildingGroup);

    // Materials based on mode
    const concreteMat = new THREE.MeshStandardMaterial({
      color: renderMode === 'xray' ? 0x94a3b8 : 0xd1d5db,
      transparent: renderMode === 'xray',
      opacity: renderMode === 'xray' ? 0.35 : 1.0,
      roughness: 0.6,
      metalness: 0.1,
      wireframe: renderMode === 'wireframe',
    });

    const orangeColumnMat = new THREE.MeshStandardMaterial({
      color: 0xea580c,
      transparent: renderMode === 'xray',
      opacity: renderMode === 'xray' ? 0.5 : 1.0,
      roughness: 0.4,
      metalness: 0.2,
      wireframe: renderMode === 'wireframe',
    });

    const rebarMat = new THREE.MeshStandardMaterial({
      color: 0xef4444, // high tensile red steel
      roughness: 0.2,
      metalness: 0.8,
    });

    // Procedural Construction Frame: 3 Floors, 4x4 Column Grid
    const numFloors = 4;
    const floorHeight = 3.2;
    const gridSpacing = 4.5;
    const colsX = 3;
    const colsZ = 3;

    // 1. Footings
    for (let x = 0; x < colsX; x++) {
      for (let z = 0; z < colsZ; z++) {
        const posX = (x - (colsX - 1) / 2) * gridSpacing;
        const posZ = (z - (colsZ - 1) / 2) * gridSpacing;

        // Footing box
        const footGeo = new THREE.BoxGeometry(1.6, 0.5, 1.6);
        const footMesh = new THREE.Mesh(footGeo, concreteMat);
        footMesh.position.set(posX, 0.25, posZ);
        footMesh.name = `footing_${x}_${z}`;
        buildingGroup.add(footMesh);
      }
    }

    // 2. Columns & Slabs for each floor
    for (let f = 0; f < numFloors; f++) {
      const floorY = f * floorHeight;

      // Filter floor if specified
      if (activeFloor !== 'all' && activeFloor !== `level_${f}`) {
        // Skip adding elements for hidden floors if isolated
      }

      // Columns
      for (let x = 0; x < colsX; x++) {
        for (let z = 0; z < colsZ; z++) {
          const posX = (x - (colsX - 1) / 2) * gridSpacing;
          const posZ = (z - (colsZ - 1) / 2) * gridSpacing;

          if (renderMode === 'rebar') {
            // Rebar Cage View: 4 corner vertical rebars + horizontal stirrup rings
            const barGeo = new THREE.CylinderGeometry(0.03, 0.03, floorHeight - 0.2, 8);
            const offsets = [
              [-0.15, -0.15],
              [0.15, -0.15],
              [-0.15, 0.15],
              [0.15, 0.15],
            ];
            offsets.forEach(([ox, oz]) => {
              const bar = new THREE.Mesh(barGeo, rebarMat);
              bar.position.set(posX + ox, floorY + floorHeight / 2, posZ + oz);
              buildingGroup.add(bar);
            });
          } else {
            // Solid Column
            const colGeo = new THREE.BoxGeometry(0.45, floorHeight, 0.45);
            const isHighlighted = x === 0 && z === 0;
            const colMesh = new THREE.Mesh(colGeo, isHighlighted ? orangeColumnMat : concreteMat);
            colMesh.position.set(posX, floorY + floorHeight / 2, posZ);
            buildingGroup.add(colMesh);
          }
        }
      }

      // Floor Slabs & Perimeter Beams
      const slabWidth = (colsX - 1) * gridSpacing + 1.2;
      const slabDepth = (colsZ - 1) * gridSpacing + 1.2;

      if (renderMode !== 'rebar') {
        const slabGeo = new THREE.BoxGeometry(slabWidth, 0.2, slabDepth);
        const slabMesh = new THREE.Mesh(slabGeo, concreteMat);
        slabMesh.position.set(0, floorY + floorHeight, 0);
        buildingGroup.add(slabMesh);
      }

      // Perimeter Beams (X & Z directions)
      const beamGeoX = new THREE.BoxGeometry(slabWidth, 0.35, 0.3);
      const beamGeoZ = new THREE.BoxGeometry(0.3, 0.35, slabDepth);

      const beam1 = new THREE.Mesh(beamGeoX, orangeColumnMat);
      beam1.position.set(0, floorY + floorHeight - 0.2, (colsZ - 1) * gridSpacing * 0.5);
      buildingGroup.add(beam1);

      const beam2 = new THREE.Mesh(beamGeoX, orangeColumnMat);
      beam2.position.set(0, floorY + floorHeight - 0.2, -(colsZ - 1) * gridSpacing * 0.5);
      buildingGroup.add(beam2);
    }

    // Interactive Drag to Rotate Camera
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let rotationAngle = 0.8;
    let cameraY = 14;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;

      rotationAngle -= deltaX * 0.008;
      cameraY = Math.max(3, Math.min(25, cameraY + deltaY * 0.05));
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const canvas = renderer.domElement;
    canvas.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    // Animation Loop
    let reqId: number;
    const animate = () => {
      reqId = requestAnimationFrame(animate);

      if (autoRotate && !isDragging) {
        rotationAngle += 0.003;
      }

      const radius = 26;
      camera.position.x = radius * Math.sin(rotationAngle);
      camera.position.z = radius * Math.cos(rotationAngle);
      camera.position.y = cameraY;
      camera.lookAt(0, 5, 0);

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight || 450;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(reqId);
      window.removeEventListener('resize', handleResize);
      canvas.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      renderer.dispose();
    };
  }, [activeFloor, renderMode, autoRotate]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white">
              BIM 3D Building &amp; Structural Viewer
            </h1>
            <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-xs font-bold text-orange-700 dark:text-orange-400">
              Three.js WebGL Engine
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Explore 3D reinforced concrete framing, inspect rebar cage detailing, isolate floor levels, and audit structural BIM attributes.
          </p>
        </div>

        {/* View mode toggle pills */}
        <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-1 rounded-xl text-xs font-bold">
          {[
            { id: 'solid', label: 'Solid BIM' },
            { id: 'xray', label: 'X-Ray Translucent' },
            { id: 'rebar', label: 'Rebar Steel Cage' },
            { id: 'wireframe', label: 'Wireframe' },
          ].map((m) => (
            <button
              key={m.id}
              onClick={() => setRenderMode(m.id as any)}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                renderMode === m.id
                  ? 'bg-orange-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: 3D Canvas (8 cols) & Structural Element Inspector (4 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Three.js Viewport */}
        <div className="lg:col-span-8 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-950 overflow-hidden shadow-xl flex flex-col">
          {/* Top Canvas Toolbar */}
          <div className="flex items-center justify-between p-3.5 bg-slate-900/90 border-b border-slate-800 text-xs text-white z-10">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-bold">Model: Apex Tower Core Framing (G+3 Storey)</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setAutoRotate(!autoRotate)}
                className={`rounded-lg px-2.5 py-1 text-[11px] font-bold border transition cursor-pointer ${
                  autoRotate
                    ? 'border-orange-500 bg-orange-500/20 text-orange-400'
                    : 'border-slate-700 bg-slate-800 text-slate-300'
                }`}
              >
                Auto-Orbit: {autoRotate ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>

          {/* Canvas Container */}
          <div
            ref={mountRef}
            className="relative w-full h-[450px] cursor-grab active:cursor-grabbing"
          />

          {/* Bottom Controls / Floor Selector */}
          <div className="flex flex-wrap items-center justify-between p-3 bg-slate-900 border-t border-slate-800 text-xs text-slate-300 gap-2">
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-slate-400">Levels:</span>
              {['all', 'level_0', 'level_1', 'level_2', 'level_3'].map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setActiveFloor(lvl)}
                  className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase transition cursor-pointer ${
                    activeFloor === lvl
                      ? 'bg-orange-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {lvl === 'all' ? 'All Floors' : lvl.replace('_', ' ')}
                </button>
              ))}
            </div>

            <div className="text-[10px] text-slate-400">
              Drag to Orbit • Scroll to Zoom
            </div>
          </div>
        </div>

        {/* Right Element Inspector Panel (4 cols) */}
        <div className="lg:col-span-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Box className="h-4 w-4 text-orange-600" />
              BIM Component Inspector
            </h2>
            <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-md">
              IFC Compatible
            </span>
          </div>

          {/* Component Quick Selector */}
          <div>
            <label className="text-[11px] font-bold text-slate-400">Select Structural Element</label>
            <div className="mt-1.5 space-y-2">
              {SAMPLE_ELEMENTS.map((elem) => {
                const isSelected = selectedElement.id === elem.id;
                return (
                  <button
                    key={elem.id}
                    onClick={() => setSelectedElement(elem)}
                    className={`w-full text-left p-2.5 rounded-xl border text-xs font-semibold transition cursor-pointer ${
                      isSelected
                        ? 'border-orange-500 bg-orange-50/50 dark:bg-orange-950/20 text-orange-700 dark:text-orange-400 ring-1 ring-orange-500'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold">{elem.name}</span>
                      <span className="text-[10px] text-slate-400">{elem.category}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Element Engineering Specifications */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 p-4 space-y-2.5 text-xs">
            <div className="font-black text-slate-900 dark:text-white text-sm">
              {selectedElement.name}
            </div>

            <div className="grid grid-cols-2 gap-2 text-slate-500 pt-1 border-t border-slate-200 dark:border-slate-700/60">
              <div>
                <span className="text-[10px] uppercase text-slate-400 block">Cross Section</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{selectedElement.dimensions}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase text-slate-400 block">Concrete Mix</span>
                <span className="font-bold text-orange-600 dark:text-orange-400">{selectedElement.concreteGrade}</span>
              </div>
            </div>

            <div className="pt-1 border-t border-slate-200 dark:border-slate-700/60">
              <span className="text-[10px] uppercase text-slate-400 block">Reinforcement Detailing</span>
              <span className="font-bold text-slate-800 dark:text-slate-200">{selectedElement.rebarDetail}</span>
            </div>

            <div className="pt-1 border-t border-slate-200 dark:border-slate-700/60">
              <span className="text-[10px] uppercase text-slate-400 block">Design Capacity (IS 456)</span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400">{selectedElement.loadCapacity}</span>
            </div>

            <div className="pt-1 border-t border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
              <span className="text-[10px] text-slate-400">Quality Status:</span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle className="h-3.5 w-3.5" /> {selectedElement.status}
              </span>
            </div>
          </div>

          <div className="rounded-xl bg-orange-50 dark:bg-orange-950/30 p-3 border border-orange-200 dark:border-orange-900/40 text-[11px] text-orange-800 dark:text-orange-300 flex items-start gap-2">
            <Sparkles className="h-4 w-4 shrink-0 mt-0.5 text-orange-600" />
            <div>
              <span className="font-bold">BIM / IFC Integration:</span> Model components correspond to IFC standard classes: <code className="bg-orange-100 dark:bg-orange-900/50 px-1 rounded">IfcColumn</code>, <code className="bg-orange-100 dark:bg-orange-900/50 px-1 rounded">IfcBeam</code>, <code className="bg-orange-100 dark:bg-orange-900/50 px-1 rounded">IfcSlab</code>, and <code className="bg-orange-100 dark:bg-orange-900/50 px-1 rounded">IfcReinforcingBar</code>.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
