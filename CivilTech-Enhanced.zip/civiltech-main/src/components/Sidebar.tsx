import React from 'react';
import {
  LayoutDashboard,
  Calculator,
  Binary,
  Bot,
  FolderKanban,
  Camera,
  Boxes,
  Users2,
  Compass,
  FileText,
  ShieldAlert,
  Box,
  FileSpreadsheet,
  GraduationCap,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
} from 'lucide-react';

export type NavModule =
  | 'dashboard'
  | 'estimator'
  | 'calculators'
  | 'ai_assistant'
  | 'projects'
  | 'progress'
  | 'materials'
  | 'labour'
  | 'land_plot'
  | 'documents'
  | 'safety'
  | 'bim_3d'
  | 'reports'
  | 'academic_docs';

interface SidebarProps {
  currentModule: NavModule;
  onSelectModule: (module: NavModule) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onToggleMobile: () => void;
}

interface NavItem {
  id: NavModule;
  label: string;
  badge?: string;
  icon: React.ElementType;
  category: 'Engineering & AI' | 'Management' | 'Analysis & 3D' | 'Academic & Reports';
}

const NAV_ITEMS: NavItem[] = [
  // Core Dash
  { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard, category: 'Engineering & AI' },
  { id: 'estimator', label: 'AI Cost Estimator & BOQ', badge: 'AI', icon: Calculator, category: 'Engineering & AI' },
  { id: 'calculators', label: 'Civil Engineering Calculators', badge: '13 In 1', icon: Binary, category: 'Engineering & AI' },
  { id: 'ai_assistant', label: 'IS Code AI Assistant', badge: 'Gemini', icon: Bot, category: 'Engineering & AI' },

  // Management
  { id: 'projects', label: 'Projects & WBS Tasks', icon: FolderKanban, category: 'Management' },
  { id: 'progress', label: 'Progress & Computer Vision', badge: 'CV', icon: Camera, category: 'Management' },
  { id: 'materials', label: 'Materials & Inventory', icon: Boxes, category: 'Management' },
  { id: 'labour', label: 'Labour & Equipment Fleet', icon: Users2, category: 'Management' },
  { id: 'safety', label: 'Safety & EHS Compliance', badge: 'IS 3786', icon: ShieldAlert, category: 'Management' },

  // Analysis & 3D
  { id: 'land_plot', label: 'Smart Land & Plot Analysis', icon: Compass, category: 'Analysis & 3D' },
  { id: 'documents', label: 'Document & Drawing Vault', icon: FileText, category: 'Analysis & 3D' },
  { id: 'bim_3d', label: 'BIM 3D Structural Viewer', badge: 'Three.js', icon: Box, category: 'Analysis & 3D' },

  // Academic & Reports
  { id: 'reports', label: 'Reports & Export Center', icon: FileSpreadsheet, category: 'Academic & Reports' },
  { id: 'academic_docs', label: 'Final Year Thesis & Viva', badge: '50 Q&A', icon: GraduationCap, category: 'Academic & Reports' },
];

export const Sidebar: React.FC<SidebarProps> = ({
  currentModule,
  onSelectModule,
  collapsed,
  onToggleCollapse,
  mobileOpen,
  onToggleMobile,
}) => {
  return (
    <>
      {/* Mobile Drawer Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden"
          onClick={onToggleMobile}
        />
      )}

      {/* Mobile Toggle Floating Button */}
      <button
        onClick={onToggleMobile}
        className="fixed bottom-4 right-4 z-50 flex h-12 w-12 items-center justify-center rounded-full bg-orange-600 text-white shadow-xl lg:hidden cursor-pointer active:scale-95 transition"
      >
        {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </button>

      {/* Sidebar Container */}
      <aside
        className={`fixed top-16 bottom-0 left-0 z-40 flex flex-col border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 transition-all duration-300 ease-in-out ${
          collapsed ? 'w-20' : 'w-64'
        } ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
      >
        {/* Navigation Item List */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = currentModule === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectModule(item.id);
                  if (mobileOpen) onToggleMobile();
                }}
                title={collapsed ? item.label : undefined}
                className={`group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-md shadow-orange-500/25'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/80 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                <Icon
                  className={`h-4 w-4 shrink-0 transition-transform group-hover:scale-110 ${
                    isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400 group-hover:text-orange-500'
                  }`}
                />
                {!collapsed && (
                  <span className="truncate text-left flex-1">{item.label}</span>
                )}
                {!collapsed && item.badge && (
                  <span
                    className={`ml-auto rounded-full px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-orange-100 dark:bg-orange-950/60 text-orange-700 dark:text-orange-300 border border-orange-200 dark:border-orange-900'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer Toggle */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 hidden lg:flex items-center justify-between">
          {!collapsed && (
            <div className="text-[11px] text-slate-400">
              <span className="font-bold text-slate-600 dark:text-slate-300">CivilTech v2.4</span>
              <p className="text-[10px]">Academic &amp; Industrial Edition</p>
            </div>
          )}
          <button
            onClick={onToggleCollapse}
            title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
            className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition cursor-pointer"
          >
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </button>
        </div>
      </aside>
    </>
  );
};
