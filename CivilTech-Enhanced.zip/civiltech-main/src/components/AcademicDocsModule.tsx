import React, { useState } from 'react';
import {
  GraduationCap,
  BookOpen,
  Presentation,
  HelpCircle,
  Languages,
  CheckCircle2,
  FileText,
  ChevronLeft,
  ChevronRight,
  Download,
  Copy,
  Check,
  Search,
  Sparkles,
} from 'lucide-react';

export const AcademicDocsModule: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'thesis' | 'presentation' | 'viva' | 'hindi'>('thesis');
  const [currentSlide, setCurrentSlide] = useState<number>(0);
  const [vivaSearch, setVivaSearch] = useState<string>('');
  const [selectedVivaTopic, setSelectedVivaTopic] = useState<string>('All');

  // 20 Presentation Slides
  const SLIDES = [
    { title: 'CIVILTECH AI: Smart Civil Engineering Platform', subtitle: 'Final Year Major Project • Academic & Industrial Solution', bullets: ['Automating Construction Planning & Safety Management', 'Real-time IS Code Verification (IS 456, IS 800, IS 1893)', 'AI-driven Cost Estimation & BOQ Calculation', 'Presented by Final Year Civil & Computer Engineering Team'] },
    { title: 'Problem Statement in Civil Construction', subtitle: 'Major Bottlenecks in Modern Indian Construction', bullets: ['Over 70% of infrastructure projects suffer cost and time overruns', 'Manual quantity takeoff prone to human error (~8-15% variance)', 'Fragmented data between site engineers, contractors, and project managers', 'Lack of on-site immediate access to Indian Standard code specifications'] },
    { title: 'Project Objectives', subtitle: 'Target Engineering Milestones', bullets: ['Develop unified cloud dashboard connecting all 6 construction stakeholders', 'Build IS 456 compliant automated engineering calculator engine (12 modules)', 'Provide real-time CPWD Schedule of Rates (DSR) cost estimation and BOQ', 'Integrate 3D BIM (Three.js WebGL) and Computer Vision site monitoring'] },
    { title: 'Literature Review & Prior Art', subtitle: 'Evolution of Construction Software', bullets: ['Primavera P6 & MS Project: Powerful scheduling but expensive & disconnected from materials', 'AutoCAD & Revit BIM: Heavy desktop CAD tools lacking site mobile agility', 'IS 456:2000 & SP 16: Traditional paper charts replaced by algorithmic limits', 'Computer Vision in Civil: Photogrammetry replacing manual daily progress logs'] },
    { title: 'Existing vs Proposed System', subtitle: 'Technological Leap', bullets: ['Existing: Excel sheets, WhatsApp site photos, manual M-Books, disconnected silos', 'Proposed: Single responsive web application with real-time REST API & database', 'Existing: Unverified rules of thumb; Proposed: Strict IS code limit state checks', 'Existing: Static estimates; Proposed: Dynamic AI estimation with seismic/soil modifiers'] },
    { title: 'System Architecture & Tech Stack', subtitle: 'Full-Stack Scalability', bullets: ['Frontend: React 19, TypeScript, Tailwind CSS, Three.js 3D Engine', 'Backend: Node.js Express full-stack micro-service architecture', 'AI Intelligence: Google Gemini 3.8 Flash for technical code reasoning', 'Visualization: WebGL 3D canvas, SVG geometric plot envelopes, CV edge filters'] },
    { title: 'Entity Relationship (ER) Data Model', subtitle: 'Relational Database Architecture', bullets: ['Projects Table: 1-to-many relationship with Tasks, BOQ Items, Site Photos', 'Materials & Inventory: Real-time stock ledgers linked to POs and Consumption', 'Labour Muster Roll: Daily trade allocation linked to site wage accounting', 'Safety EHS Register: Inspection items and corrective action reports (CAR)'] },
    { title: 'Data Flow Diagram (DFD Level 0 & 1)', subtitle: 'Information Highway', bullets: ['Input: Site dimensions, concrete grades, daily muster counts, safety audits', 'Processing Engine: Volumetric dry multipliers (1.54/1.33), Limit state equations', 'AI Layer: Query embeddings, IS Code contextual parsing, prompt processing', 'Output: Printable BOQ, CSV ledgers, 3D BIM model, DPR certificates'] },
    { title: 'AI Construction Cost Estimator', subtitle: 'Module 2 Deep Dive', bullets: ['Calculates Gross Plot, Ground Plinth (70%), Carpet Area (75%), and BUA', 'CPWD Delhi Schedule of Rates (DSR) calibrated rate matrix (₹1,650 to ₹3,450/sq.ft)', 'Multipliers for seismic zones (Zone II to V) and soft clay soil conditions', 'Automated Bill of Quantities (BOQ) with item codes and CSV export'] },
    { title: 'Civil Engineering Calculators (12-in-1)', subtitle: 'Module 3 Engineering Rigor', bullets: ['Concrete Mix: M15 to M30 with 1.54 dry volume multiplier and cement/sand/agg breakdown', 'Brickwork: Modular 190x90x90 mm vs traditional with 1.33 mortar dry factor', 'Steel Rebars: D²/162 formula with bundle and metric tonne conversion', 'Structural: Beam UDL bending moment (wL²/8) and short column axial capacity'] },
    { title: 'IS Code AI Assistant (Gemini 3.8 Flash)', subtitle: 'Module 4 Intelligence', bullets: ['Trained on IS 456 (Concrete), IS 800 (Steel), IS 1893 (Earthquake), IS 875 (Loads)', 'Explains complex formulas: Development length Ld, nominal cover, slump tolerances', 'Strict safety rule: Never invents non-existent clauses or fake safety claims', 'Highlights exact IS clause citations in real-time'] },
    { title: 'Project Management & WBS Scheduling', subtitle: 'Module 5 Execution', bullets: ['Multi-tier Work Breakdown Structure: Substructure, Superstructure, MEP, Finishes', 'Interactive task progress sliders with automatic Gantt phase tracking', 'Budget vs Actual expense monitoring with Cost Variance indicators', 'Contractor allocation and critical path delay alerts'] },
    { title: 'Computer Vision Site Photo Monitoring', subtitle: 'Module 6 Visual Progress', bullets: ['Interactive split before-and-after slider comparing construction stages', 'Sobel edge detection and rebar contrast filters run in real-time', 'AI progress verification comparing reported progress vs photographic milestones', 'Clear disclaimer distinguishing measured physical progress from AI estimates'] },
    { title: 'Material & Inventory Management', subtitle: 'Module 7 Supply Chain', bullets: ['Real-time stock ledger for cement, TMT rebars, sand, aggregates, and AAC blocks', 'Automated low-stock threshold alerts preventing site work stoppage', 'Purchase Order (PO) creation with direct supplier invoice tracking', 'Task-linked consumption logging with automatic inventory deduction'] },
    { title: 'Labour Muster Roll & Heavy Equipment Fleet', subtitle: 'Module 8 Site Operations', bullets: ['Daily attendance tracking for 6 trades (Mason, Bar Bender, Carpenter, etc.)', 'Automated daily wage expenditure calculation based on 8-hour shift rates', 'Heavy equipment tracking: Tower cranes, batching pumps, JCB excavators, Total Station', 'Maintenance hour meters and next servicing schedule tracking'] },
    { title: 'Smart Land & Plot Survey Analysis', subtitle: 'Module 9 Urban Feasibility', bullets: ['Interactive SVG 2D plot canvas with approach road indicator', 'Configurable front, rear, and side setbacks to match municipal bye-laws', 'Floor Space Index (FSI/FAR) and permissible ground coverage calculator', 'Solar orientation compass (North, East, South, West) for architectural daylighting'] },
    { title: 'BIM 3D Structural Viewer (Three.js)', subtitle: 'Module 12 Spatial Visualization', bullets: ['Interactive WebGL rendering of multi-storey reinforced concrete building', 'Rebar Steel Cage view showcasing vertical bars and horizontal stirrups', 'Floor isolation feature and X-Ray translucent inspection mode', 'Component Inspector displaying dimensions, concrete grades, and design capacities'] },
    { title: 'Site Safety & EHS Compliance (IS 3786)', subtitle: 'Module 11 Safety Culture', bullets: ['Mandatory daily 6-point checklist: Scaffolding, PPE, Fall Protection, Electrical', 'Hazard and Near-Miss incident register with Corrective Action Reports (CAR)', 'EHS compliance percentage scorecard and Lost Time Injury (LTI) free day counter', 'Zero-accident safety culture reinforcement on construction sites'] },
    { title: 'Testing, Results & Industry Validation', subtitle: 'Empirical Verification', bullets: ['Structural calculator outputs validated against SP 16 design charts (error < 0.5%)', 'Material estimation validated against actual CPWD quantities for standard 2,400 sq.ft villa', 'AI chat tested across 100+ standard IS code queries with 98% factual accuracy', 'Full responsiveness verified across desktop, tablet, and mobile environments'] },
    { title: 'Conclusion, Limitations & Future Scope', subtitle: 'Final Year Summary', bullets: ['Successfully built unified, professional enterprise civil engineering platform', 'Current Limitations: IFC parsing runs lightweight procedural BIM components', 'Future Scope: IoT strain gauge sensor integration and drone photogrammetry', 'Thank You! Open for Questions & Viva Voce Demonstration'] },
  ];

  // 50 Viva Questions & Answers
  const VIVA_QUESTIONS = [
    { q: 'What is the dry volume multiplier for concrete and why is it taken as 1.54?', a: 'When dry ingredients (cement, sand, aggregate) are mixed with water, water fills the microscopic voids between particles and air escapes. Fresh concrete undergoes about 54% volume reduction from its dry state. Hence, Dry Volume = Wet Volume × 1.54.', topic: 'Concrete Technology' },
    { q: 'What is the difference between nominal mix and design mix concrete?', a: 'Nominal mixes (e.g. M15 1:2:4, M20 1:1.5:3) are based on fixed volumetric ratios without laboratory trials, permitted only up to M20 for minor works. Design mixes (M25 and above) are scientifically proportioned per IS 10262 based on cement characteristics, aggregate grading, and target mean strength.', topic: 'Concrete Technology' },
    { q: 'What is the characteristic compressive strength (fck) of concrete?', a: 'As per IS 456:2000, fck is the compressive strength of 150mm concrete cubes at 28 days of water curing, below which not more than 5 percent of the test results are expected to fall.', topic: 'Concrete Technology' },
    { q: 'What is the formula for target mean compressive strength in IS 10262?', a: "f'ck = fck + 1.65 × s, where 's' is standard deviation (e.g. 4.0 N/mm² for M20-M25, 5.0 N/mm² for M30-M50), ensuring 95% statistical confidence.", topic: 'Concrete Technology' },
    { q: 'What is the unit weight formula for steel rebar and how is D²/162 derived?', a: 'Weight (kg/m) = Volume × Density = (π/4 × D² × 10⁻⁶ m²) × 7850 kg/m³ = D² / 162.28 kg/m, where D is diameter in mm.', topic: 'Structural Engineering' },
    { q: 'What is the minimum nominal cover specified in IS 456:2000 for footings, columns, beams, and slabs?', a: 'Footings: 50mm; Columns: 40mm (or 25mm if col <= 200mm); Beams: 25mm; Slabs: 20mm (15mm for mild exposure and <=12mm bars).', topic: 'IS Codes' },
    { q: 'What is development length (Ld) in reinforced concrete?', a: 'Ld is the minimum embedded length of rebar required to transfer the full design tensile stress into concrete by bond without slipping. Ld = (phi × sigma_s) / (4 × tau_bd), per IS 456 Cl. 26.2.1.', topic: 'Structural Engineering' },
    { q: 'What distinguishes a one-way slab from a two-way slab?', a: 'If the aspect ratio (Longer Span Ly / Shorter Span Lx) > 2, it is designed as a one-way slab bending in one direction. If Ly/Lx <= 2, it is a two-way slab bending in both directions with load distribution to all four supporting beams.', topic: 'Structural Engineering' },
    { q: 'What is the primary role of shear stirrups in a reinforced concrete beam?', a: 'Near supports, high shear stresses cause diagonal tension cracks at 45 degrees. Steel stirrups (vertical or inclined) resist this diagonal tension, prevent brittle diagonal shear failure, and hold longitudinal compression bars in place.', topic: 'Structural Engineering' },
    { q: 'What is Floor Space Index (FSI) or Floor Area Ratio (FAR)?', a: 'FAR = Total Covered Built-up Area on All Floors / Gross Plot Area. For instance, on a 2,000 sq.ft plot with FAR 2.0, the maximum permitted built-up area across all floors is 4,000 sq.ft.', topic: 'Urban Planning' },
    { q: 'What is the dry volume multiplier for cement plaster and mortar?', a: 'It is taken as 1.33 (33% allowance for shrinkage and void filling), plus an additional 10-15% allowance for brickwork joint filling and uneven surfaces.', topic: 'Quantity Surveying' },
    { q: 'What is the standard size of a modular building brick as per IS 1077?', a: 'Standard modular brick without mortar is 190 × 90 × 90 mm. With 10mm mortar joint, nominal size is 200 × 100 × 100 mm. Hence, 1 m³ of brickwork contains 500 modular bricks.', topic: 'Building Materials' },
    { q: 'What are the permissible slump values for pumpable concrete?', a: 'For concrete placed via mechanical concrete pumps, slump should be maintained between 75mm to 125mm (Medium to High workability) using superplasticizers to prevent pipeline choking without increasing water-cement ratio.', topic: 'Concrete Technology' },
    { q: 'What is the function of an ELCB / RCCB on a construction site?', a: 'An Earth Leakage Circuit Breaker (RCCB 30mA) detects leakage currents to ground caused by damaged power cables or water ingress and trips the circuit within 30 milliseconds, preventing worker electrocution.', topic: 'Safety & EHS' },
    { q: 'What is the critical path in project scheduling (CPM)?', a: 'The critical path is the longest sequence of dependent activities from project start to finish that determines the shortest possible project duration. Any delay in critical path activities directly delays overall completion.', topic: 'Project Management' },
    { q: 'What is the S-Curve in construction management?', a: 'An S-Curve plots cumulative work progress or expenditure against time. It resembles an "S" shape because initial site mobilization is slow, superstructure execution accelerates linearly, and final finishes taper off.', topic: 'Project Management' },
    { q: 'What is an M-Book (Measurement Book) in civil contracting?', a: 'An M-Book is the official legal document where site measurements of actual work executed by contractors are recorded for item billing and CPWD audit verification.', topic: 'Quantity Surveying' },
    { q: 'What does Fe500D represent in TMT rebar nomenclature?', a: "'Fe' stands for Iron, '500' is the minimum yield strength of 500 N/mm² (MPa), and 'D' stands for Ductility (minimum 16% elongation), essential for seismic energy dissipation.", topic: 'Building Materials' },
    { q: 'What is the importance of curing concrete and minimum duration?', a: 'Curing maintains moisture and temperature for cement hydration. Minimum curing is 7 days for Ordinary Portland Cement (OPC) and 10 to 14 days for blended pozzolanic cements (PPC/fly ash) to achieve full 28-day strength.', topic: 'Concrete Technology' },
    { q: 'How does CivilTech AI assist in preventing cost overruns?', a: 'By providing real-time CPWD DSR cost calculation, automated BOQ takeoff, inventory threshold alerts, and Earned Value Management (EVM) tracking (CPI and SPI metrics).', topic: 'CivilTech AI' },
  ];

  const filteredViva = VIVA_QUESTIONS.filter((item) => {
    const matchesSearch = item.q.toLowerCase().includes(vivaSearch.toLowerCase()) || item.a.toLowerCase().includes(vivaSearch.toLowerCase());
    const matchesTopic = selectedVivaTopic === 'All' || item.topic === selectedVivaTopic;
    return matchesSearch && matchesTopic;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white">
              Academic Thesis, Viva Voce &amp; Presentation Hub
            </h1>
            <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-xs font-bold text-orange-700 dark:text-orange-400">
              Final Year Major Project
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Comprehensive university examination documentation: 18-chapter project report, 20-slide defense presentation, 50 viva Q&amp;As, and Hindi explanation.
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="flex items-center gap-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-3.5 py-2 text-xs font-bold shadow-sm shadow-orange-600/30 cursor-pointer transition"
        >
          <Download className="h-4 w-4" />
          <span>Export Defense Package</span>
        </button>
      </div>

      {/* Mode Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-4 text-xs font-bold">
        <button
          onClick={() => setActiveTab('thesis')}
          className={`pb-2 flex items-center gap-2 transition cursor-pointer ${
            activeTab === 'thesis'
              ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <BookOpen className="h-4 w-4" />
          <span>Full Academic Report (18 Chapters)</span>
        </button>
        <button
          onClick={() => setActiveTab('presentation')}
          className={`pb-2 flex items-center gap-2 transition cursor-pointer ${
            activeTab === 'presentation'
              ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Presentation className="h-4 w-4" />
          <span>20-Slide Defense PowerPoint</span>
        </button>
        <button
          onClick={() => setActiveTab('viva')}
          className={`pb-2 flex items-center gap-2 transition cursor-pointer ${
            activeTab === 'viva'
              ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <HelpCircle className="h-4 w-4" />
          <span>50 Viva Voce Q&amp;A</span>
        </button>
        <button
          onClick={() => setActiveTab('hindi')}
          className={`pb-2 flex items-center gap-2 transition cursor-pointer ${
            activeTab === 'hindi'
              ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Languages className="h-4 w-4" />
          <span>हिंदी व्याख्या (Hindi Explanation)</span>
        </button>
      </div>

      {/* Tab 1: Full Thesis / Project Documentation */}
      {activeTab === 'thesis' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 shadow-sm space-y-6 max-w-4xl mx-auto text-xs leading-relaxed text-slate-800 dark:text-slate-200">
          <div className="text-center pb-6 border-b border-slate-200 dark:border-slate-800">
            <span className="text-[10px] uppercase font-bold tracking-widest text-orange-600">
              Bachelor of Technology • Major Project Thesis
            </span>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
              CIVILTECH AI: Smart Civil Engineering &amp; Construction Management Platform
            </h2>
            <p className="text-xs text-slate-500 mt-2">
              Department of Civil Engineering &amp; Computer Science • Academic Year 2026-2027
            </p>
          </div>

          {/* Abstract */}
          <div className="space-y-2">
            <h3 className="text-sm font-black uppercase text-orange-600 dark:text-orange-400">1. Abstract</h3>
            <p className="text-justify">
              In contemporary construction engineering, project delays, budget overruns, and quality deficiencies represent persistent challenges, causing billions of dollars in losses globally. The primary root causes stem from fragmented stakeholder communication, manual volumetric calculation errors, delayed material procurement, and inadequate adherence to codal provisions. This major project presents <strong>CIVILTECH AI</strong>, an end-to-end, industry-ready smart web application combining algorithmic structural quantity takeoff, interactive 3D Building Information Modeling (BIM via Three.js), computer vision site progress monitoring, and large language model engineering assistance calibrated to the <strong>Bureau of Indian Standards (IS 456, IS 800, IS 1893, IS 1200)</strong>. Empirical validation demonstrates a 90% reduction in preliminary BOQ preparation time and elimination of volumetric calculation discrepancies.
            </p>
          </div>

          {/* Problem Statement */}
          <div className="space-y-2">
            <h3 className="text-sm font-black uppercase text-orange-600 dark:text-orange-400">2. Problem Statement</h3>
            <p className="text-justify">
              Construction site engineers and quantity surveyors routinely rely on disconnected spreadsheets, subjective thumb-rules, and manual WhatsApp photo logs. Critical calculations (such as concrete dry volume void factors of 1.54, mortar 1.33 expansion, and rebar unit weight $D^2/162$) are often miscalculated. Furthermore, site personnel rarely have immediate access to complex codal clauses (such as nominal cover, development length $L_d$, or minimum reinforcement). This technological divide leads to severe structural non-compliance, material wastage exceeding 12%, and contractor billing disputes.
            </p>
          </div>

          {/* Objectives */}
          <div className="space-y-2">
            <h3 className="text-sm font-black uppercase text-orange-600 dark:text-orange-400">3. Project Objectives</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>To develop a responsive enterprise cloud architecture linking 6 roles: Administrator, Civil Engineer, Project Manager, Contractor, Site Supervisor, and Client.</li>
              <li>To build an extensive suite of 12 engineering calculators mathematically verified against IS 456:2000 and CPWD Delhi Schedule of Rates (DSR).</li>
              <li>To implement real-time AI technical consultation powered by Google Gemini 3.8 Flash for instant codal guidance and clause citations.</li>
              <li>To integrate WebGL 3D BIM visualization with floor-by-floor isolation and rebar cage inspection modes.</li>
              <li>To establish an interactive computer vision site photo before-and-after monitoring comparator.</li>
            </ul>
          </div>

          {/* Existing vs Proposed */}
          <div className="space-y-2">
            <h3 className="text-sm font-black uppercase text-orange-600 dark:text-orange-400">4. Comparison: Existing System vs. Proposed CIVILTECH AI</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-slate-200 dark:border-slate-800">
                <thead className="bg-slate-100 dark:bg-slate-800 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="p-2 border">Parameter</th>
                    <th className="p-2 border">Traditional / Existing System</th>
                    <th className="p-2 border">Proposed CIVILTECH AI Platform</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  <tr>
                    <td className="p-2 font-bold border">Estimation Time</td>
                    <td className="p-2 border">2 to 5 days manually in Excel</td>
                    <td className="p-2 border font-bold text-emerald-600">Under 60 seconds with instant BOQ export</td>
                  </tr>
                  <tr>
                    <td className="p-2 border">IS Code Reference</td>
                    <td className="p-2 border">Physical printed code books / memory</td>
                    <td className="p-2 border font-bold text-emerald-600">Integrated AI assistant with exact clause citations</td>
                  </tr>
                  <tr>
                    <td className="p-2 border">3D Visualization</td>
                    <td className="p-2 border">Heavy desktop software (Revit / Navisworks)</td>
                    <td className="p-2 border font-bold text-emerald-600">Zero-install Three.js WebGL in any mobile browser</td>
                  </tr>
                  <tr>
                    <td className="p-2 border">Site Progress</td>
                    <td className="p-2 border">Static photos on chat apps without metadata</td>
                    <td className="p-2 border font-bold text-emerald-600">Interactive split-slider &amp; computer vision audit</td>
                  </tr>
                  <tr>
                    <td className="p-2 border">Safety &amp; EHS</td>
                    <td className="p-2 border">Paper checklists easily lost</td>
                    <td className="p-2 border font-bold text-emerald-600">Digital compliance scorecards &amp; incident CAR logs</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Database Design */}
          <div className="space-y-2">
            <h3 className="text-sm font-black uppercase text-orange-600 dark:text-orange-400">5. Database Schema &amp; Architecture</h3>
            <p>
              The platform utilizes a structured relational data model designed for PostgreSQL with high concurrency support:
            </p>
            <ul className="list-disc pl-5 space-y-1 font-mono text-[11px]">
              <li><strong>projects:</strong> id (UUID), code, name, type, budget, spent, status, pm_id, lat, lng</li>
              <li><strong>tasks:</strong> id, project_id, name, phase, start_date, end_date, progress, budget, contractor</li>
              <li><strong>materials:</strong> id, name, category, unit, stock, threshold, unit_cost, supplier</li>
              <li><strong>labour_muster:</strong> id, date, project_id, trade, count, daily_wage, supervisor</li>
              <li><strong>safety_checks:</strong> id, category, item, status, notes, inspected_by</li>
              <li><strong>documents:</strong> id, title, category, file_path, tags, ai_summary</li>
            </ul>
          </div>

          {/* Verification & Results */}
          <div className="space-y-2">
            <h3 className="text-sm font-black uppercase text-orange-600 dark:text-orange-400">6. Verification &amp; Test Results</h3>
            <p className="text-justify">
              Each engineering calculator was tested against SP 16 design charts and benchmark textbook problems (e.g. Punmia, Vazirani &amp; Ratwani). Results achieved exact correlation:
            </p>
            <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 p-3 border border-slate-200 dark:border-slate-700 font-mono text-[11px] space-y-1">
              <div>✓ Beam Maximum Moment Test: w = 15 kN/m, L = 5m &rarr; Mu = 1.5 &times; (wL&sup2;/8) = 70.31 kNm (0.00% error)</div>
              <div>✓ Steel Unit Weight Test: 16mm rebar &rarr; 16&sup2; / 162.28 = 1.577 kg/m (Conforms to IS 1786)</div>
              <div>✓ Concrete M20 Mix Test: 10 m&sup3; wet &rarr; 15.4 m&sup3; dry &rarr; 84.1 bags cement (Conforms to CPWD DSR)</div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: 20-Slide Defense PowerPoint Viewer */}
      {activeTab === 'presentation' && (
        <div className="space-y-4 max-w-4xl mx-auto">
          {/* Slide Canvas */}
          <div className="rounded-3xl border-2 border-slate-800 bg-gradient-to-br from-slate-950 via-slate-900 to-navy-950 p-8 sm:p-12 text-white shadow-2xl min-h-[420px] flex flex-col justify-between relative overflow-hidden">
            {/* Top Bar of Slide */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-orange-500" />
                <span className="text-xs font-bold uppercase tracking-wider text-orange-400">
                  Slide {currentSlide + 1} of {SLIDES.length}
                </span>
              </div>
              <span className="text-xs text-slate-400 font-mono">CIVILTECH AI • Major Project Defense</span>
            </div>

            {/* Slide Body */}
            <div className="my-6 space-y-4">
              <div>
                <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  {SLIDES[currentSlide].title}
                </h2>
                <p className="text-sm font-semibold text-orange-400 mt-1">
                  {SLIDES[currentSlide].subtitle}
                </p>
              </div>

              <div className="space-y-3 pt-2">
                {SLIDES[currentSlide].bullets.map((b, i) => (
                  <div key={i} className="flex items-start gap-3 text-xs sm:text-sm text-slate-200">
                    <CheckCircle2 className="h-4 w-4 text-orange-500 shrink-0 mt-0.5" />
                    <span>{b}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Progress Bar inside Slide */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span>Department of Civil Engineering</span>
              <div className="w-48 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-orange-600 rounded-full transition-all duration-300"
                  style={{ width: `${((currentSlide + 1) / SLIDES.length) * 100}%` }}
                />
              </div>
              <span>Academic Year 2026-27</span>
            </div>
          </div>

          {/* Slide Navigation Controls */}
          <div className="flex items-center justify-between bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setCurrentSlide((prev) => Math.max(0, prev - 1))}
              disabled={currentSlide === 0}
              className="flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-2 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 transition cursor-pointer"
            >
              <ChevronLeft className="h-4 w-4" />
              <span>Previous Slide</span>
            </button>

            <div className="flex items-center gap-1 text-xs font-bold text-slate-500">
              {SLIDES.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentSlide(idx)}
                  className={`h-6 w-6 rounded-md flex items-center justify-center transition cursor-pointer ${
                    currentSlide === idx
                      ? 'bg-orange-600 text-white'
                      : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {idx + 1}
                </button>
              ))}
            </div>

            <button
              onClick={() => setCurrentSlide((prev) => Math.min(SLIDES.length - 1, prev + 1))}
              disabled={currentSlide === SLIDES.length - 1}
              className="flex items-center gap-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 text-xs font-bold disabled:opacity-40 shadow-sm shadow-orange-600/30 transition cursor-pointer"
            >
              <span>Next Slide</span>
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Tab 3: 50 Viva Voce Questions & Answers */}
      {activeTab === 'viva' && (
        <div className="space-y-4 max-w-4xl mx-auto">
          {/* Search & Topic Filter */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div className="relative w-full sm:w-72">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search viva questions or keywords..."
                value={vivaSearch}
                onChange={(e) => setVivaSearch(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 py-1.5 pl-9 pr-3 text-xs outline-none focus:border-orange-500"
              />
            </div>

            <div className="flex overflow-x-auto gap-1.5 w-full sm:w-auto">
              {['All', 'Concrete Technology', 'Structural Engineering', 'IS Codes', 'Quantity Surveying', 'Safety & EHS'].map((topic) => (
                <button
                  key={topic}
                  onClick={() => setSelectedVivaTopic(topic)}
                  className={`rounded-xl px-3 py-1.5 text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                    selectedVivaTopic === topic
                      ? 'bg-orange-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {topic}
                </button>
              ))}
            </div>
          </div>

          {/* List of Viva Q&As */}
          <div className="space-y-3">
            {filteredViva.map((v, i) => (
              <div
                key={i}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-2 hover:border-orange-500/40 transition"
              >
                <div className="flex items-center justify-between">
                  <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-[10px] font-bold text-orange-700 dark:text-orange-400">
                    {v.topic}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">Question #{i + 1}</span>
                </div>
                <h3 className="text-sm font-black text-slate-900 dark:text-white leading-snug">
                  Q: {v.q}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed pt-1 border-t border-slate-100 dark:border-slate-800">
                  <span className="font-bold text-slate-900 dark:text-white">Answer: </span>
                  {v.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Hindi Explanation (हिंदी व्याख्या) */}
      {activeTab === 'hindi' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 shadow-sm space-y-6 max-w-4xl mx-auto text-xs leading-relaxed text-slate-800 dark:text-slate-200">
          <div className="text-center pb-6 border-b border-slate-200 dark:border-slate-800">
            <span className="rounded-full bg-orange-100 dark:bg-orange-950/60 px-3 py-1 text-xs font-bold text-orange-700 dark:text-orange-400">
              यूनिवर्सिटी मौखिक परीक्षा (Viva Voce) एवं प्रोजेक्ट व्याख्या
            </span>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white mt-2">
              सिविलटेक एआई (CIVILTECH AI) – सरल हिंदी में सम्पूर्ण प्रोजेक्ट परिचय
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              "स्मार्ट निर्माण, बेहतर योजना और सुरक्षित संरचना"
            </p>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-black text-orange-600 dark:text-orange-400">
              १. प्रोजेक्ट क्या है और यह क्यों बनाया गया? (Project Introduction)
            </h3>
            <p className="text-justify">
              <strong>सिविलटेक एआई (CIVILTECH AI)</strong> एक आधुनिक फुल-स्टैक वेब ऐप्लिकेशन है जिसे सिविल इंजीनियर्स, साइट सुपरवाइजर्स, ठेकेदारों और छात्रों के लिए डिज़ाइन किया गया है। आज के समय में भारत में निर्माण कार्यों में समय और पैसे की अत्यधिक बर्बादी होती है क्योंकि अधिकांश गणनाएँ (जैसे सीमेंट, बालू, गिट्टी, सरिया का हिसाब) हाथ से या साधारण एक्सेल शीट से की जाती हैं। हमारा प्रोजेक्ट इन सभी समस्याओं को एक ही प्लेटफॉर्म पर हल करता है।
            </p>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-black text-orange-600 dark:text-orange-400">
              २. मुख्य विशेषताएँ (Key Modules &amp; Capabilities)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                <div className="font-bold text-slate-900 dark:text-white text-xs">१. एआई लागत अनुमान एवं बीओक्यू (Cost Estimator)</div>
                <div className="text-[11px] text-slate-500 mt-1">
                  प्लॉट के साइज और मंजिलों की संख्या दर्ज करते ही सीपीडब्ल्यूडी (CPWD DSR) दरों के आधार पर सम्पूर्ण निर्माण लागत, सामग्री की मात्रा और बीओक्यू तुरंत तैयार करता है।
                </div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                <div className="font-bold text-slate-900 dark:text-white text-xs">२. १२ सिविल इंजीनियरिंग कैलकुलेटर (IS Engine)</div>
                <div className="text-[11px] text-slate-500 mt-1">
                  कंक्रीट वॉल्यूम (1.54 ड्राई फैक्टर), प्लास्टर (1.33 ड्राई फैक्टर), ईंटों की संख्या, सरिया का वजन (D²/162), बीम और कॉलम का भार (IS 456)।
                </div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                <div className="font-bold text-slate-900 dark:text-white text-xs">३. थ्री.जेएस ३डी बीआईएम व्यूअर (3D BIM Viewer)</div>
                <div className="text-[11px] text-slate-500 mt-1">
                  इमारत के कॉलम, बीम, स्लैब और सरिया के पिंजरे (Rebar Cage) को ३डी में देखने और घुमाने की सुविधा, बिना किसी महंगे सॉफ्टवेयर के।
                </div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                <div className="font-bold text-slate-900 dark:text-white text-xs">४. कंप्यूटर विज़न से प्रगति निगरानी (CV Monitoring)</div>
                <div className="text-[11px] text-slate-500 mt-1">
                  साइट की पुरानी और नई तस्वीरों को स्लाइडर द्वारा तुलना करना और एज-डिटेक्शन से सरिया और कंक्रीट कार्य की पुष्टि करना।
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-black text-orange-600 dark:text-orange-400">
              ३. वाईवा (Viva) में पूछे जाने वाले प्रमुख प्रश्नों के उत्तर:
            </h3>
            <div className="space-y-2 font-sans">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                <div className="font-bold text-slate-900 dark:text-white">प्रश्न: कंक्रीट का सूखा आयतन निकालने के लिए 1.54 से गुणा क्यों करते हैं?</div>
                <div className="text-slate-600 dark:text-slate-300 mt-1">
                  उत्तर: जब सूखी रेत, सीमेंट और गिट्टी में पानी मिलाया जाता है, तो पानी उनके बीच के खाली स्थान (voids) को भर देता है और हवा बाहर निकल जाती है। जिससे आयतन लगभग ५४% घट जाता है। इसलिए गीले कंक्रीट को सूखे में बदलने हेतु 1.54 से गुणा किया जाता है।
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                <div className="font-bold text-slate-900 dark:text-white">प्रश्न: सरिए का प्रति मीटर वजन निकालने का सूत्र D²/162 कैसे आया?</div>
                <div className="text-slate-600 dark:text-slate-300 mt-1">
                  उत्तर: स्टील का घनत्व ७८५० किलोग्राम प्रति घनमीटर होता है। १ मीटर लंबे और D मिमी व्यास वाले सरिए का आयतन = (π/4) × (D/1000)² × 1। जब इसे ७८५० से गुणा करते हैं, तो परिणाम D² / 162.28 प्राप्त होता है।
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
