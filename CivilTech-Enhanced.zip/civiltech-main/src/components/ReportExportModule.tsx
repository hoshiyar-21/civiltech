import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Printer,
  FileText,
  CheckCircle,
  Building,
  Calendar,
  Layers,
  Sparkles,
} from 'lucide-react';
import { Project, MaterialItem, LabourRecord, SafetyIncident } from '../types/civil';

interface ReportProps {
  projects: Project[];
  materials: MaterialItem[];
  labour: LabourRecord[];
  incidents: SafetyIncident[];
  selectedProjectId: string;
}

export const ReportExportModule: React.FC<ReportProps> = ({
  projects,
  materials,
  labour,
  incidents,
  selectedProjectId,
}) => {
  const [selectedReportType, setSelectedReportType] = useState<string>('dpr');
  const activeProject = projects.find((p) => p.id === selectedProjectId) || projects[0];

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    let csv = '';
    if (selectedReportType === 'dpr') {
      csv = 'Trade,Head Count,Daily Wage Rate (INR),Total Cost (INR),Supervisor,Remarks\n' +
        labour.map((l) => `"${l.trade}",${l.count},${l.dailyWage},${l.count * l.dailyWage},"${l.supervisor}","${l.remarks}"`).join('\n');
    } else if (selectedReportType === 'materials') {
      csv = 'Material,Category,Current Stock,Unit,Threshold,Unit Cost (INR),Total Value (INR),Supplier\n' +
        materials.map((m) => `"${m.name}","${m.category}",${m.currentStock},"${m.unit}",${m.minThreshold},${m.unitCost},${m.currentStock * m.unitCost},"${m.supplier}"`).join('\n');
    } else {
      csv = 'Project Name,Code,Budget (INR),Spent (INR),Progress %,Status,Manager\n' +
        projects.map((p) => `"${p.name}","${p.code}",${p.estimatedBudget},${p.spentBudget},${p.completionPercentage},"${p.status}","${p.projectManager}"`).join('\n');
    }

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `CivilTech_${selectedReportType}_Report_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white">
              Report Generation &amp; Export Center
            </h1>
            <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-xs font-bold text-orange-700 dark:text-orange-400">
              PDF &amp; Excel Reports
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Generate formal Daily Progress Reports (DPR), IS 516 concrete cube test certificates, inventory valuations, and BOQs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 shadow-sm cursor-pointer transition"
          >
            <Download className="h-4 w-4 text-orange-600" />
            <span>Export CSV / Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-3.5 py-2 text-xs font-bold shadow-sm shadow-orange-600/30 cursor-pointer transition"
          >
            <Printer className="h-4 w-4" />
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>

      {/* Report Type Selector Tabs */}
      <div className="flex overflow-x-auto gap-2 pb-1 scrollbar-thin">
        {[
          { id: 'dpr', label: 'Daily Progress Report (DPR)', icon: FileText },
          { id: 'cube', label: 'Concrete Cube Test Certificate (IS 516)', icon: Layers },
          { id: 'materials', label: 'Material Stock & Inventory Audit', icon: FileSpreadsheet },
          { id: 'safety', label: 'Site EHS & Safety Compliance Audit', icon: CheckCircle },
          { id: 'projects', label: 'Project Portfolio Executive Summary', icon: Building },
        ].map((r) => {
          const Icon = r.icon;
          const isActive = selectedReportType === r.id;
          return (
            <button
              key={r.id}
              onClick={() => setSelectedReportType(r.id)}
              className={`flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold transition cursor-pointer ${
                isActive
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-100'
              }`}
            >
              <Icon className="h-4 w-4 text-orange-500" />
              <span>{r.label}</span>
            </button>
          );
        })}
      </div>

      {/* Printable Sheet Viewport (Standard ISO Paper Canvas) */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 shadow-md max-w-4xl mx-auto space-y-6 print:p-0 print:border-none print:shadow-none text-slate-900 dark:text-white">
        {/* Document Header with Logo and ISO details */}
        <div className="flex items-start justify-between pb-4 border-b-2 border-slate-900 dark:border-slate-700">
          <div>
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-orange-600 text-white flex items-center justify-center font-black text-sm">
                CT
              </div>
              <div>
                <h2 className="text-xl font-black tracking-tight text-slate-900 dark:text-white">
                  CIVILTECH AI CONSTRUCTION CORP
                </h2>
                <p className="text-[10px] text-slate-500 tracking-wider font-semibold uppercase">
                  Consulting Civil &amp; Structural Engineers • ISO 9001:2015 &amp; ISO 45001 Certified
                </p>
              </div>
            </div>
          </div>

          <div className="text-right text-xs">
            <div className="font-bold text-orange-600 dark:text-orange-400">
              DOC REF: CT-REP-{Date.now().toString().slice(-6)}
            </div>
            <div className="text-slate-500 text-[11px] mt-0.5">
              Date: {new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
            </div>
            <div className="text-slate-400 text-[10px]">Site: {activeProject?.code}</div>
          </div>
        </div>

        {/* Project Meta Details Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Project Name</span>
            <span className="font-bold text-slate-900 dark:text-white truncate block">{activeProject?.name}</span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Location</span>
            <span className="font-bold text-slate-900 dark:text-white truncate block">{activeProject?.location}</span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Resident Engineer</span>
            <span className="font-bold text-slate-900 dark:text-white truncate block">{activeProject?.projectManager}</span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Current Phase</span>
            <span className="font-bold text-orange-600 dark:text-orange-400 truncate block">{activeProject?.currentPhase}</span>
          </div>
        </div>

        {/* Report Content based on Selected Type */}

        {/* 1. DPR */}
        {selectedReportType === 'dpr' && (
          <div className="space-y-4">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-900 dark:text-white pb-1 border-b">
              1. Daily Labour Muster Roll &amp; Work Execution
            </h3>
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-800 text-[10px] font-bold uppercase text-slate-500">
                <tr>
                  <th className="p-2">Trade</th>
                  <th className="p-2">Count</th>
                  <th className="p-2">Daily Rate</th>
                  <th className="p-2">Amount (₹)</th>
                  <th className="p-2">Task Executed Today</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {labour.map((l) => (
                  <tr key={l.id}>
                    <td className="p-2 font-bold">{l.trade}</td>
                    <td className="p-2">{l.count} Nos</td>
                    <td className="p-2">₹{l.dailyWage}</td>
                    <td className="p-2 font-bold text-orange-600">₹{(l.count * l.dailyWage).toLocaleString()}</td>
                    <td className="p-2 text-slate-500">{l.remarks}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* 2. Concrete Cube Test */}
        {selectedReportType === 'cube' && (
          <div className="space-y-4">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-900 dark:text-white pb-1 border-b">
              Concrete Compressive Strength Test Certificate (IS 516:2021)
            </h3>
            <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1">
              <div>Specimen Size: <span className="font-bold">150 × 150 × 150 mm Cubes</span></div>
              <div>Concrete Grade: <span className="font-bold">M35 Design Mix (IS 10262)</span></div>
              <div>Curing Tank Temperature: <span className="font-bold">27°C ± 2°C (Water Cured)</span></div>
            </div>

            <table className="w-full text-left text-xs mt-3">
              <thead className="bg-slate-100 dark:bg-slate-800 text-[10px] font-bold uppercase text-slate-500">
                <tr>
                  <th className="p-2">Cube ID</th>
                  <th className="p-2">Date Cast</th>
                  <th className="p-2">Age (Days)</th>
                  <th className="p-2">Crushing Load (kN)</th>
                  <th className="p-2">Compressive Strength (N/mm²)</th>
                  <th className="p-2">Target Strength</th>
                  <th className="p-2">Verdict</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                <tr>
                  <td className="p-2 font-bold">CB-10-A</td>
                  <td className="p-2">03-Oct-2026</td>
                  <td className="p-2">28 Days</td>
                  <td className="p-2">945 kN</td>
                  <td className="p-2 font-bold text-emerald-600">42.0 MPa</td>
                  <td className="p-2">35.0 MPa</td>
                  <td className="p-2 font-bold text-emerald-600">PASS</td>
                </tr>
                <tr>
                  <td className="p-2 font-bold">CB-10-B</td>
                  <td className="p-2">03-Oct-2026</td>
                  <td className="p-2">28 Days</td>
                  <td className="p-2">910 kN</td>
                  <td className="p-2 font-bold text-emerald-600">40.4 MPa</td>
                  <td className="p-2">35.0 MPa</td>
                  <td className="p-2 font-bold text-emerald-600">PASS</td>
                </tr>
                <tr>
                  <td className="p-2 font-bold">CB-10-C</td>
                  <td className="p-2">03-Oct-2026</td>
                  <td className="p-2">28 Days</td>
                  <td className="p-2">930 kN</td>
                  <td className="p-2 font-bold text-emerald-600">41.3 MPa</td>
                  <td className="p-2">35.0 MPa</td>
                  <td className="p-2 font-bold text-emerald-600">PASS</td>
                </tr>
              </tbody>
            </table>
            <div className="rounded-xl bg-emerald-50 dark:bg-emerald-950/30 p-3 text-xs text-emerald-800 dark:text-emerald-300 border border-emerald-200 font-semibold">
              Average 28-day characteristic strength achieved: 41.2 N/mm² (exceeds required 35.0 N/mm² + 1.65s target mean strength).
            </div>
          </div>
        )}

        {/* 3. Materials Audit */}
        {selectedReportType === 'materials' && (
          <div className="space-y-4">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-900 dark:text-white pb-1 border-b">
              Site Material Physical Stock &amp; Valuation
            </h3>
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-800 text-[10px] font-bold uppercase text-slate-500">
                <tr>
                  <th className="p-2">Material</th>
                  <th className="p-2">Stock Level</th>
                  <th className="p-2">Unit Rate (₹)</th>
                  <th className="p-2">Valuation (₹)</th>
                  <th className="p-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {materials.map((m) => (
                  <tr key={m.id}>
                    <td className="p-2 font-bold">{m.name}</td>
                    <td className="p-2">{m.currentStock} {m.unit}</td>
                    <td className="p-2">₹{m.unitCost}</td>
                    <td className="p-2 font-bold text-slate-900 dark:text-white">
                      ₹{(m.currentStock * m.unitCost).toLocaleString()}
                    </td>
                    <td className="p-2">
                      <span className="text-emerald-600 font-bold">Audited</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* 4. Safety & General Fallback */}
        {selectedReportType === 'safety' && (
          <div className="space-y-4">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-900 dark:text-white pb-1 border-b">
              Site Environment, Health &amp; Safety Compliance (IS 3786)
            </h3>
            <div className="space-y-2 text-xs">
              <div>Total Incidents Logged: <span className="font-bold">{incidents.length} Near-Miss / Minor</span></div>
              <div>Fatalities / Major LTI: <span className="font-bold text-emerald-600">0 (Zero Accident Culture)</span></div>
              <div>Toolbox Talks Conducted: <span className="font-bold">Every Morning 08:00 AM</span></div>
            </div>
          </div>
        )}

        {/* Signatures & Certification Stamp Footer */}
        <div className="pt-8 border-t border-slate-200 dark:border-slate-800 flex justify-between items-end text-xs">
          <div className="space-y-4 text-center">
            <div className="h-10 border-b border-slate-400 w-44 mx-auto" />
            <div className="font-bold text-slate-800 dark:text-slate-200">Site Quality QA/QC In-Charge</div>
            <div className="text-[10px] text-slate-400">Er. Ankit Verma (B.Tech Civil)</div>
          </div>

          <div className="rounded-full h-20 w-20 border-2 border-dashed border-orange-500/60 flex items-center justify-center text-center p-1 text-[9px] font-bold text-orange-600 uppercase tracking-tighter">
            Approved For Construction (AFC)
          </div>

          <div className="space-y-4 text-center">
            <div className="h-10 border-b border-slate-400 w-44 mx-auto" />
            <div className="font-bold text-slate-800 dark:text-slate-200">Resident Project Manager</div>
            <div className="text-[10px] text-slate-400">{activeProject?.projectManager}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
