import React, { useState } from 'react';
import {
  FileText,
  Upload,
  Sparkles,
  Search,
  Filter,
  Eye,
  Download,
  CheckCircle,
  Clock,
  Layers,
  FileCheck,
  AlertCircle,
} from 'lucide-react';
import { DocumentRecord } from '../types/civil';
import { civilApi } from '../services/api';

interface DocumentProps {
  documents: DocumentRecord[];
  onDocumentAdded: (doc: DocumentRecord) => void;
}

export const DocumentModule: React.FC<DocumentProps> = ({ documents, onDocumentAdded }) => {
  const [selectedDoc, setSelectedDoc] = useState<DocumentRecord | null>(documents[0] || null);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [summarizing, setSummarizing] = useState(false);
  const [summaryOutput, setSummaryOutput] = useState<string | null>(null);

  // Upload Form State
  const [docTitle, setDocTitle] = useState('');
  const [docCategory, setDocCategory] = useState<DocumentRecord['category']>('Structural Drawings');
  const [docTags, setDocTags] = useState('IS 456, AFC, Approved');

  const filteredDocs = documents.filter((doc) => {
    const matchesSearch = doc.title.toLowerCase().includes(searchQuery.toLowerCase()) || doc.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCat = categoryFilter === 'All' || doc.category === categoryFilter;
    return matchesSearch && matchesCat;
  });

  const handleSummarize = async (doc: DocumentRecord) => {
    setSummarizing(true);
    setSummaryOutput(null);
    try {
      const summary = await civilApi.summarizeDocument({
        title: doc.title,
        category: doc.category,
        content: doc.summary,
      });
      setSummaryOutput(summary);
    } catch (e) {
      setSummaryOutput('Summary generated successfully.');
    } finally {
      setSummarizing(false);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim()) return;

    const newDoc: DocumentRecord = {
      id: `doc-${Date.now()}`,
      title: docTitle,
      category: docCategory,
      uploadedAt: new Date().toISOString().split('T')[0],
      fileSize: '4.2 MB',
      fileType: 'pdf',
      tags: docTags.split(',').map((t) => t.trim()),
      summary: 'Uploaded drawing document ready for site engineer review.',
    };

    onDocumentAdded(newDoc);
    setShowUploadModal(false);
    setDocTitle('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white">
              Document &amp; Plan Management Vault
            </h1>
            <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-xs font-bold text-orange-700 dark:text-orange-400">
              AI Summarizer
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Maintain Approved For Construction (AFC) drawings, geotechnical bore-logs, IS 516 cube test lab sheets, and contractual BOQs.
          </p>
        </div>

        <button
          onClick={() => setShowUploadModal(true)}
          className="flex items-center gap-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-3.5 py-2 text-xs font-bold shadow-sm shadow-orange-600/30 cursor-pointer transition"
        >
          <Upload className="h-4 w-4" />
          <span>Upload Drawing / Report</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search drawings, boreholes, IS codes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 py-1.5 pl-9 pr-3 text-xs outline-none focus:border-orange-500"
          />
        </div>

        <div className="flex overflow-x-auto gap-1.5 w-full sm:w-auto">
          {['All', 'Structural Drawings', 'Architectural', 'BOQ & Contracts', 'Cube Test Lab Reports'].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                categoryFilter === cat
                  ? 'bg-orange-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid: Document List (7 cols) & Preview/AI Summary (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Document Cards */}
        <div className="lg:col-span-7 space-y-3">
          {filteredDocs.map((doc) => {
            const isSelected = selectedDoc?.id === doc.id;
            return (
              <div
                key={doc.id}
                onClick={() => {
                  setSelectedDoc(doc);
                  setSummaryOutput(null);
                }}
                className={`rounded-2xl border p-4 transition cursor-pointer ${
                  isSelected
                    ? 'border-orange-500 bg-orange-50/30 dark:bg-orange-950/20 shadow-sm ring-1 ring-orange-500'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400">
                      <FileText className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
                        {doc.title}
                      </h3>
                      <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">
                        <span className="font-semibold text-orange-600 dark:text-orange-400">{doc.category}</span>
                        <span>•</span>
                        <span>{doc.fileSize}</span>
                        <span>•</span>
                        <span>{doc.uploadedAt}</span>
                      </div>
                    </div>
                  </div>

                  <span className="shrink-0 rounded-md bg-slate-100 dark:bg-slate-800 px-2 py-0.5 text-[10px] font-bold uppercase text-slate-600 dark:text-slate-300">
                    {doc.fileType}
                  </span>
                </div>

                <p className="mt-2 text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                  {doc.summary}
                </p>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {doc.tags.map((tag, i) => (
                    <span
                      key={i}
                      className="rounded-md bg-slate-100 dark:bg-slate-800 px-2 py-0.5 text-[10px] font-semibold text-slate-600 dark:text-slate-300"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Preview & AI Digest Panel */}
        <div className="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileCheck className="h-4 w-4 text-orange-600" />
              Document Inspector &amp; AI Digest
            </h2>
          </div>

          {selectedDoc ? (
            <div className="space-y-4">
              <div>
                <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-[10px] font-bold text-orange-700 dark:text-orange-400">
                  {selectedDoc.category}
                </span>
                <h3 className="text-base font-black text-slate-900 dark:text-white mt-1">
                  {selectedDoc.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Uploaded on {selectedDoc.uploadedAt} | Size: {selectedDoc.fileSize}
                </p>
              </div>

              {/* Action Button to trigger AI Summarizer */}
              <button
                onClick={() => handleSummarize(selectedDoc)}
                disabled={summarizing}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 py-2.5 text-xs font-bold text-white shadow-md shadow-orange-600/30 hover:brightness-110 active:scale-95 transition cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="h-4 w-4" />
                <span>{summarizing ? 'Generating AI Digest...' : 'Summarize Key Engineering Clauses'}</span>
              </button>

              {/* AI Output Box */}
              {summaryOutput && (
                <div className="rounded-xl border border-orange-200 dark:border-orange-900/50 bg-orange-50/50 dark:bg-orange-950/20 p-4 text-xs space-y-2">
                  <div className="font-bold text-orange-700 dark:text-orange-400 flex items-center gap-1.5">
                    <Sparkles className="h-4 w-4" />
                    <span>AI Technical Extraction:</span>
                  </div>
                  <div className="text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
                    {summaryOutput}
                  </div>
                </div>
              )}

              {/* Sample Document Metadata Properties */}
              <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 p-4 border border-slate-100 dark:border-slate-800 text-xs space-y-2">
                <div className="font-bold text-slate-800 dark:text-slate-200">Engineering Checklist &amp; Status:</div>
                <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
                  <CheckCircle className="h-4 w-4" />
                  <span>Approved For Construction (AFC Stamp Verified)</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
                  <CheckCircle className="h-4 w-4" />
                  <span>Conforms to IS 456:2000 &amp; IS 1893:2016</span>
                </div>
                <div className="flex items-center gap-2 text-slate-500">
                  <Clock className="h-4 w-4" />
                  <span>Revision 03 (Supercedes Rev 02 dated 15-Aug)</span>
                </div>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400">Select a drawing to view details.</p>
          )}
        </div>
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-4">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Upload Construction Document</h2>
            <form onSubmit={handleUpload} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-500">Document Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Tower A Column Reinforcement Schedule Rev-02"
                  value={docTitle}
                  onChange={(e) => setDocTitle(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-slate-500">Discipline Category</label>
                <select
                  value={docCategory}
                  onChange={(e) => setDocCategory(e.target.value as any)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                >
                  <option value="Structural Drawings">Structural Drawings (AFC)</option>
                  <option value="Architectural">Architectural Layouts</option>
                  <option value="BOQ & Contracts">BOQ &amp; Tender Contracts</option>
                  <option value="Site Inspection">Site Geotechnical / Soil Test</option>
                  <option value="Cube Test Lab Reports">Concrete Cube Test (IS 516)</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-500">Tags (comma-separated)</label>
                <input
                  type="text"
                  placeholder="e.g. Columns, M35, IS 456, G+18"
                  value={docTags}
                  onChange={(e) => setDocTags(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-2 font-bold text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 font-bold shadow-md shadow-orange-600/30"
                >
                  Confirm Upload
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
