import React, { useState } from 'react';
import {
  Compass,
  MapPin,
  Ruler,
  Building,
  Sun,
  ShieldAlert,
  Sliders,
  Layers,
  Info,
} from 'lucide-react';

export const LandPlotModule: React.FC = () => {
  const [plotLength, setPlotLength] = useState<number>(60); // ft
  const [plotWidth, setPlotWidth] = useState<number>(40); // ft
  const [frontSetback, setFrontSetback] = useState<number>(10); // ft
  const [rearSetback, setRearSetback] = useState<number>(8); // ft
  const [leftSetback, setLeftSetback] = useState<number>(5); // ft
  const [rightSetback, setRightSetback] = useState<number>(5); // ft
  const [permissibleFAR, setPermissibleFAR] = useState<number>(2.0); // Floor Area Ratio
  const [maxGroundCoverage, setMaxGroundCoverage] = useState<number>(65); // 65%
  const [plotOrientation, setPlotOrientation] = useState<'North' | 'East' | 'South' | 'West'>('North');
  const [unit, setUnit] = useState<'feet' | 'meters'>('feet');

  // Calculations
  const grossPlotAreaSqFt = plotLength * plotWidth;
  const grossPlotAreaSqM = Math.round(grossPlotAreaSqFt * 0.092903);
  const plotAreaAcres = (grossPlotAreaSqFt / 43560).toFixed(3);
  const plotAreaGunthas = (grossPlotAreaSqFt / 1089).toFixed(2); // 1 Guntha = 1089 sq.ft

  // Buildable Envelope Dimensions
  const buildableLength = Math.max(0, plotLength - (frontSetback + rearSetback));
  const buildableWidth = Math.max(0, plotWidth - (leftSetback + rightSetback));
  const buildableFootprintSqFt = buildableLength * buildableWidth;
  const actualCoveragePercent = ((buildableFootprintSqFt / (grossPlotAreaSqFt || 1)) * 100).toFixed(1);

  // Maximum Permissible BUA under FAR
  const maxPermissibleBuiltupArea = Math.round(grossPlotAreaSqFt * permissibleFAR);
  const potentialFloors = buildableFootprintSqFt > 0 ? (maxPermissibleBuiltupArea / buildableFootprintSqFt).toFixed(1) : '0';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-black text-slate-900 dark:text-white">
            Smart Land &amp; Plot Survey Analysis
          </h1>
          <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-xs font-bold text-orange-700 dark:text-orange-400">
            FAR &amp; Setback Engine
          </span>
        </div>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Interactive plot geometry, municipal setback zoning, permissible ground coverage %, and Floor Space Index (FSI/FAR) optimization.
        </p>
      </div>

      {/* Grid: Inputs (5 cols) & Canvas Diagram + Metrics (7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Inputs Panel */}
        <div className="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Ruler className="h-4 w-4 text-orange-600" />
              Plot Dimensions &amp; Authority Rules
            </h2>
            <div className="flex items-center text-xs font-semibold bg-slate-100 dark:bg-slate-800 rounded-lg p-0.5">
              <button
                onClick={() => setUnit('feet')}
                className={`px-2 py-1 rounded-md transition ${unit === 'feet' ? 'bg-white dark:bg-slate-700 text-orange-600 font-bold' : 'text-slate-500'}`}
              >
                Feet
              </button>
              <button
                onClick={() => setUnit('meters')}
                className={`px-2 py-1 rounded-md transition ${unit === 'meters' ? 'bg-white dark:bg-slate-700 text-orange-600 font-bold' : 'text-slate-500'}`}
              >
                Meters
              </button>
            </div>
          </div>

          {/* Plot Length & Width */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-bold text-slate-500">Plot Length (Depth)</label>
              <input
                type="number"
                value={plotLength}
                onChange={(e) => setPlotLength(Math.max(10, Number(e.target.value)))}
                className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 text-xs font-bold"
              />
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-500">Plot Width (Road Frontage)</label>
              <input
                type="number"
                value={plotWidth}
                onChange={(e) => setPlotWidth(Math.max(10, Number(e.target.value)))}
                className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 text-xs font-bold"
              />
            </div>
          </div>

          {/* Municipal Setbacks */}
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
              Authority Mandatory Setbacks ({unit})
            </span>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-400">Front Setback (Road)</label>
                <input
                  type="number"
                  value={frontSetback}
                  onChange={(e) => setFrontSetback(Number(e.target.value))}
                  className="mt-0.5 w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-semibold"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400">Rear Setback</label>
                <input
                  type="number"
                  value={rearSetback}
                  onChange={(e) => setRearSetback(Number(e.target.value))}
                  className="mt-0.5 w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-semibold"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400">Left Side Setback</label>
                <input
                  type="number"
                  value={leftSetback}
                  onChange={(e) => setLeftSetback(Number(e.target.value))}
                  className="mt-0.5 w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-semibold"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400">Right Side Setback</label>
                <input
                  type="number"
                  value={rightSetback}
                  onChange={(e) => setRightSetback(Number(e.target.value))}
                  className="mt-0.5 w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-semibold"
                />
              </div>
            </div>
          </div>

          {/* FAR & Coverage Limits */}
          <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div>
              <label className="text-[11px] font-bold text-slate-500">Permissible FAR / FSI</label>
              <select
                value={permissibleFAR}
                onChange={(e) => setPermissibleFAR(Number(e.target.value))}
                className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
              >
                <option value={1.5}>1.5 (Low Density Suburban)</option>
                <option value={2.0}>2.0 (Standard Urban Residential)</option>
                <option value={2.5}>2.5 (High Density Zone)</option>
                <option value={3.5}>3.5 (Commercial Transit Oriented)</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-500">Plot Road Facing</label>
              <select
                value={plotOrientation}
                onChange={(e) => setPlotOrientation(e.target.value as any)}
                className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs font-bold"
              >
                <option value="North">North Facing (Vastu Optimal)</option>
                <option value="East">East Facing (Morning Sun)</option>
                <option value="South">South Facing (Solar Heat)</option>
                <option value="West">West Facing (Evening Sun)</option>
              </select>
            </div>
          </div>

          <div className="rounded-xl bg-amber-50 dark:bg-amber-950/20 p-3 border border-amber-200 dark:border-amber-900/40 text-[11px] text-amber-800 dark:text-amber-300 flex items-start gap-2">
            <Info className="h-4 w-4 shrink-0 mt-0.5 text-amber-600" />
            <div>
              <span className="font-bold">Jurisdiction Notice:</span> Setback rules vary by Municipal Corporation (e.g. BBMP, DDA, MCGM, HMDA). The user should input their applicable bye-laws.
            </div>
          </div>
        </div>

        {/* Right Geometry Canvas & Calculations */}
        <div className="lg:col-span-7 space-y-4">
          {/* Key Metric Chips */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3">
              <div className="text-[10px] font-bold uppercase text-slate-400">Total Plot Area</div>
              <div className="text-base font-black text-slate-900 dark:text-white mt-0.5">
                {grossPlotAreaSqFt.toLocaleString()} sq.ft
              </div>
              <div className="text-[9px] text-slate-400">{grossPlotAreaSqM} m² / {plotAreaGunthas} Gunthas</div>
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3">
              <div className="text-[10px] font-bold uppercase text-slate-400">Buildable Footprint</div>
              <div className="text-base font-black text-orange-600 dark:text-orange-400 mt-0.5">
                {buildableFootprintSqFt.toLocaleString()} sq.ft
              </div>
              <div className="text-[9px] text-slate-400">Coverage: {actualCoveragePercent}%</div>
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3">
              <div className="text-[10px] font-bold uppercase text-slate-400">Max Permitted BUA</div>
              <div className="text-base font-black text-slate-900 dark:text-white mt-0.5">
                {maxPermissibleBuiltupArea.toLocaleString()} sq.ft
              </div>
              <div className="text-[9px] text-slate-400">FAR: {permissibleFAR}</div>
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3">
              <div className="text-[10px] font-bold uppercase text-slate-400">Feasible Storeys</div>
              <div className="text-base font-black text-emerald-600 dark:text-emerald-400 mt-0.5">
                G + {Math.max(1, Math.floor(Number(potentialFloors)) - 1)} Floors
              </div>
              <div className="text-[9px] text-slate-400">~{potentialFloors} total levels</div>
            </div>
          </div>

          {/* Interactive SVG Plot Geometry Diagram */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-900 p-6 text-white shadow-sm flex flex-col items-center justify-center">
            <div className="flex items-center justify-between w-full mb-3 text-xs">
              <div className="flex items-center gap-2">
                <Compass className="h-4 w-4 text-orange-500 animate-spin" />
                <span className="font-bold">Orientation: Facing {plotOrientation}</span>
              </div>
              <div className="flex items-center gap-3 text-[11px]">
                <div className="flex items-center gap-1.5">
                  <div className="h-2.5 w-2.5 rounded-xs bg-slate-700 border border-slate-500" />
                  <span>Gross Boundary</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="h-2.5 w-2.5 rounded-xs bg-orange-500/30 border border-orange-500" />
                  <span className="text-orange-400 font-bold">Buildable Envelope</span>
                </div>
              </div>
            </div>

            {/* SVG Plot Diagram */}
            <div className="relative w-full max-w-md h-64 border border-slate-800 rounded-xl bg-slate-950 flex items-center justify-center p-4">
              <svg viewBox="0 0 300 200" className="w-full h-full">
                {/* Outer Plot Boundary */}
                <rect
                  x="30"
                  y="20"
                  width="240"
                  height="160"
                  fill="#1e293b"
                  stroke="#64748b"
                  strokeWidth="2"
                  strokeDasharray="4 4"
                />

                {/* Inner Buildable Footprint */}
                <rect
                  x={30 + (leftSetback / plotWidth) * 240}
                  y={20 + (frontSetback / plotLength) * 160}
                  width={Math.max(20, (buildableWidth / plotWidth) * 240)}
                  height={Math.max(20, (buildableLength / plotLength) * 160)}
                  fill="rgba(234, 88, 12, 0.25)"
                  stroke="#ea580c"
                  strokeWidth="2.5"
                />

                {/* Center text for Footprint */}
                <text
                  x="150"
                  y="105"
                  fill="#ffffff"
                  fontSize="10"
                  fontWeight="bold"
                  textAnchor="middle"
                >
                  BUILT-UP FOOTPRINT
                </text>
                <text
                  x="150"
                  y="120"
                  fill="#fb923c"
                  fontSize="9"
                  textAnchor="middle"
                >
                  {buildableLength}′ × {buildableWidth}′ ({buildableFootprintSqFt} sq.ft)
                </text>

                {/* Road Indicator at Bottom */}
                <rect x="0" y="190" width="300" height="10" fill="#334155" />
                <text x="150" y="198" fill="#94a3b8" fontSize="8" textAnchor="middle" fontWeight="bold">
                  ═══ APPROACH ROAD ({plotOrientation.toUpperCase()} FACING) ═══
                </text>

                {/* Setback dimension labels */}
                <text x="150" y="32" fill="#94a3b8" fontSize="8" textAnchor="middle">
                  Rear Setback: {rearSetback}′
                </text>
                <text x="150" y="175" fill="#ea580c" fontSize="8" textAnchor="middle" fontWeight="bold">
                  Front Setback: {frontSetback}′
                </text>
                <text x="15" y="105" fill="#94a3b8" fontSize="8" textAnchor="middle" transform="rotate(-90, 15, 105)">
                  Left: {leftSetback}′
                </text>
                <text x="285" y="105" fill="#94a3b8" fontSize="8" textAnchor="middle" transform="rotate(90, 285, 105)">
                  Right: {rightSetback}′
                </text>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
