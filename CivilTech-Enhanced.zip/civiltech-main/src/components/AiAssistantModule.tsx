import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  BookOpen,
  ShieldCheck,
  RotateCcw,
  User,
  Check,
  Copy,
  Layers,
  HelpCircle,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { civilApi } from '../services/api';
import { ChatMessage } from '../types/civil';

const SAMPLE_PROMPTS = [
  'What is the minimum concrete cover for beams, columns, footings and slabs according to IS 456:2000?',
  'Explain the formula and steps for calculating development length (Ld) for Fe500D steel rebar in M25 concrete.',
  'What are the recommended slump values for pumpable concrete and tremie underwater concreting as per IS 456?',
  'Explain the difference between one-way and two-way slabs with boundary conditions and aspect ratio Ly/Lx.',
  'What are the key seismic detailing requirements of IS 13920:2016 for beam-column ductile junctions?',
  'How do we calculate dry volume for concrete (1.54) and mortar (1.33)? Explain the physical void rationale.',
];

export const AiAssistantModule: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-0',
      sender: 'assistant',
      timestamp: 'Just now',
      content: `### Welcome to CIVILTECH AI Engineer Assistant 👷‍♂️📐

I am your specialized AI Civil Engineering consultant, trained on **Indian Standards (IS Codes)**, **CPWD Specifications**, **Eurocodes / ACI**, and practical site engineering practices.

**What I can do for you:**
- **IS Codes Guidance:** Precise clause references for *IS 456 (RCC)*, *IS 800 (Steel)*, *IS 1893 (Earthquake)*, *IS 875 (Loads)*, *IS 1200 (Measurement)*, and *IS 10262 (Mix Design)*.
- **Structural Analysis & Formulas:** Step-by-step checks for bending moment, shear capacity, development length, and deflection limits.
- **Site QA/QC & Concrete Technology:** Slump test tolerances, cube compressive strength criteria (IS 516), curing protocols, formwork stripping intervals.
- **Quantity Surveying:** BOQ items, material estimation, bar bending schedules ($D^2/162$).

*Ask any civil engineering question or select one of the quick prompts below.*`,
      citations: ['IS 456:2000', 'IS 1893:2016', 'IS 10262:2019', 'CPWD Specs'],
    },
  ]);

  const [input, setInput] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || loading) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      content: query,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const response = await civilApi.sendChatMessage(query);
      const assistantMsg: ChatMessage = {
        id: `ast-${Date.now()}`,
        sender: 'assistant',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        content: response.reply,
        citations: response.citations,
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `ast-${Date.now()}`,
          sender: 'assistant',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          content: 'Unable to connect to CivilTech AI engine. Please verify network connectivity.',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (id: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: 'msg-0',
        sender: 'assistant',
        timestamp: 'Just now',
        content: 'Chat session reset. Ready for your civil engineering queries!',
        citations: ['IS 456:2000'],
      },
    ]);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8.5rem)] space-y-4">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white">
              IS Code AI Civil Assistant
            </h1>
            <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-xs font-bold text-orange-700 dark:text-orange-400 flex items-center gap-1">
              <Sparkles className="h-3 w-3" /> Gemini 3.8 Flash
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Verified engineering calculations, Indian Standards citations, concrete tech, and site safety consultation.
          </p>
        </div>

        <button
          onClick={handleClearChat}
          className="flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          <span>Reset Session</span>
        </button>
      </div>

      {/* Quick Prompt Chips */}
      <div className="flex overflow-x-auto gap-2 pb-1 scrollbar-thin">
        {SAMPLE_PROMPTS.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(prompt)}
            disabled={loading}
            className="flex shrink-0 items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:border-orange-500/50 hover:bg-orange-50/50 dark:hover:bg-orange-950/20 transition cursor-pointer disabled:opacity-50"
          >
            <Sparkles className="h-3 w-3 text-orange-500 shrink-0" />
            <span className="truncate max-w-xs">{prompt}</span>
          </button>
        ))}
      </div>

      {/* Chat Messages Container */}
      <div className="flex-1 overflow-y-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-6 space-y-5 shadow-inner">
        {messages.map((msg) => {
          const isAssistant = msg.sender === 'assistant';

          return (
            <div
              key={msg.id}
              className={`flex gap-3 max-w-4xl ${isAssistant ? '' : 'ml-auto flex-row-reverse'}`}
            >
              {/* Avatar */}
              <div
                className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-white shadow-xs ${
                  isAssistant ? 'bg-orange-600' : 'bg-slate-700'
                }`}
              >
                {isAssistant ? <Bot className="h-4 w-4" /> : <User className="h-4 w-4" />}
              </div>

              {/* Message Bubble */}
              <div
                className={`rounded-2xl p-4 text-xs sm:text-sm leading-relaxed transition ${
                  isAssistant
                    ? 'border border-slate-200/80 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/50 text-slate-800 dark:text-slate-200'
                    : 'bg-orange-600 text-white shadow-md shadow-orange-600/20'
                }`}
              >
                {/* Header info */}
                <div
                  className={`flex items-center justify-between gap-4 mb-2 pb-1 border-b text-[10px] ${
                    isAssistant
                      ? 'border-slate-200 dark:border-slate-700/60 text-slate-400'
                      : 'border-orange-500/60 text-orange-200'
                  }`}
                >
                  <span className="font-bold">{isAssistant ? 'CIVILTECH AI Engine' : 'Site Engineer'}</span>
                  <div className="flex items-center gap-2">
                    <span>{msg.timestamp}</span>
                    {isAssistant && (
                      <button
                        onClick={() => handleCopy(msg.id, msg.content)}
                        className="hover:text-orange-500 transition cursor-pointer"
                        title="Copy text"
                      >
                        {copiedId === msg.id ? (
                          <Check className="h-3 w-3 text-emerald-500" />
                        ) : (
                          <Copy className="h-3 w-3" />
                        )}
                      </button>
                    )}
                  </div>
                </div>

                {/* Content with basic formatting */}
                <div className="prose dark:prose-invert max-w-none text-xs sm:text-sm whitespace-pre-wrap font-sans">
                  {msg.content}
                </div>

                {/* Citations Badges */}
                {isAssistant && msg.citations && msg.citations.length > 0 && (
                  <div className="mt-3 pt-2.5 border-t border-slate-200 dark:border-slate-700/60 flex flex-wrap items-center gap-1.5">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                      <BookOpen className="h-3 w-3 text-orange-500" />
                      Standards Referenced:
                    </span>
                    {msg.citations.map((c, i) => (
                      <span
                        key={i}
                        className="rounded-md bg-orange-100 dark:bg-orange-950/80 px-2 py-0.5 text-[10px] font-bold text-orange-800 dark:text-orange-300 border border-orange-200 dark:border-orange-800/60"
                      >
                        {c}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {loading && (
          <div className="flex gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-orange-600 text-white">
              <Bot className="h-4 w-4 animate-spin" />
            </div>
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 p-4 text-xs text-slate-500 flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-orange-600 animate-bounce" />
              <div className="h-2 w-2 rounded-full bg-orange-600 animate-bounce [animation-delay:0.2s]" />
              <div className="h-2 w-2 rounded-full bg-orange-600 animate-bounce [animation-delay:0.4s]" />
              <span className="font-semibold text-slate-600 dark:text-slate-300 ml-1">
                Analyzing IS Codes &amp; computing structural principles...
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
        className="relative flex items-center"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask anything on IS 456, mix designs, concrete tests, rebar calculations, safety..."
          disabled={loading}
          className="w-full rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-3.5 pl-4 pr-14 text-xs sm:text-sm font-medium text-slate-900 dark:text-white shadow-sm outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 transition"
        />
        <button
          type="submit"
          disabled={!input.trim() || loading}
          className="absolute right-2 flex h-9 w-9 items-center justify-center rounded-xl bg-orange-600 hover:bg-orange-700 active:scale-95 text-white transition disabled:opacity-40 cursor-pointer"
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
};
