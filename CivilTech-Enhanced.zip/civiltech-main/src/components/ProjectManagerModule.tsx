import React, { useState } from 'react';
import {
  FolderKanban,
  Plus,
  Calendar,
  DollarSign,
  Users,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Filter,
  Layers,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { Project, ProjectTask } from '../types/civil';
import { civilApi } from '../services/api';

interface ProjectManagerProps {
  projects: Project[];
  tasks: ProjectTask[];
  selectedProjectId: string;
  onSelectProject: (id: string) => void;
  onProjectCreated: (newProj: Project) => void;
  onTaskCreated: (newTask: ProjectTask) => void;
  onTaskUpdated: (task: ProjectTask) => void;
}

export const ProjectManagerModule: React.FC<ProjectManagerProps> = ({
  projects,
  tasks,
  selectedProjectId,
  onSelectProject,
  onProjectCreated,
  onTaskCreated,
  onTaskUpdated,
}) => {
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [showNewTaskModal, setShowNewTaskModal] = useState(false);
  const [phaseFilter, setPhaseFilter] = useState<string>('All');

  // Form States
  const [newProjName, setNewProjName] = useState('');
  const [newProjType, setNewProjType] = useState<'Residential' | 'Commercial' | 'Infrastructure' | 'Industrial'>('Residential');
  const [newProjLocation, setNewProjLocation] = useState('');
  const [newProjBudget, setNewProjBudget] = useState(25000000);
  const [newProjDeadline, setNewProjDeadline] = useState('2027-06-30');
  const [newProjManager, setNewProjManager] = useState('Er. Sameer Joshi');
  const [newProjContractor, setNewProjContractor] = useState('Buildwell Infra');

  // New Task Form
  const [newTaskName, setNewTaskName] = useState('');
  const [newTaskPhase, setNewTaskPhase] = useState<'Substructure' | 'Superstructure' | 'MEP' | 'Finishes' | 'Handover'>('Superstructure');
  const [newTaskEndDate, setNewTaskEndDate] = useState('2026-12-15');
  const [newTaskContractor, setNewTaskContractor] = useState('Shri Balaji Rebar');
  const [newTaskBudget, setNewTaskBudget] = useState(1500000);
  const [newTaskPriority, setNewTaskPriority] = useState<'Low' | 'Medium' | 'High' | 'Critical'>('High');

  const activeProject = projects.find((p) => p.id === selectedProjectId) || projects[0];
  const projectTasks = tasks.filter((t) => t.projectId === activeProject?.id);
  const filteredTasks = phaseFilter === 'All' ? projectTasks : projectTasks.filter((t) => t.phase === phaseFilter);

  const formatINR = (val: number) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(2)} L`;
    return `₹${val.toLocaleString('en-IN')}`;
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjName.trim()) return;

    const created = await civilApi.createProject({
      name: newProjName,
      type: newProjType,
      location: newProjLocation || 'Industrial Development Zone',
      coordinates: { lat: 28.6139, lng: 77.209 },
      clientName: 'Institutional Client',
      projectManager: newProjManager,
      contractor: newProjContractor,
      startDate: new Date().toISOString().split('T')[0],
      targetCompletionDate: newProjDeadline,
      estimatedBudget: Number(newProjBudget),
      spentBudget: 0,
      completionPercentage: 0,
      status: 'Planning',
      currentPhase: 'Site Mobilization & Excavation',
      floors: 4,
      totalBuiltupAreaSqFt: 35000,
      description: 'Newly planned infrastructure project managed on CivilTech AI.',
      risksIdentified: 0,
    });

    if (created) {
      onProjectCreated(created);
      onSelectProject(created.id);
      setShowNewProjectModal(false);
      setNewProjName('');
    }
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskName.trim() || !activeProject) return;

    const created = await civilApi.createTask({
      projectId: activeProject.id,
      taskName: newTaskName,
      phase: newTaskPhase,
      startDate: new Date().toISOString().split('T')[0],
      endDate: newTaskEndDate,
      progress: 0,
      assignedContractor: newTaskContractor,
      status: 'Not Started',
      budget: Number(newTaskBudget),
      spent: 0,
      priority: newTaskPriority,
    });

    if (created) {
      onTaskCreated(created);
      setShowNewTaskModal(false);
      setNewTaskName('');
    }
  };

  const handleUpdateTaskProgress = (task: ProjectTask, newProgress: number) => {
    const updatedStatus = newProgress === 100 ? 'Completed' : newProgress > 0 ? 'In Progress' : 'Not Started';
    const updated = { ...task, progress: newProgress, status: updatedStatus as any };
    onTaskUpdated(updated);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white">
              Project Management &amp; WBS Schedules
            </h1>
            <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-xs font-bold text-orange-700 dark:text-orange-400">
              Work Breakdown
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Track multi-phase milestones, contractor scopes, budget variances, and delay risks across the project lifecycle.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowNewTaskModal(true)}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 shadow-sm cursor-pointer transition"
          >
            <Plus className="h-4 w-4 text-orange-600" />
            <span>Add Work Task</span>
          </button>
          <button
            onClick={() => setShowNewProjectModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-3 py-2 text-xs font-bold shadow-sm shadow-orange-600/30 cursor-pointer transition"
          >
            <Plus className="h-4 w-4" />
            <span>New Project</span>
          </button>
        </div>
      </div>

      {/* Project Selector Cards Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {projects.map((proj) => {
          const isSelected = proj.id === activeProject?.id;
          return (
            <div
              key={proj.id}
              onClick={() => onSelectProject(proj.id)}
              className={`rounded-2xl p-4 border transition cursor-pointer ${
                isSelected
                  ? 'border-orange-500 bg-orange-50/50 dark:bg-orange-950/20 shadow-md ring-2 ring-orange-500/20'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-bold text-orange-600 dark:text-orange-400">{proj.code}</span>
                <span
                  className={`rounded-md px-1.5 py-0.5 text-[10px] font-bold ${
                    proj.status === 'Active'
                      ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                  }`}
                >
                  {proj.status}
                </span>
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">{proj.name}</h3>
              <p className="text-[11px] text-slate-400 mt-1 truncate">{proj.location}</p>

              <div className="mt-3 flex items-center justify-between text-xs font-semibold">
                <span className="text-slate-500">Progress:</span>
                <span className="text-orange-600 dark:text-orange-400 font-bold">{proj.completionPercentage}%</span>
              </div>
              <div className="mt-1 h-1.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-orange-600 rounded-full"
                  style={{ width: `${proj.completionPercentage}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Project Detail View */}
      {activeProject && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm space-y-6">
          {/* Top Info Bar */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-slate-900 dark:text-white">{activeProject.name}</h2>
                <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2 py-0.5 text-xs font-bold text-slate-700 dark:text-slate-300">
                  {activeProject.type}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Project Manager: <span className="font-semibold text-slate-800 dark:text-slate-200">{activeProject.projectManager}</span> | Lead Contractor: <span className="font-semibold text-slate-800 dark:text-slate-200">{activeProject.contractor}</span>
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs">
              <div className="rounded-xl bg-slate-50 dark:bg-slate-800/80 p-2.5 border border-slate-100 dark:border-slate-800">
                <div className="text-[10px] uppercase font-bold text-slate-400">Target Budget</div>
                <div className="font-black text-slate-900 dark:text-white mt-0.5">{formatINR(activeProject.estimatedBudget)}</div>
              </div>
              <div className="rounded-xl bg-slate-50 dark:bg-slate-800/80 p-2.5 border border-slate-100 dark:border-slate-800">
                <div className="text-[10px] uppercase font-bold text-slate-400">Spent to Date</div>
                <div className="font-black text-orange-600 dark:text-orange-400 mt-0.5">{formatINR(activeProject.spentBudget)}</div>
              </div>
              <div className="rounded-xl bg-slate-50 dark:bg-slate-800/80 p-2.5 border border-slate-100 dark:border-slate-800">
                <div className="text-[10px] uppercase font-bold text-slate-400">Target Handover</div>
                <div className="font-black text-slate-900 dark:text-white mt-0.5">{activeProject.targetCompletionDate}</div>
              </div>
            </div>
          </div>

          {/* Phase Filter Tabs */}
          <div className="flex items-center justify-between">
            <div className="flex overflow-x-auto gap-2">
              {['All', 'Substructure', 'Superstructure', 'MEP', 'Finishes', 'Handover'].map((phase) => (
                <button
                  key={phase}
                  onClick={() => setPhaseFilter(phase)}
                  className={`rounded-xl px-3 py-1.5 text-xs font-bold transition cursor-pointer ${
                    phaseFilter === phase
                      ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {phase}
                </button>
              ))}
            </div>

            <span className="text-xs font-semibold text-slate-400">
              Showing {filteredTasks.length} tasks
            </span>
          </div>

          {/* Task Work Breakdown Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Task Name</th>
                  <th className="py-2.5 px-3">Phase</th>
                  <th className="py-2.5 px-3">Assigned Agency</th>
                  <th className="py-2.5 px-3">End Date</th>
                  <th className="py-2.5 px-3">Progress (%)</th>
                  <th className="py-2.5 px-3">Budget</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {filteredTasks.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-3 font-bold text-slate-900 dark:text-white max-w-xs">
                      {t.taskName}
                    </td>
                    <td className="py-3 px-3">
                      <span className="rounded-md bg-slate-100 dark:bg-slate-800 px-2 py-0.5 text-[10px] font-bold text-slate-700 dark:text-slate-300">
                        {t.phase}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-300">{t.assignedContractor}</td>
                    <td className="py-3 px-3 text-slate-500">{t.endDate}</td>
                    <td className="py-3 px-3 w-40">
                      <div className="flex items-center gap-2">
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={t.progress}
                          onChange={(e) => handleUpdateTaskProgress(t, Number(e.target.value))}
                          className="w-24 accent-orange-600 cursor-pointer"
                        />
                        <span className="font-bold text-orange-600 dark:text-orange-400 text-xs w-8">
                          {t.progress}%
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-3 font-semibold text-slate-800 dark:text-slate-200">
                      {formatINR(t.budget)}
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${
                          t.status === 'Completed'
                            ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400'
                            : t.status === 'In Progress'
                            ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400'
                            : t.status === 'Delayed'
                            ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-400'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                        }`}
                      >
                        {t.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* New Project Modal */}
      {showNewProjectModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-4">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Create New Construction Project</h2>
            <form onSubmit={handleCreateProject} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-500">Project Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Prestige High-Tech Commercial Complex"
                  value={newProjName}
                  onChange={(e) => setNewProjName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-500">Building Type</label>
                  <select
                    value={newProjType}
                    onChange={(e) => setNewProjType(e.target.value as any)}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  >
                    <option value="Residential">Residential</option>
                    <option value="Commercial">Commercial</option>
                    <option value="Infrastructure">Infrastructure</option>
                    <option value="Industrial">Industrial</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-500">Site Location</label>
                  <input
                    type="text"
                    placeholder="e.g. Whitefield, Bengaluru"
                    value={newProjLocation}
                    onChange={(e) => setNewProjLocation(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-500">Budget (INR ₹)</label>
                  <input
                    type="number"
                    value={newProjBudget}
                    onChange={(e) => setNewProjBudget(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-500">Target Completion</label>
                  <input
                    type="date"
                    value={newProjDeadline}
                    onChange={(e) => setNewProjDeadline(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNewProjectModal(false)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-2 font-bold text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 font-bold shadow-md shadow-orange-600/30"
                >
                  Initialize Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Task Modal */}
      {showNewTaskModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-4">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Add Construction WBS Task</h2>
            <form onSubmit={handleCreateTask} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-500">Task Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 11th Floor Slab Shuttering & Rebar Binding"
                  value={newTaskName}
                  onChange={(e) => setNewTaskName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-500">Phase</label>
                  <select
                    value={newTaskPhase}
                    onChange={(e) => setNewTaskPhase(e.target.value as any)}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  >
                    <option value="Substructure">Substructure</option>
                    <option value="Superstructure">Superstructure</option>
                    <option value="MEP">MEP</option>
                    <option value="Finishes">Finishes</option>
                    <option value="Handover">Handover</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-500">Target Date</label>
                  <input
                    type="date"
                    value={newTaskEndDate}
                    onChange={(e) => setNewTaskEndDate(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-500">Sub-Contractor</label>
                  <input
                    type="text"
                    value={newTaskContractor}
                    onChange={(e) => setNewTaskContractor(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-500">Task Budget (₹)</label>
                  <input
                    type="number"
                    value={newTaskBudget}
                    onChange={(e) => setNewTaskBudget(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 font-bold"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNewTaskModal(false)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-2 font-bold text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 font-bold shadow-md shadow-orange-600/30"
                >
                  Save Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
