import React, { useState } from 'react';
import {
  Calculator,
  Download,
  Printer,
  Sparkles,
  Info,
  DollarSign,
  Building,
  CheckCircle,
  FileSpreadsheet,
  Layers,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { BOQItem, CostEstimateInput } from '../types/civil';

export const EstimatorModule: React.FC = () => {
  // Input State
  const [params, setParams] = useState<CostEstimateInput>({
    plotLength: 40,
    plotWidth: 60,
    floors: 3, // G+2
    buildingType: 'Residential Villa',
    quality: 'Standard / Executive',
    basementIncluded: false,
    seismicZone: 'Zone IV',
    soilCondition: 'Medium / Sand',
    concreteGrade: 'M25',
    steelGrade: 'Fe500D',
  });

  const [unitSystem, setUnitSystem] = useState<'feet' | 'meters'>('feet');
  const [activeTab, setActiveTab] = useState<'overview' | 'boq' | 'materials'>('overview');

  // Calculations
  const plotArea = params.plotLength * params.plotWidth; // in sq.ft
  const groundCoveragePercent = 0.70; // 70% typical permissible
  const plinthAreaPerFloor = Math.round(plotArea * groundCoveragePercent);
  const totalBuiltupArea = plinthAreaPerFloor * params.floors + (params.basementIncluded ? plinthAreaPerFloor * 0.9 : 0);
  const carpetArea = Math.round(totalBuiltupArea * 0.75); // 75% carpet efficiency

  // Base Rate per Sq.Ft
  let baseRatePerSqFt = 2200;
  if (params.quality === 'Economy / Basic') baseRatePerSqFt = 1650;
  if (params.quality === 'Luxury / High-End') baseRatePerSqFt = 3450;

  // Modifiers
  if (params.buildingType === 'Commercial Office') baseRatePerSqFt *= 1.15;
  if (params.buildingType === 'Industrial Shed') baseRatePerSqFt *= 0.85;
  if (params.seismicZone === 'Zone IV' || params.seismicZone === 'Zone V') baseRatePerSqFt *= 1.05;
  if (params.soilCondition === 'Soft Clay / Loose') baseRatePerSqFt *= 1.08;

  const totalEstimatedCost = Math.round(totalBuiltupArea * baseRatePerSqFt);

  // Breakdown Percentages
  const breakdown = [
    { category: 'Substructure & Foundation', percent: 15, amount: Math.round(totalEstimatedCost * 0.15), desc: 'Excavation, PCC, isolated/raft footings, plinth beam, anti-termite' },
    { category: 'RCC Superstructure Framing', percent: 32, amount: Math.round(totalEstimatedCost * 0.32), desc: 'Columns, shear walls, beams, slabs with M25/Fe500D' },
    { category: 'Brickwork & Masonry Walls', percent: 13, amount: Math.round(totalEstimatedCost * 0.13), desc: 'External 200mm AAC/fly ash & internal 100mm partition walls' },
    { category: 'Plastering & Waterproofing', percent: 8, amount: Math.round(totalEstimatedCost * 0.08), desc: '12mm internal plaster (1:6), 15mm external sand-faced, sunken waterproofing' },
    { category: 'Flooring & Wall Tiling', percent: 10, amount: Math.round(totalEstimatedCost * 0.10), desc: 'Vitrified tiles, granite counter, skirting, anti-skid bathroom tiles' },
    { category: 'MEP (Electrical & Plumbing)', percent: 11, amount: Math.round(totalEstimatedCost * 0.11), desc: 'Concealed CPVC/PVC piping, copper wiring, DBs, sanitary fittings' },
    { category: 'Doors, Windows & Painting', percent: 7, amount: Math.round(totalEstimatedCost * 0.07), desc: 'UPVC windows, flush/teak wood doors, premium acrylic emulsion' },
    { category: 'Contingency & Site Supervision', percent: 4, amount: Math.round(totalEstimatedCost * 0.04), desc: 'Contractor margin, site engineering testing, municipal permits' },
  ];

  // Material Estimation Quantities (Thumb Rules & IS 1200 Standards)
  const cementBags = Math.round(totalBuiltupArea * 0.42); // 0.42 bags per sq.ft
  const steelTonnes = Number(((totalBuiltupArea * 3.8) / 1000).toFixed(2)); // 3.8 kg per sq.ft -> MT
  const sandCft = Math.round(totalBuiltupArea * 1.9); // 1.9 cft per sq.ft
  const aggregateCft = Math.round(totalBuiltupArea * 2.8); // 2.8 cft per sq.ft
  const brickCount = Math.round(totalBuiltupArea * 18); // 18-20 bricks per sq.ft
  const paintLitres = Math.round(totalBuiltupArea * 0.18);
  const tilesSqFt = Math.round(carpetArea * 1.15); // +15% cutting wastage and skirting

  // BOQ Items
  const boqItems: BOQItem[] = [
    {
      itemNo: '1.01',
      category: 'Earthwork',
      description: 'Earthwork excavation in foundation trenches and column pits in all types of soil including disposal of surplus excavated earth within 50m lead (IS 1200 Part 1)',
      quantity: Math.round(totalBuiltupArea * 0.22),
      unit: 'Cu.m',
      rate: 320,
      amount: Math.round(totalBuiltupArea * 0.22 * 320),
      isCodeReference: 'IS 1200 (Part 1):1992',
    },
    {
      itemNo: '1.02',
      category: 'Substructure',
      description: 'Providing and laying Plain Cement Concrete (PCC) 1:4:8 (1 cement : 4 coarse sand : 8 graded stone aggregate 40mm nominal size) for foundation blinding',
      quantity: Math.round(totalBuiltupArea * 0.05),
      unit: 'Cu.m',
      rate: 4850,
      amount: Math.round(totalBuiltupArea * 0.05 * 4850),
      isCodeReference: 'IS 456:2000 Cl. 5',
    },
    {
      itemNo: '1.03',
      category: 'RCC Superstructure',
      description: `Reinforced cement concrete ${params.concreteGrade} grade in suspended floor slabs, lintels, columns and beams including centering, shuttering, prop staging and vibration (IS 456)`,
      quantity: Math.round(totalBuiltupArea * 0.16),
      unit: 'Cu.m',
      rate: 7600,
      amount: Math.round(totalBuiltupArea * 0.16 * 7600),
      isCodeReference: 'IS 456:2000 / IS 10262',
    },
    {
      itemNo: '1.04',
      category: 'Reinforcement Steel',
      description: `Supplying, cutting, bending, hooking and placing in position ${params.steelGrade} Thermo-Mechanically Treated (TMT) high-yield strength rebar including binding wire (IS 1786)`,
      quantity: steelTonnes,
      unit: 'MT',
      rate: 64000,
      amount: Math.round(steelTonnes * 64000),
      isCodeReference: 'IS 1786:2008 / IS 2502',
    },
    {
      itemNo: '1.05',
      category: 'Masonry',
      description: 'Brickwork / Autoclaved Aerated Concrete (AAC) blocks with cement mortar 1:6 (1 cement : 6 coarse sand) in superstructure above plinth level',
      quantity: Math.round(totalBuiltupArea * 0.12),
      unit: 'Cu.m',
      rate: 5400,
      amount: Math.round(totalBuiltupArea * 0.12 * 5400),
      isCodeReference: 'IS 2212 / IS 2185',
    },
    {
      itemNo: '1.06',
      category: 'Finishes',
      description: '12mm cement plaster of mix 1:6 to internal walls and ceiling finished smooth with lime rendering / gypsum punning',
      quantity: Math.round(totalBuiltupArea * 2.8),
      unit: 'Sq.m',
      rate: 240,
      amount: Math.round(totalBuiltupArea * 2.8 * 240),
      isCodeReference: 'IS 1661:1972',
    },
    {
      itemNo: '1.07',
      category: 'Flooring',
      description: 'Providing and laying glazed vitrified floor tiles (600x600mm / 800x800mm) with 20mm cement mortar 1:4 bedding and epoxy grout joints',
      quantity: Math.round(carpetArea * 0.0929), // sq.ft to sq.m
      unit: 'Sq.m',
      rate: 1450,
      amount: Math.round(carpetArea * 0.0929 * 1450),
      isCodeReference: 'IS 14457 / IS 13755',
    },
  ];

  const formatINR = (val: number) => `₹${val.toLocaleString('en-IN')}`;

  const handleExportCSV = () => {
    const headers = 'Item No,Category,Description,Quantity,Unit,Rate (INR),Amount (INR),IS Standard\n';
    const rows = boqItems
      .map(
        (item) =>
          `"${item.itemNo}","${item.category}","${item.description.replace(/"/g, '""')}",${item.quantity},"${item.unit}",${item.rate},${item.amount},"${item.isCodeReference}"`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `CivilTech_BOQ_Estimate_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Title & Top Description */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white">
              AI Construction Cost Estimator &amp; Detailed BOQ
            </h1>
            <span className="rounded-md bg-orange-100 dark:bg-orange-950/60 px-2 py-0.5 text-xs font-bold text-orange-700 dark:text-orange-400">
              CPWD DSR Norms
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Compute preliminary structural budgets, material quantities, and standard Bill of Quantities (BOQ) with customizable specs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 shadow-sm cursor-pointer transition"
          >
            <Download className="h-4 w-4 text-orange-600" />
            <span>Export CSV / Excel</span>
          </button>
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white px-3 py-2 text-xs font-bold shadow-sm shadow-orange-600/30 cursor-pointer transition"
          >
            <Printer className="h-4 w-4" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Inputs on Left, Results on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Config Panel (5 cols) */}
        <div className="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Calculator className="h-4 w-4 text-orange-600" />
              Project Parameters &amp; Specifications
            </h2>
            <div className="flex items-center text-xs font-semibold bg-slate-100 dark:bg-slate-800 rounded-lg p-0.5">
              <button
                onClick={() => setUnitSystem('feet')}
                className={`px-2 py-1 rounded-md transition ${unitSystem === 'feet' ? 'bg-white dark:bg-slate-700 shadow-xs text-orange-600 font-bold' : 'text-slate-500'}`}
              >
                Feet (ft)
              </button>
              <button
                onClick={() => setUnitSystem('meters')}
                className={`px-2 py-1 rounded-md transition ${unitSystem === 'meters' ? 'bg-white dark:bg-slate-700 shadow-xs text-orange-600 font-bold' : 'text-slate-500'}`}
              >
                Meters (m)
              </button>
            </div>
          </div>

          {/* Plot Dimensions */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                Plot Length ({unitSystem === 'feet' ? 'ft' : 'm'})
              </label>
              <input
                type="number"
                min="10"
                value={params.plotLength}
                onChange={(e) => setParams({ ...params, plotLength: Math.max(1, Number(e.target.value)) })}
                className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-orange-500"
              />
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                Plot Width ({unitSystem === 'feet' ? 'ft' : 'm'})
              </label>
              <input
                type="number"
                min="10"
                value={params.plotWidth}
                onChange={(e) => setParams({ ...params, plotWidth: Math.max(1, Number(e.target.value)) })}
                className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-orange-500"
              />
            </div>
          </div>

          {/* Building Type & Number of Floors */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">Building Type</label>
              <select
                value={params.buildingType}
                onChange={(e) => setParams({ ...params, buildingType: e.target.value as any })}
                className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-orange-500"
              >
                <option value="Residential Villa">Residential Villa</option>
                <option value="Apartment Complex">Apartment Complex</option>
                <option value="Commercial Office">Commercial Office</option>
                <option value="Industrial Shed">Industrial Shed</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">Number of Floors</label>
              <select
                value={params.floors}
                onChange={(e) => setParams({ ...params, floors: Number(e.target.value) })}
                className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-orange-500"
              >
                <option value={1}>G+0 (Single Storey)</option>
                <option value={2}>G+1 (Ground + 1)</option>
                <option value={3}>G+2 (Ground + 2)</option>
                <option value={4}>G+3 (Ground + 3)</option>
                <option value={5}>G+4 (Ground + 4)</option>
                <option value={8}>G+7 (Medium Rise)</option>
                <option value={12}>G+11 (High Rise)</option>
              </select>
            </div>
          </div>

          {/* Quality Tier Selection */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">Construction Quality Tier</label>
            <div className="mt-1 grid grid-cols-3 gap-2">
              {(['Economy / Basic', 'Standard / Executive', 'Luxury / High-End'] as const).map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => setParams({ ...params, quality: q })}
                  className={`p-2 rounded-xl border text-center transition cursor-pointer ${
                    params.quality === q
                      ? 'border-orange-500 bg-orange-50 dark:bg-orange-950/40 text-orange-700 dark:text-orange-300 font-bold'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <div className="text-[11px] leading-tight">{q.split(' / ')[0]}</div>
                  <div className="text-[9px] text-slate-400 mt-0.5">
                    {q === 'Economy / Basic' ? '₹1,650/sq.ft' : q === 'Standard / Executive' ? '₹2,200/sq.ft' : '₹3,450/sq.ft'}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Engineering Specs: Concrete & Steel Grades */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">Concrete Grade</label>
              <select
                value={params.concreteGrade}
                onChange={(e) => setParams({ ...params, concreteGrade: e.target.value as any })}
                className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-orange-500"
              >
                <option value="M20">M20 (1:1.5:3 - 20 N/mm²)</option>
                <option value="M25">M25 (1:1:2 - 25 N/mm²)</option>
                <option value="M30">M30 (Design Mix - 30 N/mm²)</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">Steel Rebar Grade</label>
              <select
                value={params.steelGrade}
                onChange={(e) => setParams({ ...params, steelGrade: e.target.value as any })}
                className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-orange-500"
              >
                <option value="Fe415">Fe 415 TMT</option>
                <option value="Fe500D">Fe 500D Ductile (IS 1786)</option>
                <option value="Fe550">Fe 550 High Strength</option>
              </select>
            </div>
          </div>

          {/* Seismic & Soil Conditions */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">Seismic Zone (IS 1893)</label>
              <select
                value={params.seismicZone}
                onChange={(e) => setParams({ ...params, seismicZone: e.target.value as any })}
                className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-orange-500"
              >
                <option value="Zone II">Zone II (Low)</option>
                <option value="Zone III">Zone III (Moderate)</option>
                <option value="Zone IV">Zone IV (Severe)</option>
                <option value="Zone V">Zone V (Very Severe)</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400">Subsoil Condition</label>
              <select
                value={params.soilCondition}
                onChange={(e) => setParams({ ...params, soilCondition: e.target.value as any })}
                className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-orange-500"
              >
                <option value="Hard Rock / Dense">Hard Rock (SBC &gt; 350 kN/m²)</option>
                <option value="Medium / Sand">Medium Sand (SBC ~ 200 kN/m²)</option>
                <option value="Soft Clay / Loose">Soft Clay (SBC &lt; 120 kN/m²)</option>
              </select>
            </div>
          </div>

          {/* Basement Toggle */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
            <div>
              <div className="text-xs font-bold text-slate-800 dark:text-slate-200">Include Retaining Basement</div>
              <div className="text-[10px] text-slate-400">Adds RCC retaining walls &amp; diaphragm waterproofing</div>
            </div>
            <input
              type="checkbox"
              checked={params.basementIncluded}
              onChange={(e) => setParams({ ...params, basementIncluded: e.target.checked })}
              className="h-4 w-4 accent-orange-600 rounded cursor-pointer"
            />
          </div>

          {/* Area Summary Box */}
          <div className="rounded-xl bg-orange-50 dark:bg-orange-950/30 p-3 border border-orange-200 dark:border-orange-900/50 text-xs space-y-1.5">
            <div className="flex justify-between text-slate-600 dark:text-slate-400">
              <span>Gross Plot Area:</span>
              <span className="font-bold text-slate-900 dark:text-white">{plotArea.toLocaleString()} sq.ft</span>
            </div>
            <div className="flex justify-between text-slate-600 dark:text-slate-400">
              <span>Ground Plinth Footprint (70%):</span>
              <span className="font-bold text-slate-900 dark:text-white">{plinthAreaPerFloor.toLocaleString()} sq.ft</span>
            </div>
            <div className="flex justify-between text-slate-600 dark:text-slate-400">
              <span>Total Built-Up Area (BUA):</span>
              <span className="font-bold text-orange-600 dark:text-orange-400">{totalBuiltupArea.toLocaleString()} sq.ft</span>
            </div>
            <div className="flex justify-between text-slate-600 dark:text-slate-400">
              <span>Usable Carpet Area (75%):</span>
              <span className="font-bold text-slate-900 dark:text-white">{carpetArea.toLocaleString()} sq.ft</span>
            </div>
          </div>
        </div>

        {/* Right Output Dashboard (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Big Cost Result Banner */}
          <div className="rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-navy-900 p-6 text-white shadow-lg border border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-400">
                Indicative Project Construction Cost
              </span>
              <span className="rounded-full bg-white/10 px-2.5 py-0.5 text-[11px] font-semibold text-slate-200">
                Unit Rate: ₹{Math.round(baseRatePerSqFt)} / sq.ft
              </span>
            </div>
            <div className="mt-2 flex items-baseline gap-3">
              <div className="text-3xl sm:text-4xl font-black text-white">{formatINR(totalEstimatedCost)}</div>
              <span className="text-xs text-slate-300">
                ({(totalEstimatedCost / 10000000).toFixed(2)} Crores INR)
              </span>
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-4 text-xs text-slate-300 border-t border-slate-700/60 pt-3">
              <div>
                <span className="text-slate-400">Structure: </span>
                <span className="font-bold text-white">{params.concreteGrade} Concrete + {params.steelGrade}</span>
              </div>
              <div>
                <span className="text-slate-400">Floors: </span>
                <span className="font-bold text-white">{params.floors} Levels</span>
              </div>
              <div>
                <span className="text-slate-400">Total BUA: </span>
                <span className="font-bold text-orange-400">{totalBuiltupArea.toLocaleString()} sq.ft</span>
              </div>
            </div>
          </div>

          {/* Navigation Tabs for Details */}
          <div className="flex border-b border-slate-200 dark:border-slate-800 gap-4 text-xs font-bold">
            <button
              onClick={() => setActiveTab('overview')}
              className={`pb-2 transition cursor-pointer ${
                activeTab === 'overview'
                  ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Cost Breakdown by Stage
            </button>
            <button
              onClick={() => setActiveTab('materials')}
              className={`pb-2 transition cursor-pointer ${
                activeTab === 'materials'
                  ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Estimated Material Quantities
            </button>
            <button
              onClick={() => setActiveTab('boq')}
              className={`pb-2 transition cursor-pointer ${
                activeTab === 'boq'
                  ? 'border-b-2 border-orange-600 text-orange-600 dark:text-orange-400'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Detailed BOQ (Bill of Quantities)
            </button>
          </div>

          {/* Tab 1: Stage Breakdown */}
          {activeTab === 'overview' && (
            <div className="space-y-3">
              {breakdown.map((item, idx) => (
                <div
                  key={idx}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3.5 shadow-2xs hover:border-orange-500/40 transition"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900 dark:text-white">{item.category}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-slate-400 font-semibold">{item.percent}%</span>
                      <span className="font-black text-slate-800 dark:text-slate-100">{formatINR(item.amount)}</span>
                    </div>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">{item.desc}</p>
                  <div className="mt-2 w-full h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div className="h-full bg-orange-600 rounded-full" style={{ width: `${item.percent}%` }} />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Tab 2: Material Quantities */}
          {activeTab === 'materials' && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                { name: 'Cement (OPC/PPC)', qty: `${cementBags.toLocaleString()} Bags`, note: '50kg each (~42 bags/100 sq.ft)', code: 'IS 269 / IS 1489' },
                { name: 'Reinforcement Steel', qty: `${steelTonnes} MT`, note: `${params.steelGrade} deformed bars`, code: 'IS 1786:2008' },
                { name: 'Coarse Sand (Zone II)', qty: `${sandCft.toLocaleString()} cft`, note: 'For concrete & 1:6 plaster', code: 'IS 383:2016' },
                { name: '10/20mm Aggregates', qty: `${aggregateCft.toLocaleString()} cft`, note: 'Crushed hard granite', code: 'IS 383:2016' },
                { name: 'Masonry Blocks/Bricks', qty: `${brickCount.toLocaleString()} Nos`, note: 'AAC blocks or modular bricks', code: 'IS 2185 / IS 1077' },
                { name: 'Floor Vitrified Tiles', qty: `${tilesSqFt.toLocaleString()} sq.ft`, note: 'Includes 12% cutting wastage', code: 'IS 13755' },
                { name: 'Wall Primer & Paint', qty: `${paintLitres.toLocaleString()} Litres`, note: '2 coats emulsion over primer', code: 'IS 15489' },
              ].map((m, i) => (
                <div key={i} className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3.5 shadow-2xs">
                  <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">{m.name}</div>
                  <div className="text-base font-black text-orange-600 dark:text-orange-400 mt-1">{m.qty}</div>
                  <div className="text-[10px] text-slate-400 mt-1">{m.note}</div>
                  <div className="mt-2 inline-block rounded-md bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 text-[9px] font-bold text-slate-600 dark:text-slate-300">
                    {m.code}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Tab 3: Detailed BOQ Table */}
          {activeTab === 'boq' && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="py-2.5 px-3">Item</th>
                      <th className="py-2.5 px-3">Description</th>
                      <th className="py-2.5 px-3">Qty</th>
                      <th className="py-2.5 px-3">Unit</th>
                      <th className="py-2.5 px-3">Rate (₹)</th>
                      <th className="py-2.5 px-3 text-right">Amount (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                    {boqItems.map((item) => (
                      <tr key={item.itemNo} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="py-2.5 px-3 font-bold text-orange-600 dark:text-orange-400 whitespace-nowrap">
                          {item.itemNo}
                        </td>
                        <td className="py-2.5 px-3 text-slate-800 dark:text-slate-200 max-w-xs">
                          {item.description}
                          <div className="text-[10px] text-slate-400">{item.isCodeReference}</div>
                        </td>
                        <td className="py-2.5 px-3 font-bold">{item.quantity}</td>
                        <td className="py-2.5 px-3 text-slate-500">{item.unit}</td>
                        <td className="py-2.5 px-3 font-semibold">{formatINR(item.rate)}</td>
                        <td className="py-2.5 px-3 font-black text-right text-slate-900 dark:text-white">
                          {formatINR(item.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Mandatory Engineering Disclaimer */}
          <div className="rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/70 dark:bg-amber-950/30 p-3.5 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-2.5">
            <ShieldAlert className="h-5 w-5 shrink-0 text-amber-600 dark:text-amber-400 mt-0.5" />
            <div>
              <span className="font-bold">Preliminary Civil Engineering Disclaimer:</span> This estimate is generated based on standard CPWD (Delhi Schedule of Rates) volumetric thumb-rules and preliminary structural assumptions. It does not constitute a certified structural engineering drawing, architectural stamp, or commercial contractor tender quotation. Actual site conditions, soil bearing capacity (SBC), and specific architectural drawings will govern final material quantities.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
