import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar, NavModule } from './components/Sidebar';
import { DashboardModule } from './components/DashboardModule';
import { EstimatorModule } from './components/EstimatorModule';
import { CalculatorModule } from './components/CalculatorModule';
import { AiAssistantModule } from './components/AiAssistantModule';
import { ProjectManagerModule } from './components/ProjectManagerModule';
import { ProgressMonitoringModule } from './components/ProgressMonitoringModule';
import { MaterialModule } from './components/MaterialModule';
import { LabourEquipmentModule } from './components/LabourEquipmentModule';
import { LandPlotModule } from './components/LandPlotModule';
import { DocumentModule } from './components/DocumentModule';
import { SafetyModule } from './components/SafetyModule';
import { BimViewerModule } from './components/BimViewerModule';
import { ReportExportModule } from './components/ReportExportModule';
import { AcademicDocsModule } from './components/AcademicDocsModule';

import {
  UserRole,
  Project,
  ProjectTask,
  MaterialItem,
  MaterialPurchase,
  MaterialConsumption,
  LabourRecord,
  EquipmentItem,
  SafetyCheckItem,
  SafetyIncident,
  DocumentRecord,
  SitePhotoRecord,
} from './types/civil';

import {
  INITIAL_PROJECTS,
  INITIAL_TASKS,
  INITIAL_MATERIALS,
  INITIAL_PURCHASES,
  INITIAL_CONSUMPTION,
  INITIAL_LABOUR,
  INITIAL_EQUIPMENT,
  INITIAL_SAFETY_CHECKS,
  INITIAL_SAFETY_INCIDENTS,
  INITIAL_DOCUMENTS,
  INITIAL_SITE_PHOTOS,
} from './data/seedData';

import { civilApi } from './services/api';

export default function App() {
  const [currentRole, setCurrentRole] = useState<UserRole>('Civil Engineer');
  const [currentModule, setCurrentModule] = useState<NavModule>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [mobileOpen, setMobileOpen] = useState<boolean>(false);
  const [darkMode, setDarkMode] = useState<boolean>(true);

  // Core Data States with resilient seed defaults
  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [selectedProjectId, setSelectedProjectId] = useState<string>(INITIAL_PROJECTS[0].id);
  const [tasks, setTasks] = useState<ProjectTask[]>(INITIAL_TASKS);
  const [materials, setMaterials] = useState<MaterialItem[]>(INITIAL_MATERIALS);
  const [purchases, setPurchases] = useState<MaterialPurchase[]>(INITIAL_PURCHASES);
  const [consumption, setConsumption] = useState<MaterialConsumption[]>(INITIAL_CONSUMPTION);
  const [labour, setLabour] = useState<LabourRecord[]>(INITIAL_LABOUR);
  const [equipment, setEquipment] = useState<EquipmentItem[]>(INITIAL_EQUIPMENT);
  const [safetyChecks, setSafetyChecks] = useState<SafetyCheckItem[]>(INITIAL_SAFETY_CHECKS);
  const [safetyIncidents, setSafetyIncidents] = useState<SafetyIncident[]>(INITIAL_SAFETY_INCIDENTS);
  const [documents, setDocuments] = useState<DocumentRecord[]>(INITIAL_DOCUMENTS);
  const [sitePhotos, setSitePhotos] = useState<SitePhotoRecord[]>(INITIAL_SITE_PHOTOS);

  // Sync dark mode class
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Load live data from full-stack REST API
  const refreshData = async () => {
    try {
      const [projData, taskData, matData, labData, eqData, safeData, docData, photoData] = await Promise.all([
        civilApi.getProjects(),
        civilApi.getTasks(),
        civilApi.getMaterials(),
        civilApi.getLabour(),
        civilApi.getEquipment(),
        civilApi.getSafety(),
        civilApi.getDocuments(),
        civilApi.getSitePhotos(),
      ]);

      if (projData && projData.length > 0) setProjects(projData);
      if (taskData && taskData.length > 0) setTasks(taskData);
      if (matData?.materials?.length > 0) setMaterials(matData.materials);
      if (matData?.purchases?.length > 0) setPurchases(matData.purchases);
      if (matData?.consumption?.length > 0) setConsumption(matData.consumption);
      if (labData && labData.length > 0) setLabour(labData);
      if (eqData && eqData.length > 0) setEquipment(eqData);
      if (safeData?.checklist?.length > 0) setSafetyChecks(safeData.checklist);
      if (safeData?.incidents?.length > 0) setSafetyIncidents(safeData.incidents);
      if (docData && docData.length > 0) setDocuments(docData);
      if (photoData && photoData.length > 0) setSitePhotos(photoData);
    } catch (e) {
      console.warn('Falling back to local high-precision engineering seed state', e);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors duration-200">
      {/* Top Navbar */}
      <Navbar
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        projects={projects}
        selectedProjectId={selectedProjectId}
        onSelectProject={setSelectedProjectId}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onOpenQuickEstimate={() => setCurrentModule('estimator')}
      />

      <div className="flex">
        {/* Sidebar */}
        <Sidebar
          currentModule={currentModule}
          onSelectModule={setCurrentModule}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          mobileOpen={mobileOpen}
          onToggleMobile={() => setMobileOpen(!mobileOpen)}
        />

        {/* Main Content Area */}
        <main
          className={`flex-1 transition-all duration-300 ease-in-out p-4 sm:p-6 lg:p-8 ${
            sidebarCollapsed ? 'lg:ml-20' : 'lg:ml-64'
          }`}
        >
          <div className="max-w-7xl mx-auto">
            {currentModule === 'dashboard' && (
              <DashboardModule
                projects={projects}
                tasks={tasks}
                materials={materials}
                labour={labour}
                selectedProjectId={selectedProjectId}
                onNavigate={setCurrentModule}
              />
            )}

            {currentModule === 'estimator' && <EstimatorModule />}

            {currentModule === 'calculators' && <CalculatorModule />}

            {currentModule === 'ai_assistant' && <AiAssistantModule />}

            {currentModule === 'projects' && (
              <ProjectManagerModule
                projects={projects}
                tasks={tasks}
                selectedProjectId={selectedProjectId}
                onSelectProject={setSelectedProjectId}
                onProjectCreated={(newP) => setProjects([newP, ...projects])}
                onTaskCreated={(newT) => setTasks([newT, ...tasks])}
                onTaskUpdated={(updT) =>
                  setTasks(tasks.map((t) => (t.id === updT.id ? updT : t)))
                }
              />
            )}

            {currentModule === 'progress' && (
              <ProgressMonitoringModule
                photos={sitePhotos}
                onUploadPhoto={(newP) => setSitePhotos([newP, ...sitePhotos])}
              />
            )}

            {currentModule === 'materials' && (
              <MaterialModule
                materials={materials}
                purchases={purchases}
                consumption={consumption}
                onMaterialUpdated={refreshData}
              />
            )}

            {currentModule === 'labour' && (
              <LabourEquipmentModule
                labour={labour}
                equipment={equipment}
                onDataUpdated={refreshData}
              />
            )}

            {currentModule === 'land_plot' && <LandPlotModule />}

            {currentModule === 'documents' && (
              <DocumentModule
                documents={documents}
                onDocumentAdded={(newD) => setDocuments([newD, ...documents])}
              />
            )}

            {currentModule === 'safety' && (
              <SafetyModule
                checklist={safetyChecks}
                incidents={safetyIncidents}
                onCheckUpdated={refreshData}
                onIncidentReported={refreshData}
              />
            )}

            {currentModule === 'bim_3d' && <BimViewerModule />}

            {currentModule === 'reports' && (
              <ReportExportModule
                projects={projects}
                materials={materials}
                labour={labour}
                incidents={safetyIncidents}
                selectedProjectId={selectedProjectId}
              />
            )}

            {currentModule === 'academic_docs' && <AcademicDocsModule />}
          </div>
        </main>
      </div>
    </div>
  );
}
